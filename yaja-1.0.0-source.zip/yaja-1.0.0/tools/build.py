#!/usr/bin/env python3
"""Build YAJA (Yet another jellyfin app).

Produces:
  dist/yaja.civapp           install through CivHomebrew's FTP "Install civapp"
  dist/yaja.js               single file for Gezine's Remote JS Loader (send_js.py)

Credits: the console media pipeline (hardware H.264 decode, GPU texture,
Opus/AudioOut) is XITRIX's work from Moonlight-CivSwitch
(https://github.com/XITRIX/Moonlight-CivSwitch): native-io.js, native-texture.js and
native-media.js are copied from YOUR local checkout at build time, with an
attribution header. The .civapp packager is XITRIX's package_payload.py (CivHomebrew /
Moonlight-CivSwitch tools). That repository does not ship a license for these
files, so the built outputs contain code you may not redistribute without his
permission.

Usage:
  python3 tools/build.py --moonlight PATH/TO/Moonlight-CivSwitch [--packager PATH/TO/package_payload.py]
"""
import argparse, json, pathlib, shutil, subprocess, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
VENDOR = ["native-io.js", "native-texture.js", "native-media.js"]
LOADER_LIMIT = 500 * 1024  # Gezine's Remote JS Loader rejects payloads at 500 KiB


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--moonlight", required=True, help="Moonlight-CivSwitch checkout (folder containing app/src/streaming)")
    ap.add_argument("--packager", help="package_payload.py (default: the Moonlight checkout's tools/package_payload.py)")
    args = ap.parse_args()

    moonlight = pathlib.Path(args.moonlight).expanduser().resolve()
    streaming = moonlight / "app" / "src" / "streaming"
    missing = [f for f in VENDOR if not (streaming / f).is_file()]
    if missing:
        sys.exit(f"error: {streaming} is missing {', '.join(missing)}. Point --moonlight at a Moonlight-CivSwitch checkout.")
    packager = pathlib.Path(args.packager).expanduser().resolve() if args.packager else moonlight / "tools" / "package_payload.py"
    if not packager.is_file():
        sys.exit(f"error: packager not found at {packager}. Pass --packager PATH/TO/package_payload.py (CivHomebrew or Moonlight tools/).")

    vendor = ROOT / "build" / "vendor"
    if vendor.exists():
        shutil.rmtree(vendor)
    vendor.mkdir(parents=True)
    for name in VENDOR:
        text = (streaming / name).read_text(encoding="utf-8")
        header = (f"/* {name}: written by XITRIX for Moonlight-CivSwitch (https://github.com/XITRIX/Moonlight-CivSwitch),\n"
                  f" * copied unmodified at build time from {moonlight.name}/app/src/streaming/{name}.\n"
                  " * Not covered by YAJA's license; all rights remain with its author. */\n")
        (vendor / name).write_text(header + text, encoding="utf-8")
        print(f"vendored {name} ({len(text)} bytes)")

    manifest = json.loads((ROOT / "payload.json").read_text(encoding="utf-8"))
    for script in manifest["scripts"]:
        if not (ROOT / script).is_file():
            sys.exit(f"error: payload.json lists {script}, which does not exist")

    dist = ROOT / "dist"
    dist.mkdir(exist_ok=True)
    out = dist / "yaja.civapp"
    run([sys.executable, str(packager), "--directory", str(ROOT), "--non-interactive", "--no-save-metadata", "-o", str(out)])
    run([sys.executable, str(packager), "--inspect", str(out)])

    # One file for Gezine's loader: same scripts, same order, separated by newlines
    # so a trailing line comment can never swallow the next file.
    parts = [(ROOT / s).read_text(encoding="utf-8") for s in manifest["scripts"]]
    bundle = "\n;\n".join(parts) + "\n"
    single = dist / "yaja.js"
    single.write_text(bundle, encoding="utf-8")
    size = len(bundle.encode("utf-8"))
    print(f"wrote {single.relative_to(ROOT)} ({size // 1024} KiB)")
    if size >= LOADER_LIMIT:
        print("warning: larger than the Remote JS Loader's 500 KiB limit; use the .civapp instead")


def run(cmd):
    print("$", " ".join(cmd))
    result = subprocess.run(cmd)
    if result.returncode:
        sys.exit(result.returncode)


if __name__ == "__main__":
    main()
