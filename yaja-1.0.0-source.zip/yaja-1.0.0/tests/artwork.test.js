"use strict";
const assert = require("assert");
const fs = require("fs");
const dom = require("./fake-dom.js")();
global.JF = {};
require("../app/src/ui-kit.js");

// 1) Guard: no CSS animation features the console UI engine is not known to handle.
for (const f of fs.readdirSync(__dirname + "/../app/src")) {
    const code = fs.readFileSync(__dirname + "/../app/src/" + f, "utf8").split("\n").filter((l) => !/^\s*(\/\/|\*|\/\*)/.test(l)).join("\n");
    for (const bad of [/\btransform\s*:/, /style\.transform/, /\btransition\s*:/, /linear-gradient|radial-gradient/])
        assert(!bad.test(code), f + " uses " + bad);
}

// 2) Guard: UI text uses keyboard characters only (the console font may lack symbols/emoji).
for (const f of fs.readdirSync(__dirname + "/../app/src")) {
    fs.readFileSync(__dirname + "/../app/src/" + f, "utf8").split("\n").forEach((line, i) => {
        if (/^\s*(\/\/|\*|\/\*)/.test(line)) return;
        const code = line.replace(/\/\/.*$/, "");
        for (const lit of code.match(/"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'/g) || [])
            assert(!/[^\x00-\x7e]/.test(lit), f + ":" + (i + 1) + " has a non-keyboard character in " + lit);
    });
}

(async () => {
    // 2) Loader: sequential, budgeted, releasable.
    let active = 0, peak = 0, calls = 0;
    const big = "data:image/png;base64," + "A".repeat(400000);        // ~800 KB as UTF-16
    const art = JF.ui.createArtwork((id) => { calls++; active++; peak = Math.max(peak, active);
        return new Promise((r) => setTimeout(() => { active--; r(id === "bad" ? null : big + id); }, 3)); }, () => {}, {budget: 4 * 1048576});
    const host = document.createElement("div"); document.body.appendChild(host);
    const imgs = [];
    for (let i = 0; i < 12; i++) { const img = document.createElement("img"); host.appendChild(img); imgs.push(img); art.show(img, "id" + i, "t", 300); }
    const bad = document.createElement("img"); host.appendChild(bad); art.show(bad, "bad", "t", 300);
    await new Promise((r) => setTimeout(r, 200));
    console.log("stats:", JSON.stringify(art.stats()), "peak concurrent:", peak);
    assert.strictEqual(peak, 1, "one download at a time");
    assert(art.stats().bytes <= 4 * 1048576, "cache within budget");
    assert(imgs.every((i) => i.src && i.src.startsWith("data:image/png")), "all shown");
    assert(!bad.src && art.stats().failed === 1, "failed image recorded, not retried");
    art.show(bad, "bad", "t", 300); await new Promise((r) => setTimeout(r, 20)); assert.strictEqual(calls, 13, "no retry of failed image");
    // Release frees the element; showing again uses the cache or refetches.
    art.release(imgs[0]); assert(!imgs[0].src && imgs[0].style.display === "none");
    art.show(imgs[11], "id11", "t", 300); assert.strictEqual(calls, 13, "cached image reused without download");
    // Unwanted (far-away) or removed elements are skipped by the queue.
    art.reset();
    const far = document.createElement("img"); host.appendChild(far); far.__jfWanted = false; art.show(far, "far", "t", 300);
    const gone = document.createElement("img"); art.show(gone, "gone", "t", 300);
    await new Promise((r) => setTimeout(r, 30));
    assert.strictEqual(calls, 13, "skipped unwanted and detached images");
    console.log("artwork: ALL OK");
})().catch((e) => { console.error(e); process.exit(1); });
