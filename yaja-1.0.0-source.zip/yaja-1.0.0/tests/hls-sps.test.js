"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const {execFileSync} = require("child_process");
const sps = require("../app/src/h264-sps.js");
const hls = require("../app/src/hls.js");
const {create} = require("../app/src/ts-demux.js");

const dir = fs.mkdtempSync("/tmp/hlsgen-");
function gen(name, size, extra) {
    execFileSync("ffmpeg", ["-y", "-v", "error", "-f", "lavfi", "-i", `testsrc=size=${size}:rate=24`, "-f", "lavfi", "-i", "sine=frequency=330:sample_rate=48000",
        "-t", "13", "-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p", "-g", "48", ...extra, "-c:a", "libopus", "-ac", "2", "-b:a", "96k",
        "-f", "hls", "-hls_time", "6", "-hls_segment_type", "mpegts", "-hls_playlist_type", "vod", "-hls_segment_filename", path.join(dir, name + "_%d.ts"), path.join(dir, name + ".m3u8")]);
}
const cases = [
    ["hd", "1920x1080", ["-profile:v", "high"], 1920, 1080],
    ["scope", "1920x800", ["-profile:v", "high"], 1920, 800],
    ["sd", "854x480", ["-profile:v", "main", "-bf", "0"], 854, 480],
    ["odd", "1280x718", ["-profile:v", "high"], 1280, 718]
];
for (const [name, size, extra, w, h] of cases) {
    gen(name, size, extra);
    const pl = hls.parsePlaylist(fs.readFileSync(path.join(dir, name + ".m3u8"), "utf8"));
    assert(pl.endList && pl.segments.length === 3, name + " segments: " + pl.segments.length);
    assert(pl.segments[1].start > 5.9 && pl.segments[1].start < 6.1);
    // Demux every segment independently (as the player will) and parse SPS from the first keyframe.
    let found = null, v = 0, a = 0;
    for (const seg of pl.segments) {
        const bytes = new Uint8Array(fs.readFileSync(path.join(dir, seg.uri)));
        const d = create({onVideo: (au) => { v++; if (!found && au.sps) found = au.sps; }, onAudio: () => { a++; }});
        d.push(bytes); d.end();
        assert(d.program().videoPid > 0 && d.program().audioPid > 0, "program in every segment (PAT/PMT repeated)");
    }
    const info = sps.parse(found);
    console.log(name.padEnd(6), "SPS ->", info.width + "x" + info.height, "(coded " + info.codedWidth + "x" + info.codedHeight + ")", "profile", info.profile, "| AUs", v, "opus", a);
    assert.strictEqual(info.width, w, name + " width"); assert.strictEqual(info.height, h, name + " height");
    assert(Math.abs(v - 13 * 24) <= 2);
}
// Playlist helpers.
assert.strictEqual(hls.resolve("/Videos/abc/main.m3u8?x=1", "hls1/main/0.ts?runtimeTicks=60"), "/Videos/abc/hls1/main/0.ts?runtimeTicks=60");
assert.strictEqual(hls.resolve("/Videos/abc/main.m3u8", "/abs/seg.ts"), "/abs/seg.ts");
assert.strictEqual(hls.resolve("/a/b/main.m3u8", "../c/s.ts"), "/a/c/s.ts");
assert.strictEqual(hls.resolve("/a/main.m3u8", "http://10.0.0.5:8096/x/y.ts?z=1"), "/x/y.ts?z=1");
const pl = hls.parsePlaylist("#EXTM3U\n#EXT-X-TARGETDURATION:6\n#EXTINF:6.0,\na.ts\n#EXTINF:6.0,\nb.ts\n#EXTINF:3.5,\nc.ts\n#EXT-X-ENDLIST\n");
assert.strictEqual(hls.segmentAt(pl, 0), 0); assert.strictEqual(hls.segmentAt(pl, 6), 1); assert.strictEqual(hls.segmentAt(pl, 11.9), 1); assert.strictEqual(hls.segmentAt(pl, 12), 2); assert.strictEqual(hls.segmentAt(pl, 999), 2);
assert.strictEqual(hls.firstVariant("#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1\nmain.m3u8?a=1\n"), "main.m3u8?a=1");
assert.throws(() => hls.parsePlaylist("nope"));
assert.throws(() => sps.parse(Uint8Array.of(0x68, 1, 2, 3)));
console.log("hls + sps: ALL OK");
