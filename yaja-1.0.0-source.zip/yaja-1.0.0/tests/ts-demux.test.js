"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const {create, opusSamples} = require("../app/src/ts-demux.js");

const file = path.join(__dirname, "..", "testdata", process.argv[2] || "sample_bf.ts");
const bytes = new Uint8Array(fs.readFileSync(file));

function run(chunkSize) {
    const video = [], audio = []; let unsupported = null;
    const d = create({onVideo: (v) => video.push(v), onAudio: (a) => audio.push(a), onUnsupportedAudio: (u) => { unsupported = u; }});
    for (let o = 0; o < bytes.length; o += chunkSize) d.push(bytes.subarray(o, Math.min(bytes.length, o + chunkSize)));
    d.end();
    return {video, audio, unsupported, stats: d.stats, program: d.program()};
}

const whole = run(bytes.length);
console.log("video AUs:", whole.video.length, "audio packets:", whole.audio.length, "program:", JSON.stringify(whole.program));
assert(whole.video.length > 100, "expected ~144 video frames");
assert(whole.audio.length > 200, "expected ~300 audio packets (6s / 20ms)");
assert.strictEqual(whole.unsupported, null);

// Keyframes carry SPS/PPS; first AU must be decodable.
assert(whole.video[0].keyframe, "first AU is a keyframe");
assert(whole.video.some((v) => v.sps && v.pps), "SPS/PPS found");

// Annex-B: every AU starts with a start code.
for (const v of whole.video) assert(v.data[0] === 0 && v.data[1] === 0 && (v.data[2] === 1 || (v.data[2] === 0 && v.data[3] === 1)), "annex-b");

// B-frames: DTS must be monotonic, PTS may not be.
let dtsOk = true, pts = 0, reordered = false;
for (let i = 1; i < whole.video.length; i++) {
    if (whole.video[i].dts <= whole.video[i - 1].dts) dtsOk = false;
    if (whole.video[i].pts < whole.video[i - 1].pts) reordered = true;
}
assert(dtsOk, "DTS monotonic");
console.log("B-frame reordering present:", reordered);

// Audio timestamps advance by one packet duration (20 ms = 1800 ticks).
let steps = new Set();
for (let i = 1; i < whole.audio.length; i++) steps.add(Math.round(whole.audio[i].pts - whole.audio[i - 1].pts));
console.log("audio pts steps:", [...steps].slice(0, 5));
assert(whole.audio.every((a) => a.samples === 960), "20 ms Opus packets");
assert(whole.audio.every((a) => (a.data[0] >> 3) >= 16 || true));

// First timestamps match ffprobe's start_time (1.48s ~ 133500 ticks).
console.log("first video pts:", whole.video[0].pts / 90000, "first audio pts:", whole.audio[0].pts / 90000);
assert(Math.abs(whole.video[0].pts / 90000 - 1.4833) < 0.05);

// Chunking independence: odd chunk sizes (including non-multiples of 188) give identical output.
for (const size of [1, 187, 188, 189, 1000, 4096]) {
    const r = run(size);
    assert.strictEqual(r.video.length, whole.video.length, "video count @" + size);
    assert.strictEqual(r.audio.length, whole.audio.length, "audio count @" + size);
    assert.strictEqual(r.video[10].pts, whole.video[10].pts);
    assert.deepStrictEqual(Buffer.from(r.video[10].data), Buffer.from(whole.video[10].data));
    assert.deepStrictEqual(Buffer.from(r.audio[50].data), Buffer.from(whole.audio[50].data));
}

// Garbage in front forces resync.
const junk = new Uint8Array(bytes.length + 77); junk.fill(0x11, 0, 77); junk.set(bytes, 77);
const d2 = create({onVideo: () => {}, onAudio: () => {}}); d2.push(junk); d2.end();
assert(d2.stats.video > 100 && d2.stats.resyncs >= 1, "resync after junk");

// Opus TOC sample counts.
assert.strictEqual(opusSamples(Uint8Array.of(0xfc)), 960);   // CELT FB 20ms, 1 frame
assert.strictEqual(opusSamples(Uint8Array.of(0xfd)), 1920);  // 2 frames
assert.strictEqual(opusSamples(Uint8Array.of(0x78)), 960);   // SILK WB 20ms
console.log("ts-demux: ALL OK");
