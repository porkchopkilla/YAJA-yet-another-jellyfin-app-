"use strict";
// Evaluate the built single-file bundle the way CivSwitch does (one eval, completion value
// = lifetime promise). Outside the console the platform is unavailable, so the app must
// still start, explain why networking is off, and close cleanly.
const assert = require("assert");
const fs = require("fs");
const dom = require("./fake-dom.js")();
const bundle = fs.readFileSync(__dirname + "/../dist/yaja.js", "utf8");
const lifetime = (0, eval)(bundle);
assert(lifetime && typeof lifetime.then === "function", "bundle completion value is the lifetime promise");
(async () => {
    await new Promise((r) => setTimeout(r, 30));
    for (const g of ["MoonlightStreamIO", "MoonlightNativeTexture", "MoonlightStreamMedia"]) assert(global[g], g + " defined by vendored modules");
    const app = global.__civswitchApp;
    assert(app && app.id === "jellyfin-civswitch", "app registered for cooperative cleanup");
    assert(dom.text().includes("Connect to a server"));
    assert(app.diagnostics.some((l) => l.includes("Platform unavailable")), "explains missing platform");
    // Try connecting: must fail with a clear message, not crash.
    dom.press("Enter"); for (const ch of "10.0.0.2:8096") dom.press(ch); dom.press("Enter");
    await new Promise((r) => setTimeout(r, 20));
    dom.press("ArrowDown"); dom.press("Enter");
    await new Promise((r) => setTimeout(r, 30));
    assert(dom.text().includes("Networking unavailable"), "clear error shown");
    let settled = false; lifetime.then(() => { settled = true; });
    await app.close();
    await new Promise((r) => setTimeout(r, 10));
    assert(settled, "lifetime promise settles after close");
    assert.strictEqual(dom.body.children.length, 0);
    console.log("bundle: ALL OK");
    process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
