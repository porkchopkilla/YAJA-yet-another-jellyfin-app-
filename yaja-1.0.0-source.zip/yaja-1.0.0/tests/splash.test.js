"use strict";
// Splash with the app icon while Home loads behind it; YAJA naming.
const assert = require("assert");
const dom = require("./fake-dom.js")();
global.JF = {};
for (const f of ["http", "dns", "hls", "h264-sps", "ts-demux", "jellyfin-api", "player", "diagnostics", "ui-kit", "app"]) require("../app/src/" + f + ".js");
const transport = require("./node-transport.js")();
const startMock = require("./mock-jellyfin.js");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function until(cond, label, ms = 15000) { const end = Date.now() + ms; while (!cond()) { if (Date.now() > end) throw new Error("Timed out: " + label + "\n" + dom.text().slice(0, 500)); await sleep(10); } }
const root = () => dom.body.children[0];
const splash = () => root() && root().children.find((n) => n.style.zIndex === "40");
const title = () => root().children[0].children[1].textContent;

(async () => {
    const mock = await startMock({seconds: 3});
    let saved = {server: "http://127.0.0.1:" + mock.port, host: "127.0.0.1", port: mock.port, token: "tok-123", userId: "u1", userName: "alice", deviceId: "dev-splash"};
    const platform = {transport, sleep, storage: {load: () => saved, save: (d) => { saved = d; }}, createSink: () => ({})};

    // Signed in: the splash covers Home until it and its visible artwork are ready.
    const started = Date.now();
    const app = JF.startApp(platform);
    assert(splash(), "splash shown at start");
    const icon = splash().children.find((n) => n.tagName === "IMG");
    assert.strictEqual(icon.src, JF.appIconUrl, "splash shows the app icon");
    assert(Buffer.from(JF.appIconUrl.split(",")[1], "base64").readUInt32BE(16) === 256, "the bundled 256x256 icon");
    assert(splash().textContent.includes("Loading your libraries..."));
    assert(splash().textContent.includes("Yet another jellyfin app"), "splash shows the full name");
    { const png = Buffer.from(JF.appIconUrl.split(",")[1], "base64");
      assert.strictEqual(png[25], 2, "icon is opaque RGB (no transparent corners for the launcher tile to show through)"); }
    assert.strictEqual(root().children[0].children[0].textContent, "YAJA", "header shows YAJA");
    await until(() => title() === "Home" && dom.text().includes("Libraries"), "home loaded behind the splash");
    assert(splash(), "still covered while artwork loads");
    await until(() => !splash(), "splash removed once Home is ready");
    const shownFor = Date.now() - started;
    console.log("splash shown for", shownFor, "ms");
    assert(shownFor >= 700, "shown at least 0.7 s, so it does not flash");
    assert(mock.log.some((l) => l.startsWith("GET /Items/m1/Images/Backdrop")), "Home artwork requested before the reveal");
    assert(mock.log.find((l) => l.startsWith("AUTH ")).includes('Client="YAJA"'), "the server sees the client as YAJA");
    // About shows the full name.
    dom.press("y"); await until(() => title() === "Settings", "settings");
    for (let i = 0; i < 12; i++) dom.press("ArrowDown"); dom.press("Enter");
    await until(() => dom.text().includes("YAJA (Yet another jellyfin app) 1.0.0"), "about shows the full name");
    await app.close();

    // Not signed in: straight to the connect screen.
    saved = null;
    const t1 = Date.now();
    const app2 = JF.startApp(platform);
    assert(splash(), "splash shown briefly");
    await until(() => !splash(), "splash removed");
    assert(Date.now() - t1 < 1500, "no long wait without a sign-in");
    assert.strictEqual(title(), "Connect to a server");
    await app2.close(); mock.close();
    console.log("splash: ALL OK"); process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
