"use strict";
// Compare this demuxer with ffprobe's packet list (an independent implementation).
const assert = require("assert");
const fs = require("fs");
const {execFileSync} = require("child_process");
const {create} = require("../app/src/ts-demux.js");
const file = process.argv[2];
const bytes = new Uint8Array(fs.readFileSync(file));
const video = [], audio = [];
const d = create({onVideo: (v) => video.push(v), onAudio: (a) => audio.push(a)});
d.push(bytes); d.end();

function probe(sel) {
    const out = execFileSync("ffprobe", ["-v", "error", "-select_streams", sel, "-show_entries", "packet=size,pts,dts", "-of", "csv=p=0", file]).toString().trim().split("\n");
    return out.map((l) => l.split(",")).map(([pts, dts, size]) => ({pts: Number(pts), dts: Number(dts), size: Number(size)}));
}
const pv = probe("v:0"), pa = probe("a:0");
console.log("ffprobe video packets:", pv.length, "ours:", video.length, "| audio:", pa.length, "ours:", audio.length);
assert.strictEqual(video.length, pv.length);

// Video: ffprobe's size == our Annex-B AU size; PTS and DTS identical.
for (let i = 0; i < pv.length; i++) {
    assert.strictEqual(video[i].data.length, pv[i].size, "video size @" + i);
    assert.strictEqual(video[i].pts, pv[i].pts, "video pts @" + i);
    assert.strictEqual(video[i].dts, Number.isNaN(pv[i].dts) ? pv[i].pts : pv[i].dts, "video dts @" + i);
}
// Audio: ffprobe reports the raw Opus packet (control header stripped), same as ours.
assert.strictEqual(audio.length, pa.length);
let bad = 0;
for (let i = 0; i < pa.length; i++) {
    if (audio[i].data.length !== pa[i].size) bad++;
    if (Math.abs(audio[i].pts - pa[i].pts) > 1) bad++;
}
assert.strictEqual(bad, 0, "audio mismatches: " + bad);

// Decode our reassembled H.264 with ffmpeg: every frame must decode cleanly.
const annexb = Buffer.concat(video.map((v) => Buffer.from(v.data)));
fs.writeFileSync("/tmp/ours.h264", annexb);
const log = execFileSync("ffmpeg", ["-v", "error", "-f", "h264", "-i", "/tmp/ours.h264", "-f", "null", "-"], {encoding: "utf8", stdio: ["ignore", "pipe", "pipe"]});
assert.strictEqual(log.trim(), "", "ffmpeg reported decode errors: " + log);
const frames = execFileSync("ffprobe", ["-v", "error", "-count_frames", "-select_streams", "v:0", "-show_entries", "stream=nb_read_frames", "-of", "csv=p=0", "-f", "h264", "/tmp/ours.h264"]).toString().trim();
console.log("ffmpeg decoded", frames, "frames from our reassembled stream without errors");
assert.strictEqual(Number(frames), video.length);
console.log("crosscheck: ALL OK for", file);
