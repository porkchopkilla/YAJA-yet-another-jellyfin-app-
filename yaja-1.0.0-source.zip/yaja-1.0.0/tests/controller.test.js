"use strict";
// Native controller buttons (X, Y, L, R) through a scripted stand-in for the nn::hid
// reader, plus A-Z library ordering.
const assert = require("assert");
const dom = require("./fake-dom.js")();
global.JF = {};
for (const f of ["http", "dns", "hls", "h264-sps", "ts-demux", "jellyfin-api", "player", "diagnostics", "ui-kit", "app"]) require("../app/src/" + f + ".js");
const transport = require("./node-transport.js")();
const startMock = require("./mock-jellyfin.js");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function until(cond, label, ms = 12000) { const end = Date.now() + ms; while (!cond()) { if (Date.now() > end) throw new Error("Timed out: " + label + "\n" + dom.text().slice(0, 500)); await sleep(15); } }
const title = () => dom.body.children[0].children[0].children[1].textContent;
const BIT = {X: 0x4n, Y: 0x8n, L: 0x40n, R: 0x80n};

(async () => {
    const shuffled = ["The Zebra Film", "Film 10", "alpha", "Film 9", "Bravo", "The Apple", "Film 2", "Charlie"]
        .map((name, i) => ({Id: "z" + i, Name: name, SortName: name.replace(/^The /, "").toLowerCase().replace(/\d+/g, (d) => d.padStart(10, "0")), Type: "Movie", ImageTags: {Primary: "t"}, MediaSources: [{Id: "ms"}]}));
    const mock = await startMock({seconds: 13, libraryList: shuffled.slice().sort(() => Math.random() - 0.5)});
    let bits = 0n, polls = 0;
    async function press(b) { bits |= BIT[b]; const p = polls; await until(() => polls > p + 1, "poll"); bits &= ~BIT[b]; const q = polls; await until(() => polls > q + 1, "release"); }
    let saved = {server: "http://127.0.0.1:" + mock.port, host: "127.0.0.1", port: mock.port, token: "tok-123", userId: "u1", userName: "alice", deviceId: "d"};
    const platform = {transport, sleep, storage: {load: () => saved, save: (d) => { saved = d; }},
        createController: () => ({poll: () => { polls++; return bits; }, close() {}}),
        createSink: () => ({setup() {}, videoFrame: () => true, audioFrame() {}, drainVideo() {}, drainAudio() {}, close() {}})};
    const app = JF.startApp(platform);
    await until(() => title() === "Home" && dom.text().includes("Libraries"), "home");
    assert(app.diagnostics.some((l) => l.includes("Controller buttons: native")));

    // Y opens Settings.
    await press("Y");
    await until(() => title() === "Settings", "Y -> settings");
    dom.press("Escape"); await until(() => title() === "Home" && dom.text().includes("Libraries"), "back home");

    // Library comes out A-Z by sort name, numbers in natural order.
    dom.press("ArrowDown"); dom.press("ArrowDown"); dom.press("ArrowDown"); dom.press("Enter");
    await until(() => dom.text().includes("8 titles - A-Z"), "library");
    const order = dom.text().split("A-Z")[1];
    const names = ["alpha", "The Apple", "Bravo", "Charlie", "Film 2", "Film 9", "Film 10", "The Zebra Film"];
    const positions = names.map((n) => order.indexOf(n));
    console.log("library order:", names.slice().sort((a, b) => order.indexOf(a) - order.indexOf(b)).join(", "));
    for (let i = 1; i < positions.length; i++) assert(positions[i] > positions[i - 1], "A-Z: " + names[i - 1] + " before " + names[i]);
    dom.press("Escape"); await until(() => title() === "Home" && dom.text().includes("Libraries"), "home again");

    // Going back restores focus to the Libraries row; move up to Continue watching
    // (rows: tabs, hero, continue watching, next up, libraries).
    await sleep(30);
    dom.press("ArrowUp"); dom.press("ArrowUp"); dom.press("Enter");
    await until(() => dom.text().includes("A movie."), "details"); dom.press("Enter");
    await until(() => dom.text().includes("A: pause"), "playing");
    const stats = () => { let found = null; (function walk(n) { if (n.style && n.style.fontFamily === "monospace" && n.style.color === "#9f9") found = n; n.children.forEach(walk); })(dom.body); return found; };
    assert.strictEqual(stats().style.display, "none");
    await press("X"); await until(() => stats().style.display === "", "X shows stats");
    await until(() => stats().textContent.includes("LAST 5 S") && stats().textContent.includes("frame spacing"), "rolling stats shown");
    // Same press by both routes at once (engine event + native bit) toggles only once.
    bits |= BIT.X; dom.pad("menu"); { const p = polls; await until(() => polls > p + 1, "poll"); } bits &= ~BIT.X; await sleep(200);
    assert.strictEqual(stats().style.display, "none", "double-route press toggled once (hidden)");
    // The test clip is 13 s long, so seeks clamp to its ends; presses within 0.7 s combine.
    await press("R"); await until(() => dom.text().includes("Seek to 0:12"), "R seeks forward (clamped to the end)");
    await press("L"); await until(() => dom.text().includes("Seek to 0:00"), "L seeks back (clamped to the start)");
    await sleep(900);
    assert(dom.text().includes("A: pause"), "still playing after the combined seek");
    dom.press("Escape");
    await until(() => !dom.text().includes("A: pause"), "stopped");
    await app.close(); mock.close();
    console.log("controller: ALL OK"); process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
