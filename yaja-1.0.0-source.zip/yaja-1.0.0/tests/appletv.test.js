"use strict";
// Apple TV-style Home (tabs, hero, initial focus), hero actions, and keep-awake during playback.
const assert = require("assert");
const dom = require("./fake-dom.js")();
global.JF = {};
for (const f of ["http", "dns", "hls", "h264-sps", "ts-demux", "jellyfin-api", "player", "diagnostics", "ui-kit", "app"]) require("../app/src/" + f + ".js");
const transport = require("./node-transport.js")();
const startMock = require("./mock-jellyfin.js");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function until(cond, label, ms = 20000) { const end = Date.now() + ms; while (!cond()) { if (Date.now() > end) throw new Error("Timed out: " + label + "\n" + dom.text().slice(0, 600)); await sleep(20); } }
const title = () => dom.body.children[0].children[0].children[1].textContent;
function focused() {                       // the element painted as focused (white pill or outlined card)
    let found = null;
    (function walk(n) { if (n.style && (n.style.backgroundColor === "#ffffff" && n.style.color === "#000000" || n.style.outline === "4px solid #ffffff")) found = found || n; n.children.forEach(walk); })(dom.body);
    return found ? found.textContent.trim() : null;
}

(async () => {
    const mock = await startMock({seconds: 7});
    const awake = [], setups = [];
    let saved = {server: "http://127.0.0.1:" + mock.port, host: "127.0.0.1", port: mock.port, token: "tok-123", userId: "u1", userName: "alice", deviceId: "dev-tv"};
    const platform = {transport, sleep, storage: {load: () => saved, save: (d) => { saved = d; }}, keepAwake: (on) => { awake.push(on); return true; },
        createSink: () => ({setup: (f) => setups.push(f), videoFrame: () => true, audioFrame() {}, drainVideo() {}, drainAudio() {}, close() {}})};
    const app = JF.startApp(platform);
    await until(() => title() === "Home" && dom.text().includes("Libraries"), "home");

    // Tabs and rows, no banner; focus starts on the Home tab.
    const text = dom.text();
    for (const t of ["Home", "Movies", "Settings", "Continue watching", "Next up", "Libraries"]) assert(text.includes(t), "home shows " + t);
    assert(!text.includes("CONTINUE WATCHING") && !text.includes("More info"), "no banner on Home");
    assert.strictEqual(focused(), "Home", "focus starts on the Home tab");

    // Continue watching / Next up cards sit on the blue-to-purple gradient; library tiles do not.
    const png = Buffer.from(JF.gradientUrl.split(",")[1], "base64");
    assert.strictEqual(png.subarray(1, 4).toString(), "PNG"); assert.strictEqual(png.readUInt32BE(16), 1); assert.strictEqual(png.readUInt32BE(20), 256);
    const imgs = []; (function walk(n) { if (n.tagName === "IMG") imgs.push(n); n.children.forEach(walk); })(dom.body);
    const shades = imgs.filter((i) => i.src === JF.gradientUrl);
    assert.strictEqual(shades.length, 2, "one gradient per Continue watching / Next up card (Test Movie, Second)");
    for (const shade of shades) {
        const card = shade.parentNode, art = card.children[1];
        assert.strictEqual(shade.style.width, card.style.width, "gradient spans the card");
        assert.strictEqual(parseInt(art.style.width, 10), parseInt(card.style.width, 10) - 20, "artwork framed inside the gradient");
        assert(card.textContent.includes("Test Movie") || card.textContent.includes("Test Show"));
    }
    const libraryRow = imgs.filter((i) => i.src !== JF.gradientUrl && i.parentNode && i.parentNode.parentNode && i.parentNode.parentNode.textContent.includes("Movies"));
    assert(libraryRow.every((i) => i.src !== JF.gradientUrl), "library tiles unchanged");

    // Down into Continue watching -> details; back restores focus to that card.
    dom.press("ArrowDown"); assert(focused().startsWith("Test Movie"), "first Continue watching card: " + focused());
    dom.press("Enter"); await until(() => dom.text().includes("A movie.") && dom.text().includes("> Play"), "details");
    // The artwork fills the screen behind the title and buttons, over a full-screen fade,
    // with no box behind the text.
    { const layer = dom.body.children[0].children[3], art = layer.children[0], fade = layer.children[2];
      assert.strictEqual(layer.style.display, "", "screen backdrop shown on the details page");
      assert(mock.log.some((l) => l.startsWith("GET /Items/m1/Images/Backdrop?format=Png&maxHeight=540")), "item backdrop requested for the screen");
      assert.strictEqual(fade.src, JF.scrimUrl); assert.strictEqual(fade.style.display, "");
      assert.strictEqual(fade.style.width, "1280px"); assert.strictEqual(fade.style.height, "720px");
      await until(() => art.src && art.src.startsWith("data:image/png"), "backdrop image displayed");
      const all = []; (function walk(n) { all.push(n); n.children.forEach(walk); })(dom.body);
      const title = all.find((n) => n.style && n.style.fontSize === "44px");
      assert(!title.parentNode.style.backgroundColor && !title.parentNode.style.borderRadius, "no box behind the title and buttons"); }
    dom.press("Escape"); await until(() => title() === "Home" && dom.text().includes("Libraries"), "home again");
    await sleep(30); assert(focused().startsWith("Test Movie"), "focus restored to the card after going back");

    // Play from details; keep-awake on while playing, off while paused and afterwards.
    dom.press("Enter"); await until(() => dom.text().includes("> Play") && dom.text().includes("A movie."), "details again");
    dom.press("Enter");
    await until(() => setups.length === 1 && dom.text().includes("A: pause"), "playing");
    assert(awake.includes(true), "screen kept awake while playing");
    await sleep(100); assert(!/\bplaying\b/.test(dom.text()), "overlay does not show the raw state name");
    dom.press("Enter"); await sleep(50);                     // pause
    assert.strictEqual(awake[awake.length - 1], false, "released while paused");
    dom.press("Enter"); await sleep(50);                     // resume
    assert.strictEqual(awake[awake.length - 1], true, "kept awake again after resume");
    await until(() => !dom.text().includes("A: pause"), "played to the end", 25000);
    assert.strictEqual(awake[awake.length - 1], false, "released after playback");
    dom.press("Escape");

    // Tabs: up to the tab bar, right to the library tab.
    await until(() => title() === "Home" && dom.text().includes("Libraries"), "home after playback");
    await sleep(30);
    dom.press("ArrowUp"); assert.strictEqual(focused(), "Home");
    dom.press("ArrowRight"); assert.strictEqual(focused(), "Movies");
    dom.press("Enter"); await until(() => title() === "Movies" && dom.text().includes("titles"), "library tab opens the library");
    await app.close(); mock.close();
    console.log("appletv: ALL OK"); process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
