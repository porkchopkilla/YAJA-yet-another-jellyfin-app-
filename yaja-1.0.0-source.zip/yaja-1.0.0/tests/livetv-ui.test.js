"use strict";
// Live TV tab, guide navigation, tuning, channel switching and tuner release.
const assert = require("assert");
const dom = require("./fake-dom.js")();
global.JF = {};
for (const f of ["http", "dns", "hls", "h264-sps", "ts-demux", "jellyfin-api", "player", "diagnostics", "ui-kit", "app"]) require("../app/src/" + f + ".js");
const transport = require("./node-transport.js")();
const startMock = require("./mock-jellyfin.js");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function until(cond, label, ms = 20000) { const end = Date.now() + ms; while (!cond()) { if (Date.now() > end) throw new Error("Timed out: " + label + "\n" + dom.text().slice(0, 800)); await sleep(15); } }
const title = () => dom.body.children[0].children[0].children[1].textContent;
const statusText = () => dom.body.children[0].children[2].textContent;
function focused() {
    let found = null;
    (function walk(n) { if (n.style && (n.style.backgroundColor === "#ffffff" && n.style.color === "#000000" || n.style.outline === "4px solid #ffffff")) found = found || n; n.children.forEach(walk); })(dom.body);
    return found ? found.textContent.trim() : null;
}
const half = 30 * 60000, base = Math.floor(Date.now() / half) * half, hhmm = (t) => new Date(t).toISOString().slice(11, 16);

(async () => {
    const mock = await startMock({seconds: 3, live: true, liveSeconds: 20, liveSpeed: 1, extraViews: [{Id: "lib2", Name: "Shows", CollectionType: "tvshows"}]});
    let saved = {server: "http://127.0.0.1:" + mock.port, host: "127.0.0.1", port: mock.port, token: "tok-123", userId: "u1", userName: "alice", deviceId: "dev-live"};
    const setups = [];
    const platform = {transport, sleep, storage: {load: () => saved, save: (d) => { saved = d; }},
        createSink: () => ({setup: (f) => setups.push(f), videoFrame: () => true, audioFrame() {}, drainVideo() {}, drainAudio() {}, close() {}})};
    const app = JF.startApp(platform);
    await until(() => title() === "Home" && dom.text().includes("Libraries"), "home");
    const tabsText = dom.text();
    assert(tabsText.indexOf("Shows") < tabsText.indexOf("Live TV") && tabsText.indexOf("Live TV") < tabsText.indexOf("Settings"), "Live TV tab before Settings");

    // L from Home wraps to Settings; L again reaches Live TV.
    dom.press("q"); await until(() => title() === "Settings", "L -> Settings");
    dom.press("q"); await until(() => title() === "Live TV" && dom.text().includes("News One"), "L -> Live TV guide");
    await until(() => focused() && focused().startsWith("Show " + hhmm(base)), "focus on the program on air now");
    const t = dom.text();
    assert(t.indexOf("2.1") < t.indexOf("4.1") && t.indexOf("4.1") < t.indexOf("Quiet"), "channels by number: 2.1, 4.1, 10");
    assert(t.includes("On now"), "info panel describes the focused program");
    assert(t.includes("About ch1 at " + hhmm(base)), "overview shown");

    // Up/down keep the time; a channel without guide data has one cell.
    dom.press("ArrowDown"); assert(focused().startsWith("Feature "), "4.1: the feature on air: " + focused());
    dom.press("ArrowDown"); assert(focused().startsWith("No guide information"), "10: no guide data");
    dom.press("ArrowUp"); dom.press("ArrowUp"); assert(focused().startsWith("Show " + hhmm(base)));
    dom.press("ArrowUp"); assert.strictEqual(focused(), "Live TV", "up from the first channel reaches the tab bar");
    dom.press("ArrowDown"); assert(focused().startsWith("Show " + hhmm(base)), "down from the tab bar returns to the guide");

    // Right walks programs; past the window edge the guide slides forward.
    const firstRulerLabel = () => dom.body.children[0].children[1].children[0].children[2].children[0].textContent;
    const startLabel = firstRulerLabel();
    for (let i = 0; i < 4; i++) dom.press("ArrowRight");
    assert(focused().startsWith("Show " + hhmm(base + 4 * half)), "four programs later: " + focused());
    await sleep(20);
    assert.notStrictEqual(firstRulerLabel(), startLabel, "window slid forward");
    dom.press("Enter"); await sleep(20);
    assert(/starts at/.test(statusText()), "future program: shows when it starts");
    for (let i = 0; i < 4; i++) dom.press("ArrowLeft");
    assert(focused().startsWith("Show " + hhmm(base)), "back to now");

    // Tune 2.1: live overlay, tuner opened; R switches to 4.1 and releases 2.1; B releases 4.1.
    dom.press("Enter");
    await until(() => setups.length === 1 && dom.text().includes("L / R: channel"), "tuned 2.1", 25000);
    assert(mock.log.some((l) => l.startsWith("PLAYBACKINFO ") && l.includes('"AutoOpenLiveStream":true')), "live stream opened");
    assert(mock.log.some((l) => l.startsWith("GET /Videos/ch1/live.m3u8?") && l.includes("LiveStreamId=ls-ch1")));
    await until(() => dom.text().includes("LIVE"), "LIVE badge", 15000);
    assert(dom.text().includes("LIVE   -   2.1  NEWS ONE") && dom.text().includes("Show " + hhmm(base)), "channel and current program in the overlay");
    await until(() => mock.log.some((l) => l.startsWith("REPORT-START ") && l.includes('"LiveStreamId":"ls-ch1"')), "playback reported with the live stream id");
    dom.press("e");
    await until(() => mock.log.includes("CLOSE ls-ch1"), "2.1's tuner released on channel change");
    await until(() => setups.length === 2 && mock.log.some((l) => l.startsWith("GET /Videos/ch2/live.m3u8?")), "switched to 4.1", 25000);
    await until(() => dom.text().includes("LIVE   -   4.1  MOVIES PLUS"), "4.1 overlay");
    dom.press("Escape");
    await until(() => mock.log.includes("CLOSE ls-ch2") && !dom.text().includes("A: pause"), "B stops and releases the tuner");
    await until(() => title() === "Live TV" && dom.text().includes("News One"), "back in the guide");
    await app.close(); mock.close();
    console.log("livetv-ui: ALL OK"); process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
