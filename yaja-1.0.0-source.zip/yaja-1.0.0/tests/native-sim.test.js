"use strict";
// Runs platform-native.js against a simulated console: fake memory, nn::socket,
// nn::ssl and DNS servers. Checks call sequences, arguments, waiting on
// would-block results, socket ownership and that every allocation is freed.
const assert = require("assert");
global.window = global; global.JF = {};
for (const f of ["http", "dns"]) require("../app/src/" + f + ".js");
const fs = require("fs");

// ---- Fake memory -----------------------------------------------------------
const MEM = new Uint8Array(8 << 20), MEMBASE = 0x10000000n, HEAPBASE = 0x200000000n;
let brk = 64, jsHeap = null; const live = new Map();
function region(addr) {
    if (addr >= HEAPBASE) return [jsHeap, Number(addr - HEAPBASE)];
    if (addr >= MEMBASE) return [MEM, Number(addr - MEMBASE)];
    throw new Error("bad address 0x" + addr.toString(16));
}
global.malloc = (n) => { n = Number(n); const off = brk; brk += (n + 15) & ~15; const p = MEMBASE + BigInt(off); live.set(p, n); return p; };
global.free = (p) => { if (!live.has(p)) throw new Error("free of unknown pointer 0x" + p.toString(16)); live.delete(p); };
global.write_buffer = (p, bytes) => { const [m, o] = region(p); m.set(bytes, o); };
global.read_buffer = (p, n) => { const [m, o] = region(p); return m.slice(o, o + Number(n)); };
global.read32 = (p) => { const [m, o] = region(p); return BigInt((m[o] | m[o + 1] << 8 | m[o + 2] << 16 | m[o + 3] << 24) >>> 0); };
global.write32 = (p, v) => { const [m, o] = region(p); v = Number(BigInt.asUintN(32, BigInt(v))); m[o] = v & 255; m[o + 1] = v >>> 8 & 255; m[o + 2] = v >>> 16 & 255; m[o + 3] = v >>> 24 & 255; };
global.read64 = (p) => read32(p) | (read32(p + 4n) << 32n);
global.write64 = (p, v) => { write32(p, BigInt.asUintN(32, v)); write32(p + 4n, v >> 32n); };
global.text_encode = (s) => new TextEncoder().encode(s);
global.bytes_to_string = (b) => new TextDecoder().decode(b);
global.alloc_string = (s) => { const b = text_encode(s), p = malloc(b.length + 1); write_buffer(p, b); MEM[Number(p - MEMBASE) + b.length] = 0; return p; };
global.read_null_terminated_string = (p) => { const [m, o] = region(p); let e = o; while (m[e]) e++; return new TextDecoder().decode(m.slice(o, e)); };
const cstr = (p, len) => { const [m, o] = region(BigInt(p)); return new TextDecoder().decode(m.slice(o, o + Number(len))); };
global.sdk_base = 0x1000n;

// ---- Fake console services ------------------------------------------------------
const WOULD_BLOCK = 123 | (204 << 9);
let S;                                            // per-scenario state
function reset(opts) {
    S = Object.assign({fds: new Map(), nextFd: 3, errno: 0, closed: [], calls: [], dnsQueries: [], ssl: null, sent: [], systemLookups: 0,
        dns: (server, name, id) => ({answer: [93, 184, 216, 34]}), handshake: [WOULD_BLOCK, WOULD_BLOCK, 0], response: null}, opts || {});
}
function dnsResponse(query, ip, rcode) {
    const q = Buffer.from(query);
    const head = Buffer.from([q[0], q[1], 0x81, 0x80 | (rcode || 0), 0, 1, 0, ip ? 1 : 0, 0, 0, 0, 0]);
    const parts = [head, q.subarray(12)];
    if (ip) { const rr = Buffer.alloc(16); rr[0] = 0xc0; rr[1] = 12; rr.writeUInt16BE(1, 2); rr.writeUInt16BE(1, 4); rr.writeUInt32BE(300, 6); rr.writeUInt16BE(4, 10); Buffer.from(ip).copy(rr, 12); parts.push(rr); }
    return new Uint8Array(Buffer.concat(parts));
}
const SSL = {};
function invoke(name, args) {
    S.calls.push(name.replace(/^_ZN2nn(6socket|3ssl)/, ""));
    const a = args.map((x) => typeof x === "bigint" ? x : BigInt(x)), n = (i) => Number(BigInt.asIntN(64, a[i]));
    const ret = (v) => BigInt(v);
    switch (name) {
        case "_ZN2nn6socket12GetLastErrnoEv": return ret(S.errno);
        case "_ZN2nn6socket6SocketEiii": { const fd = S.nextFd++; S.fds.set(fd, {type: n(1), connects: 0, inbox: [], recvPolls: 0}); return ret(fd); }
        case "_ZN2nn6socket5FcntlEiiz": return ret(0);
        case "_ZN2nn6socket7ConnectEiPK8sockaddrj": {
            const f = S.fds.get(n(0)); f.addr = Array.from(read_buffer(a[1], 8)).slice(2);
            if (f.connects++ === 0) { S.errno = 115; return ret(-1); }
            return ret(0);
        }
        case "_ZN2nn6socket4SendEiPKvmi": { const len = Math.min(n(2), 40); S.sent.push(read_buffer(a[1], len)); return ret(len); }   // partial sends
        case "_ZN2nn6socket4RecvEiPvmi": {
            const f = S.fds.get(n(0));
            if (!f.reply) f.reply = S.response();
            if (f.recvPolls++ % 2 === 0) { S.errno = 11; return ret(-1); }                                  // EAGAIN in between
            const chunk = f.reply.splice(0, 1)[0];
            if (!chunk) return ret(0);                                                                     // EOF
            write_buffer(a[1], chunk.subarray(0, n(2))); return ret(Math.min(chunk.length, n(2)));
        }
        case "_ZN2nn6socket6SendToEiPKvmiPK8sockaddrj": {
            const query = read_buffer(a[1], n(2)), server = Array.from(read_buffer(a[4], 8)).slice(4, 8).join(".");
            const name = (() => { let o = 12, parts = []; while (query[o]) { parts.push(Buffer.from(query.subarray(o + 1, o + 1 + query[o])).toString()); o += 1 + query[o]; } return parts.join("."); })();
            S.dnsQueries.push({server, name});
            const r = S.dns(server, name);
            if (r) S.fds.get(n(0)).inbox.push(dnsResponse(query, r.answer, r.rcode));
            return ret(n(2));
        }
        case "_ZN2nn6socket8RecvFromEiPvmiP8sockaddrPj": {
            const msg = S.fds.get(n(0)).inbox.shift();
            if (!msg) { S.errno = 11; return ret(-1); }
            write_buffer(a[1], msg); return ret(msg.length);
        }
        case "_ZN2nn6socket5CloseEi": S.closed.push(n(0)); S.fds.delete(n(0)); return ret(0);
        // nn::ssl
        case "_ZN2nn3ssl7ContextC1Ev": case "_ZN2nn3ssl10ConnectionC1Ev": case "_ZN2nn3ssl7ContextD1Ev": case "_ZN2nn3ssl10ConnectionD1Ev": return ret(0);
        case "_ZN2nn3ssl7Context6CreateENS1_10SslVersionE": S.ssl = {version: n(1), reads: 0, writes: []}; return ret(0);
        case "_ZN2nn3ssl10Connection6CreateEPNS0_7ContextE": return ret(0);
        case "_ZN2nn3ssl10Connection19SetSocketDescriptorEi": S.ssl.fd = n(1); return ret(0);
        case "_ZN2nn3ssl10Connection11SetHostNameEPKcj": S.ssl.host = cstr(a[1], a[2]); return ret(0);
        case "_ZN2nn3ssl10Connection15SetVerifyOptionENS1_12VerifyOptionE": S.ssl.verify = n(1); return ret(0);
        case "_ZN2nn3ssl10Connection9SetIoModeENS1_6IoModeE": S.ssl.ioMode = n(1); return ret(0);
        case "_ZN2nn3ssl10Connection11DoHandshakeEv": { const r = S.handshake.shift(); return ret(r === undefined ? 0 : r); }
        case "_ZN2nn3ssl10Connection18GetVerifyCertErrorEPNS_6ResultE": write32(a[1], S.certError || 0); return ret(0);
        case "_ZN2nn3ssl10Connection5WriteEPKcPij": {
            if (S.ssl.writes.length === 0 && !S.ssl.blockedWrite) { S.ssl.blockedWrite = true; return ret(WOULD_BLOCK); }
            const len = Math.min(n(3), 64); S.ssl.writes.push(read_buffer(a[1], len)); write32(a[2], len); return ret(0);
        }
        case "_ZN2nn3ssl10Connection4ReadEPcPij": {
            if (!S.ssl.reply) S.ssl.reply = S.response();
            if (S.ssl.reads++ % 3 === 0) return ret(WOULD_BLOCK);
            const chunk = S.ssl.reply.splice(0, 1)[0];
            if (!chunk) return ret(S.closeResult || (123 | (209 << 9)));                                   // closed
            write_buffer(a[1], chunk.subarray(0, n(3))); write32(a[2], Math.min(chunk.length, n(3))); return ret(0);
        }
        case "_ZN2nn3ssl10Connection7DestroyEv": S.ssl.destroyed = true; if (S.ssl.fd !== undefined) S.fds.delete(S.ssl.fd); return ret(0);   // the TLS service closes the socket it owns
        case "_ZN2nn3ssl7Context7DestroyEv": S.ssl.contextDestroyed = true; return ret(0);
    }
    throw new Error("unexpected native call " + name);
}
global.MoonlightStreamIO = {create: () => ({heapAddress: (heap) => { jsHeap = heap; return HEAPBASE; }, invoke, close() {}})};
// Symbol table for direct call_rop calls (console resolver).
const symbols = {"_ZN2nn6socket16GetHostEntByNameEPKc": 0x77n};
const awakeCalls = [];
global.call_rop = (addr, ...args) => {
    if (addr === 0x80n) { awakeCalls.push("begin"); return 0n; }
    if (addr === 0x81n) { awakeCalls.push("end"); return 0n; }
    if (addr === 0x82n) { awakeCalls.push("autosleep " + args[0]); return 0n; }
    if (addr === 0x77n) {
        S.systemLookups++;
        if (!S.systemAnswer) return 0n;
        const ip = malloc(4), list = malloc(16), ent = malloc(32);
        write_buffer(ip, Uint8Array.from(S.systemAnswer)); write64(list, ip); write64(list + 8n, 0n);
        write64(ent, 0n); write64(ent + 8n, 0n); write32(ent + 16n, 2); write32(ent + 20n, 4); write64(ent + 24n, list);
        S.systemAllocs = [ip, list, ent];                                       // owned by the "system", released below
        return ent;
    }
    throw new Error("unexpected call_rop 0x" + addr.toString(16));
};
function releaseSystem() { (S.systemAllocs || []).forEach(free); }
eval(fs.readFileSync(__dirname + "/../app/src/platform-native.js", "utf8"));
const platform = JF.nativePlatform.create({resolveNativeSymbol: (name) => { if (symbols[name]) return symbols[name]; throw new Error("Missing SDK export: " + name); }});
const httpResponse = (body, chunked) => () => {
    const b = Buffer.from(body);
    const raw = chunked ? Buffer.concat([Buffer.from("HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\nContent-Type: application/json\r\n\r\n"), Buffer.from(b.length.toString(16) + "\r\n"), b, Buffer.from("\r\n0\r\n\r\n")])
        : Buffer.from("HTTP/1.1 200 OK\r\nContent-Length: " + b.length + "\r\n\r\n" + body);
    const out = []; for (let o = 0; o < raw.length; o += 23) out.push(new Uint8Array(raw.subarray(o, o + 23)));
    return out;
};
const JSONBODY = JSON.stringify({Id: "srv", ServerName: "Home", Version: "10.11.2"});
const get = (o) => JF.http.fetchJson(platform.transport, Object.assign({method: "GET", path: "/jellyfin/System/Info/Public", timeoutMs: 8000}, o));

(async () => {
    const before = live.size;
    // A) HTTPS by server name.
    reset({response: httpResponse(JSONBODY, true)});
    let res = await get({host: "jellyfin.example.com", port: 443, tls: true});
    assert.strictEqual(res.status, 200); assert.strictEqual(res.data.ServerName, "Home");
    assert.deepStrictEqual(S.dnsQueries, [{server: "1.1.1.1", name: "jellyfin.example.com"}]);
    assert.deepStrictEqual(S.fds.size, 0, "no sockets left open");
    assert.strictEqual(S.ssl.version, 1); assert.strictEqual(S.ssl.host, "jellyfin.example.com"); assert.strictEqual(S.ssl.verify, 7); assert.strictEqual(S.ssl.ioMode, 2);
    const tcpFd = S.ssl.fd;
    assert(!S.closed.includes(tcpFd), "socket handed to TLS is not closed by the app");
    assert(S.ssl.destroyed && S.ssl.contextDestroyed, "TLS objects destroyed");
    const written = Buffer.concat(S.ssl.writes).toString();
    assert(written.startsWith("GET /jellyfin/System/Info/Public HTTP/1.1\r\nHost: jellyfin.example.com\r\n"), written.slice(0, 80));
    assert(S.calls.indexOf("10Connection11DoHandshakeEv") < S.calls.indexOf("10Connection5WriteEPKcPij"), "handshake before write");
    assert.strictEqual(live.size, before, "every allocation freed (" + (live.size - before) + " leaked)");
    console.log("A) https by name: ok (" + S.calls.filter((c) => /DoHandshake/.test(c)).length + " handshake polls, " + S.calls.filter((c) => /ReadEPcPij/.test(c)).length + " reads)");

    // B) Cached lookup; C) certificate checking off.
    reset({response: httpResponse(JSONBODY)});
    platform.setTlsVerify(false);
    res = await get({host: "jellyfin.example.com", port: 8920, tls: true});
    assert.strictEqual(res.status, 200); assert.strictEqual(S.dnsQueries.length, 0, "DNS answer reused from cache");
    assert.strictEqual(S.ssl.verify, 0, "verification off when the setting is off");
    assert(Buffer.concat(S.ssl.writes).toString().includes("Host: jellyfin.example.com:8920\r\n"));
    platform.setTlsVerify(true);
    console.log("B/C) cached lookup + verify off: ok");

    // D) Certificate failure: clear message, everything released.
    reset({response: httpResponse(JSONBODY), handshake: [WOULD_BLOCK, 123 | (207 << 9)], certError: 123 | (1509 << 9)});
    await assert.rejects(get({host: "jellyfin.example.com", port: 443, tls: true}), (e) => /TLS handshake failed: 2123-0207 \(certificate problem 2123-1509; .*self-signed/.test(e.message));
    if (!(S.ssl.destroyed && !S.closed.includes(S.ssl.fd))) console.log("DEBUG calls:", S.calls.join(" > "), "closed:", S.closed, "ssl.fd:", S.ssl.fd);
    assert(S.ssl.destroyed && !S.closed.includes(S.ssl.fd), "cleaned up after the failure");
    assert.strictEqual(live.size, before, "no leaks after failure");
    console.log("D) certificate failure: ok");

    // E1) First DNS server silent -> second answers.  E2) NXDOMAIN publicly -> console resolver.
    reset({response: httpResponse(JSONBODY), dns: (server) => server === "1.1.1.1" ? null : {answer: [10, 0, 0, 7]}});
    const t0 = Date.now();
    res = await get({host: "media.example.net", port: 8096, tls: false});
    assert.strictEqual(res.status, 200); assert.deepStrictEqual(S.dnsQueries.map((q) => q.server), ["1.1.1.1", "8.8.8.8"]);
    assert.deepStrictEqual(S.fds.size, 0); assert(Date.now() - t0 >= 1400, "waited for the silent server");
    assert(Buffer.concat(S.sent).toString().startsWith("GET /jellyfin/System/Info/Public HTTP/1.1\r\nHost: media.example.net:8096\r\n"));
    reset({response: httpResponse(JSONBODY), dns: () => ({answer: null, rcode: 3}), systemAnswer: [192, 168, 1, 50]});
    res = await get({host: "nas.lan", port: 8096, tls: false});
    assert.strictEqual(res.status, 200);
    assert.deepStrictEqual(S.dnsQueries.map((q) => q.server), ["1.1.1.1"], "a definite 'no such name' stops public retries");
    assert.strictEqual(S.systemLookups, 1); releaseSystem();
    assert.deepStrictEqual(S.fds.size, 0);
    console.log("E) DNS fallbacks: ok");

    // F) Plain HTTP by IP (the path proven on hardware) still works, with partial sends.
    reset({response: httpResponse(JSONBODY)});
    res = await get({host: "192.168.1.20", port: 8096, tls: false});
    assert.strictEqual(res.status, 200); assert.strictEqual(S.dnsQueries.length, 0); assert.strictEqual(S.ssl, null);
    assert.deepStrictEqual(S.closed.length, 1); assert.strictEqual(live.size, before);
    console.log("F) plain http by IP: ok");

    // G) Test connection report.
    reset({response: httpResponse(JSONBODY), dns: () => ({answer: [93, 184, 216, 34]})});
    const report = await platform.testConnection({host: "secure.example.org", port: 443, tls: true, basePath: "/jellyfin"}, "/System/Info/Public");
    console.log(report.lines.map((l) => "   " + l).join("\n"));
    assert(report.ok);
    assert(/^Found secure\.example\.org at 93\.184\.216\.34 via public DNS 1\.1\.1\.1/.test(report.lines[1]));
    assert(report.lines.some((l) => l === "Connected to 93.184.216.34:443"));
    assert(report.lines.some((l) => l === "Secure connection established (certificate verified)"));
    assert(report.lines.some((l) => /Jellyfin replied: HTTP 200 from "Home" 10\.11\.2/.test(l)));
    assert.strictEqual(live.size, before, "no leaks overall");
    // H) Keep-awake: media playback section in balanced pairs; idempotent; fallbacks.
    const logs = []; JF.log = (m) => logs.push(m);
    const make = (table) => JF.nativePlatform.create({resolveNativeSymbol: (name) => { if (table[name]) return table[name]; throw new Error("Missing SDK export: " + name); }});
    let p1 = make({"_ZN2nn2oe25BeginMediaPlaybackSectionEv": 0x80n, "_ZN2nn2oe23EndMediaPlaybackSectionEv": 0x81n});
    assert(p1.keepAwake(true) && p1.keepAwake(true) && p1.keepAwake(false) && p1.keepAwake(false));
    p1.keepAwake(true); p1.close();                                          // exit releases it
    assert.deepStrictEqual(awakeCalls.splice(0), ["begin", "end", "begin", "end"]);
    assert(logs.some((l) => /media playback section/.test(l)));
    let p2 = make({"_ZN2nn2oe20SetAutoSleepDisabledEb": 0x82n});
    p2.keepAwake(true); p2.keepAwake(false);
    assert.deepStrictEqual(awakeCalls.splice(0), ["autosleep 1", "autosleep 0"]);
    let p3 = make({});
    assert.strictEqual(p3.keepAwake(true), false);
    assert(logs.some((l) => /not available in this game's SDK/.test(l)) && awakeCalls.length === 0);
    console.log("H) keep-awake: ok");
    console.log("native-sim: ALL OK");
})().catch((e) => { console.error(e); process.exit(1); });
