"use strict";
// Real-time playback against decoder models that behave like the native presenter:
// frames leave in display order after a reorder hold plus processing time, and each
// drain shows only the newest finished frame (older ones are skipped). The player's
// adaptive lead must keep frames on time whatever the decoder's delay is.
const assert = require("assert");
global.window = global; global.JF = {};
for (const f of ["http", "hls", "h264-sps", "ts-demux", "jellyfin-api", "player"]) require("../app/src/" + f + ".js");
const transport = require("./node-transport.js")();
const startMock = require("./mock-jellyfin.js");

async function run(mock, item, api, depth, processMs) {
    let player, base = null, pending = [], dpb = [], ready = [], shown = 0, skipped = 0, errors = [], ages = [];
    const now = () => performance.now();
    const note = (ts) => { base = base === null ? ts : Math.min(base, ts); };
    const sink = {
        setup() {}, drainAudio() {}, close() {},
        audioFrame(p) { note(p.pts); },
        videoFrame(au) { note(Math.min(au.pts, au.dts)); pending.push({pts: au.pts, submitted: now(), at: now() + processMs}); return true; },
        drainVideo() {
            const t = now();
            while (pending.length && pending[0].at <= t) { dpb.push(pending.shift()); dpb.sort((a, b) => a.pts - b.pts); if (dpb.length > depth) ready.push(dpb.shift()); }
            if (!ready.length) return;
            const latest = ready[ready.length - 1]; skipped += ready.length - 1; ready = []; shown++;
            ages.push(t - latest.submitted);
            errors.push((latest.pts - base) / 90000 - player.position());   // > 0: shown early
        },
        latency() { return ages.length >= 8 ? ages.reduce((a, b) => a + b, 0) / ages.length / 1000 : null; }
    };
    player = JF.player.create({api, sink, transport, now, sleep: (ms) => new Promise((r) => setTimeout(r, ms)), log() {}});
    await player.load(api.masterPlaylistPath(item, {videoBitrate: 4e6, maxWidth: 1280, maxHeight: 720}).path, 0);
    await new Promise((resolve, reject) => {
        const t = setInterval(() => { player.tick(); if (player.state() === "ended") { clearInterval(t); resolve(); } if (player.state() === "error") { clearInterval(t); reject(player.error()); } }, 1000 / 60);
    });
    const steady = errors.slice(Math.floor(errors.length / 3));       // after the delay has been measured
    const mean = steady.reduce((a, b) => a + b, 0) / steady.length;
    const spread = Math.sqrt(steady.reduce((a, b) => a + (b - mean) * (b - mean), 0) / steady.length);
    const rate = skipped / (shown + skipped);
    console.log(`decoder reorder ${depth}, processing ${String(processMs).padStart(2)} ms -> shown ${shown}, skipped ${(rate * 100).toFixed(1)}%, timing ${(mean * 1000).toFixed(0)} ms (±${(spread * 1000).toFixed(0)}), lead ${player.stats.videoLeadMs} ms`);
    return {mean, rate};
}

(async () => {
    const mock = await startMock({seconds: 7});
    const api = JF.jellyfin.create({transport, host: "127.0.0.1", port: mock.port, token: "tok-123", userId: "u1"});
    const item = await api.item("m1");
    for (const [depth, ms] of [[0, 4], [2, 4], [2, 30], [4, 15]]) {
        const r = await run(mock, item, api, depth, ms);
        assert(Math.abs(r.mean) < 0.045, "frames within about one frame of their time");
        assert(r.rate < 0.03, "under 3% skipped");
    }
    mock.close();
    console.log("pacing: ALL OK");
    process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
