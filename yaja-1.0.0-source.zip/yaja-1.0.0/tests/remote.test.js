"use strict";
// Remote-style setup: HTTPS, a server name and a /jellyfin base path, driven through the UI.
const assert = require("assert");
const dom = require("./fake-dom.js")();
global.JF = {};
for (const f of ["http", "dns", "hls", "h264-sps", "ts-demux", "jellyfin-api", "player", "diagnostics", "ui-kit", "app"]) require("../app/src/" + f + ".js");
const transport = require("./node-transport.js")();
const startMock = require("./mock-jellyfin.js");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function until(cond, label, ms = 20000) { const end = Date.now() + ms; while (!cond()) { if (Date.now() > end) throw new Error("Timed out: " + label + "\n" + dom.text().slice(0, 700)); await sleep(20); } }
const title = () => dom.body.children[0].children[0].children[1].textContent;
async function typeServer(text) {
    dom.press("Enter");                                         // open the Server field
    await until(() => dom.text().includes("up to 128 characters"), "keyboard");
    for (let i = 0; i < 40; i++) dom.press("Backspace");
    for (const ch of text) dom.press(ch);
    dom.press("Enter");                                         // physical Enter finishes
    await until(() => dom.text().includes("Server: " + text), "server label");
}

(async () => {
    const mock = await startMock({seconds: 7, tls: true, basePath: "/jellyfin"});
    let saved = null, verifyCalls = [], testCalls = [];
    const setups = [];
    const platform = {transport, sleep,
        storage: {load: () => saved, save: (d) => { saved = JSON.parse(JSON.stringify(d)); }},
        setTlsVerify: (on) => verifyCalls.push(on),
        testConnection: async (address, path) => { testCalls.push([address, path]); return {ok: true, lines: ["Found " + address.host + " at 127.0.0.1 via public DNS 1.1.1.1", "Secure connection established (certificate verified)", "Jellyfin replied: HTTP 200 from \"Mock\""]}; },
        createSink: () => ({setup: (f) => setups.push(f), videoFrame: () => true, audioFrame() {}, drainVideo() {}, drainAudio() {}, close() {}})};
    const app = JF.startApp(platform);
    assert.deepStrictEqual(verifyCalls, [true], "certificate checking on by default");

    // An unencrypted remote address is accepted but clearly warned about.
    await typeServer("http://203.0.113.9:8096");
    assert(dom.text().includes("Warning: this is an unencrypted (http://) address outside your home network"));
    // The HTTPS address with a server name and base path: no warning.
    const url = "https://localhost:" + mock.port + "/jellyfin";
    dom.press("ArrowUp"); await typeServer(url);
    assert(!dom.text().includes("Warning: this is an unencrypted"));
    // Test connection uses the parsed address.
    dom.press("ArrowDown"); dom.press("ArrowDown"); dom.press("Enter");
    await until(() => title() === "Connection test: OK", "test screen");
    assert.deepStrictEqual([testCalls[0][0].host, testCalls[0][0].port, testCalls[0][0].tls, testCalls[0][0].basePath, testCalls[0][1]], ["localhost", mock.port, true, "/jellyfin", "/System/Info/Public"]);
    assert(dom.text().includes("Secure connection established"));
    dom.press("Escape"); await until(() => title() === "Connect to a server", "back to connect");

    // Connect, sign in, browse and play entirely over HTTPS within the base path.
    // Back from the results, focus is restored to "Test connection"; Connect is just above.
    await sleep(20); dom.press("ArrowUp"); dom.press("Enter");
    await until(() => title() === "Sign in to Mock" && dom.text().includes("Connected to Mock"), "login over https");
    await sleep(50);                                            // the Connect action finishes just after the screen appears
    assert.deepStrictEqual([saved.host, saved.port, saved.tls, saved.basePath], ["localhost", mock.port, true, "/jellyfin"]);
    dom.press("Enter"); for (const ch of "alice") dom.press(ch); dom.press("Enter"); await sleep(20);
    dom.press("ArrowDown"); dom.press("Enter"); for (const ch of "secret") dom.press(ch); dom.press("Enter"); await sleep(20);
    dom.press("ArrowDown"); dom.press("Enter");
    await until(() => title() === "Home" && dom.text().includes("Libraries") || mock.log.some((l) => l.startsWith("REJECTED")), "home over https");
    if (mock.log.some((l) => l.startsWith("REJECTED"))) throw new Error(mock.log.filter((l) => l.startsWith("REJECTED")).join(" "));
    dom.press("ArrowDown"); dom.press("Enter");
    await until(() => dom.text().includes("A movie."), "details"); dom.press("Enter");
    await until(() => setups.length === 1, "video started over https");
    await until(() => !dom.text().includes("A: pause"), "played to the end", 25000);

    const requests = mock.log.filter((l) => /^(GET|POST|DELETE) /.test(l));
    assert(requests.length > 10, "requests made: " + requests.length);
    assert(!mock.log.some((l) => l.startsWith("OUTSIDE-BASE")), "every request stayed under /jellyfin");
    assert(mock.log.filter((l) => l.startsWith("TLS host=")).every((l) => l === "TLS host=localhost:" + mock.port), "Host header carries the server name");
    assert(requests.some((l) => /^GET \/Videos\/m1\/hls1\/main\/\d+\.ts/.test(l)), "segments streamed over https");
    assert(requests.some((l) => l.startsWith("GET /Items/m1/Images/Backdrop")), "artwork over https");

    // Settings: certificate checking can be turned off (for self-signed servers).
    dom.press("Escape"); await until(() => title() === "Home" && dom.text().includes("Libraries"), "home");
    dom.press("y"); await until(() => title() === "Settings", "settings");
    assert(dom.text().includes("Check HTTPS certificates: On (recommended)") && dom.text().includes("on " + url));
    for (let i = 0; i < 6; i++) dom.press("ArrowDown"); dom.press("Enter");      // 5 qualities, auto-play, certificates
    await until(() => dom.text().includes("Check HTTPS certificates: Off (insecure)"), "toggled off");
    assert.deepStrictEqual(verifyCalls.slice(-1), [false]); assert.strictEqual(saved.tlsVerify, false);

    // Restart: settings from before 0.1.9 (no tls/basePath fields) are migrated from the address.
    await app.close();
    saved = {server: url, host: "localhost", port: mock.port, token: "tok-123", userId: "u1", userName: "alice", deviceId: "old"};
    const app2 = JF.startApp(platform);
    await until(() => title() === "Home" && dom.text().includes("Libraries"), "migrated settings reach Home over https");
    await app2.close(); mock.close();
    console.log("remote: ALL OK"); process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
