"use strict";
const assert = require("assert");
const dns = require("../app/src/dns.js");

// Query bytes match RFC 1035 layout exactly.
const q = dns.buildQuery(0xbeef, "Jellyfin.Example.com");
assert.deepStrictEqual(Buffer.from(q).toString("hex"),
    "beef" + "0100" + "0001" + "0000" + "0000" + "0000" +
    "086a656c6c7966696e" + "076578616d706c65" + "03636f6d" + "00" + "0001" + "0001");
assert.throws(() => dns.buildQuery(1, "bad_name.com")); assert.throws(() => dns.buildQuery(1, "-a.com")); assert.throws(() => dns.buildQuery(1, "a".repeat(64) + ".com"));
assert(dns.validName("media.my-home.duckdns.org")); assert(!dns.validName("")); assert(!dns.validName("a..b"));

// Response builder for tests (header + question + answers), with compression pointers.
function response(id, flags, rcode, answers) {
    const qbytes = Buffer.from(q.subarray(12));                      // question as sent (name at offset 12)
    const parts = [Buffer.from([id >> 8, id & 255, 0x81 | flags, 0x80 | rcode, 0, 1, 0, answers.length, 0, 0, 0, 0]), qbytes];
    for (const a of answers) parts.push(a);
    return new Uint8Array(Buffer.concat(parts));
}
const ptrToQName = Buffer.from([0xc0, 12]);                          // points at the question name
function rr(owner, type, ttl, rdata) { const h = Buffer.alloc(10); h.writeUInt16BE(type, 0); h.writeUInt16BE(1, 2); h.writeUInt32BE(ttl, 4); h.writeUInt16BE(rdata.length, 8); return Buffer.concat([owner, h, rdata]); }
const nameBytes = (s) => Buffer.concat(s.split(".").map((l) => Buffer.concat([Buffer.from([l.length]), Buffer.from(l)])).concat([Buffer.from([0])]));

// Plain A records (two addresses), compressed owner.
let r = dns.parseResponse(response(0xbeef, 0, 0, [rr(ptrToQName, 1, 300, Buffer.from([203, 0, 113, 7])), rr(ptrToQName, 1, 120, Buffer.from([203, 0, 113, 8]))]), 0xbeef, "jellyfin.example.com");
assert.deepStrictEqual(r.addresses, ["203.0.113.7", "203.0.113.8"]); assert.strictEqual(r.ttl, 120);

// CNAME chain: query -> proxy.example.net (uncompressed) -> A record whose owner points into the CNAME data.
const cnameData = nameBytes("proxy.example.net");
const msg1 = response(0xbeef, 0, 0, [rr(ptrToQName, 5, 600, cnameData)]);
const cnameOffset = msg1.length - cnameData.length;                  // where "proxy.example.net" starts
const msg = new Uint8Array(Buffer.concat([Buffer.from(msg1), rr(Buffer.from([0xc0, cnameOffset]), 1, 60, Buffer.from([198, 51, 100, 4]))]));
msg[7] = 2;                                                          // ANCOUNT 2
r = dns.parseResponse(msg, 0xbeef, "jellyfin.example.com");
assert.deepStrictEqual(r.addresses, ["198.51.100.4"]); assert.strictEqual(r.cname, "proxy.example.net"); assert.strictEqual(r.ttl, 60);

// Only AAAA (IPv6) -> clear error; NXDOMAIN; truncated; wrong id; not a response.
assert.throws(() => dns.parseResponse(response(0xbeef, 0, 0, [rr(ptrToQName, 28, 60, Buffer.alloc(16))]), 0xbeef, "jellyfin.example.com"), /no IPv4 address/);
assert.throws(() => dns.parseResponse(response(0xbeef, 0, 3, []), 0xbeef, "jellyfin.example.com"), /name does not exist/);
assert.throws(() => dns.parseResponse(response(0xbeef, 0x02, 0, []), 0xbeef, "x.com"), /truncated/);
assert.throws(() => dns.parseResponse(response(0x1234, 0, 0, []), 0xbeef, "x.com"), /different query/);
const notResp = response(0xbeef, 0, 0, []); notResp[2] = 0x01; assert.throws(() => dns.parseResponse(notResp, 0xbeef, "x.com"), /Not a DNS response/);

// Hostile input: compression loop, pointer past the end, record overrunning the packet.
const loop = response(0xbeef, 0, 0, [rr(Buffer.from([0xc0, 0]), 1, 1, Buffer.from([1, 2, 3, 4]))]);
const loopAt = loop.length - 16; loop[loopAt] = 0xc0; loop[loopAt + 1] = loopAt;   // owner (2 + 10 + 4 byte record) points at itself
assert.throws(() => dns.parseResponse(loop, 0xbeef, "x.com"), /loop/);
assert.throws(() => dns.parseResponse(response(0xbeef, 0, 0, [rr(Buffer.from([0xc0, 250]), 1, 1, Buffer.from([1, 2, 3, 4]))]), 0xbeef, "x.com"), /past the message|Truncated/);
const overrun = response(0xbeef, 0, 0, [rr(ptrToQName, 1, 1, Buffer.from([1, 2, 3, 4]))]); overrun[overrun.length - 5] = 200;  // rdlength 200
assert.throws(() => dns.parseResponse(overrun, 0xbeef, "jellyfin.example.com"), /Truncated/);
console.log("dns: ALL OK");
