"use strict";
// Navigator scrolling with a simulated layout where a just-revealed card reports
// position 0 (as the console's engine may before laying it out).
const assert = require("assert");
require("./fake-dom.js")();
global.JF = {};
require("../app/src/ui-kit.js");

const viewport = {style: {}, clientHeight: 600, scrollTop: 0, getBoundingClientRect() { return {top: 84, bottom: 684, height: 600}; }};
function rowEl(y, h) { return {style: {}, getBoundingClientRect() { return {top: 84 + y - viewport.scrollTop, bottom: 84 + y + h - viewport.scrollTop, height: h}; }}; }
// A card whose own measurement is broken (always 0), like a freshly revealed element.
function card(row) { return {el: {style: {}, offsetTop: 0, offsetHeight: 0, getBoundingClientRect() { return {top: 0, bottom: 0, height: 0}; }}, rowEl: row, kind: "card"}; }
const layout = [[0, 60], [120, 260], [460, 260], [800, 260], [1140, 260]];   // tabs, then card rows (y, height)
const rows = layout.map(([y, h], i) => { const r = rowEl(y, h); return Array.from({length: i === 0 ? 3 : 8}, () => card(r)); });

const nav = JF.ui.createNavigator(viewport);
nav.setRows(rows, false);
assert.strictEqual(viewport.scrollTop, 0);
nav.move("down"); nav.move("down"); nav.move("down");                       // to row 3 (y 800-1060)
const afterDown = viewport.scrollTop;
console.log("scrollTop after moving down to row 3:", afterDown);
assert(afterDown > 0 && 800 + 260 - afterDown <= 600 - 24 + 1, "row 3 brought into view");
for (let i = 0; i < 6; i++) nav.move("right");                              // sideways through the sliding row
assert.strictEqual(viewport.scrollTop, afterDown, "sideways moves leave the scroll alone (no jump to the top)");
for (let i = 0; i < 6; i++) nav.move("left");
assert.strictEqual(viewport.scrollTop, afterDown);
nav.move("up");                                                            // row 2 (y 460) needs 64 px of headroom
console.log("scrollTop after moving up to row 2:", viewport.scrollTop);
assert(460 - viewport.scrollTop >= 64 - 1 && viewport.scrollTop < afterDown, "scrolls up just enough to show row 2 and its heading");
nav.move("up"); nav.move("up");
assert.strictEqual(viewport.scrollTop, 0, "top row scrolls to the top");

// A row that is not laid out yet (height 0) never causes a jump.
const lazy = {style: {}, getBoundingClientRect() { return {top: 0, bottom: 0, height: 0}; }};
const rows2 = [[card(rowEl(0, 60))], [card(rowEl(400, 260))], [card(lazy)]];
const nav2 = JF.ui.createNavigator(viewport);
viewport.scrollTop = 0; nav2.setRows(rows2, false); nav2.move("down");
const before = viewport.scrollTop; nav2.move("down");
assert.strictEqual(viewport.scrollTop, before, "unmeasurable row leaves the scroll unchanged");
console.log("scroll: ALL OK");
