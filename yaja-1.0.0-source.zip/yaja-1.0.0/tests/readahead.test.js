"use strict";
// The read-ahead starts short and grows, spreading the start-up download work.
const assert = require("assert");
global.window = global; global.JF = {};
for (const f of ["http", "hls", "h264-sps", "ts-demux", "jellyfin-api", "player"]) require("../app/src/" + f + ".js");
const transport = require("./node-transport.js")();
const startMock = require("./mock-jellyfin.js");
(async () => {
    const mock = await startMock({seconds: 60});
    const api = JF.jellyfin.create({transport, host: "127.0.0.1", port: mock.port, token: "tok-123", userId: "u1"});
    const item = await api.item("m1");
    const t0 = Date.now(), SPEED = 6, now = () => t0 + (Date.now() - t0) * SPEED;
    const sink = {setup() {}, videoFrame: () => true, audioFrame() {}, drainVideo() {}, drainAudio() {}, close() {}};
    const p = JF.player.create({api, sink, transport, now, sleep: (ms) => new Promise((r) => setTimeout(r, ms / SPEED)), log() {}});
    await p.load(api.masterPlaylistPath(item, {videoBitrate: 4e6, maxWidth: 1280, maxHeight: 720}).path, 0);
    let earlyMax = 0, laterMax = 0;
    await new Promise((resolve, reject) => {
        const t = setInterval(() => {
            p.tick();
            if (p.state() === "playing") {
                if (p.position() < 4) earlyMax = Math.max(earlyMax, p.buffered());
                if (p.position() > 20 && p.position() < 30) laterMax = Math.max(laterMax, p.buffered());
            }
            if (p.position() > 30 || p.state() === "ended") { clearInterval(t); resolve(); }
            if (p.state() === "error") { clearInterval(t); reject(p.error()); }
        }, 4);
    });
    p.stop(); mock.close();
    console.log("read-ahead in the first 4 s: max " + earlyMax.toFixed(1) + " s; at 20-30 s: max " + laterMax.toFixed(1) + " s");
    assert(earlyMax <= 13, "starts with a short read-ahead (6 s limit + one 6 s segment)");
    assert(laterMax > earlyMax + 4, "read-ahead grows later");
    console.log("readahead: ALL OK"); process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
