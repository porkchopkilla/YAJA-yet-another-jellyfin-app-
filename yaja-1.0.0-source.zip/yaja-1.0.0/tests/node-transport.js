"use strict";
// Test-only transport: same interface as the console's native transport, over Node's net.
const net = require("net");
const http = require("../app/src/http.js");
module.exports = function createNodeTransport() {
    return {
        request(options, handlers) {
            return new Promise((resolve, reject) => {
                let done = false, head = null;
                const sock = options.tls
                    ? require("tls").connect({host: options.host, port: options.port, servername: net.isIP(options.host) ? undefined : options.host, rejectUnauthorized: false})
                    : net.connect(options.port, options.host);
                const timer = setTimeout(() => fail(new Error("timed out")), options.timeoutMs || 15000);
                function fail(e) { if (done) return; done = true; clearTimeout(timer); sock.destroy(); reject(e); }
                const parser = http.createParser({
                    noBody: options.method === "HEAD",
                    onHead: (h) => { head = h; if (handlers.onHead) handlers.onHead(h); },
                    onBody: (b) => { if (handlers.onBody) handlers.onBody(b); },
                    onEnd: () => { if (done) return; done = true; clearTimeout(timer); sock.destroy(); resolve({status: head.status, headers: head.headers}); }
                });
                const poll = setInterval(() => { if (options.signal && options.signal.aborted) { clearInterval(poll); fail(new Error("aborted")); } }, 5);
                sock.on(options.tls ? "secureConnect" : "connect", () => sock.write(Buffer.from(http.buildRequest(options))));
                sock.on("data", (d) => { try { parser.push(new Uint8Array(d)); } catch (e) { fail(e); } });
                sock.on("end", () => { clearInterval(poll); try { parser.eof(); } catch (e) { fail(e); } });
                sock.on("close", () => clearInterval(poll));
                sock.on("error", fail);
            });
        }
    };
};
