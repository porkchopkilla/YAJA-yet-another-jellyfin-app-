"use strict";
// Just enough DOM for the app's screens to build, update and tear down in Node.
class El {
    constructor(tag) { this.tagName = tag.toUpperCase(); this.style = {}; this.children = []; this.parentNode = null; this._text = ""; this.attrs = {}; this.offsetTop = 0; this.offsetLeft = 0; this.offsetHeight = 0; this.offsetWidth = 0; this.clientHeight = 0; this.clientWidth = 0; this.scrollTop = 0; }
    appendChild(c) { if (c.parentNode) c.parentNode.removeChild(c); c.parentNode = this; this.children.push(c); return c; }
    removeChild(c) { const i = this.children.indexOf(c); if (i < 0) throw new Error("removeChild: not a child"); this.children.splice(i, 1); c.parentNode = null; return c; }
    get firstChild() { return this.children[0] || null; }
    set textContent(v) { this.children.forEach((c) => { c.parentNode = null; }); this.children = []; this._text = String(v); }
    get textContent() { return this._text + this.children.map((c) => c.textContent).join(" "); }
    setAttribute(k, v) { this.attrs[k] = v; if (k === "src") this.src = v; } removeAttribute(k) { delete this.attrs[k]; if (k === "src") this.src = ""; }
    addEventListener() {} removeEventListener() {} focus() {}
}
module.exports = function install() {
    const listeners = {};
    const body = new El("body");
    global.window = global;
    global.document = {createElement: (t) => new El(t), body};
    Object.defineProperty(global, "navigator", {value: {getGamepads: () => []}, configurable: true, writable: true});
    global.addEventListener = (t, fn) => { (listeners[t] = listeners[t] || []).push(fn); };
    global.removeEventListener = (t, fn) => { listeners[t] = (listeners[t] || []).filter((f) => f !== fn); };
    return {
        body,
        // Controller-style input, as CivSwitch delivers it (navigate-input events).
        pad(name) { (listeners["navigate-input"] || []).slice().forEach((fn) => fn({detail: {name, status: 0}, preventDefault() {}, stopImmediatePropagation() {}})); },
        press(key) { (listeners.keydown || []).slice().forEach((fn) => fn({key, preventDefault() {}, stopImmediatePropagation() {}})); },
        listenerCount: () => Object.values(listeners).reduce((n, a) => n + a.length, 0),
        text: () => body.textContent
    };
};
