"use strict";
// Types text on the on-screen keyboard with D-pad moves and A only, like a controller.
const assert = require("assert");
const dom = require("./fake-dom.js")();
global.JF = {};
require("../app/src/ui-kit.js");
const C = JF.colors;
const host = document.createElement("div"); document.body.appendChild(host);
const kb = JF.ui.createKeyboard(host);

function grid() { return host.children[0].children[0].children[2]; }
function field() { return host.children[0].children[0].children[1].textContent; }
function keys() { return grid().children.map((row) => row.children.map((k) => k.textContent)); }
function cursor() {
    const rows = grid().children;
    for (let r = 0; r < rows.length; r++) for (let c = 0; c < rows[r].children.length; c++) if (rows[r].children[c].style.backgroundColor === C.focus) return [r, c];
    throw new Error("no highlighted key");
}
function goTo(r, c) {
    let [cr, cc] = cursor(), guard = 0;
    while ((cr !== r || cc !== c) && guard++ < 60) {
        if (cr < r) kb.action("down"); else if (cr > r) kb.action("up");
        else if (cc < c) kb.action("right"); else kb.action("left");
        [cr, cc] = cursor();
    }
    assert.deepStrictEqual([cr, cc], [r, c], "reached key");
}
function find(label) { const k = keys(); for (let r = 0; r < k.length; r++) { const c = k[r].indexOf(label); if (c >= 0) return [r, c]; } return null; }
function pressLabel(label) { const at = find(label); assert(at, "key " + label + " on this page: " + JSON.stringify(keys())); goTo(at[0], at[1]); kb.action("accept"); }
function typeChar(ch) {
    for (let attempt = 0; attempt < 3; attempt++) {
        if (find(ch === " " ? "Space" : ch)) { pressLabel(ch === " " ? "Space" : ch); return; }
        // Switch pages via the on-screen keys, as a player would.
        if (find("#+=") && /[a-z]/.test(ch) === false && /[A-Z]/.test(ch) === false) pressLabel("#+=");
        else if (find("abc")) pressLabel("abc");
        else pressLabel(find("SHIFT") ? "SHIFT" : "Shift");
    }
    throw new Error("cannot type " + JSON.stringify(ch));
}
async function typeWithPad(title, text, opts) {
    const done = kb.open(title, "", opts);
    for (const ch of text) typeChar(ch);
    pressLabel("Done");
    return done;
}

(async () => {
    // Every symbol page key is present exactly once and is a single character.
    kb.open("t", ""); pressLabel("#+=");
    const symbols = keys().slice(0, 4).flat();
    console.log("symbols page:", symbols.join(" "));
    for (const ch of "!@#$%^&*()`~-_=+[]{};:'\",.<>/?\\|") assert(symbols.includes(ch), "missing " + ch);
    assert(symbols.every((k) => k.length === 1));
    assert.strictEqual(new Set(symbols.filter((k) => !/[0-9]/.test(k))).size, symbols.filter((k) => !/[0-9]/.test(k)).length, "no duplicate symbols");
    kb.action("cancel");

    assert.strictEqual(await typeWithPad("Server", "192.168.1.20:8096"), "192.168.1.20:8096");
    const pw = "p@ss:W0rd!#{}[]\\|'\"<>?~` x";
    assert.strictEqual(await typeWithPad("Password", pw, {secret: true}), pw);
    assert.strictEqual(await typeWithPad("Name", "Living Room TV"), "Living Room TV");

    // ZR jumps to symbols and back; masked field shows dots for secrets.
    const p = kb.open("Password", "", {secret: true});
    kb.action("zr"); assert(find("abc") && find("{"), "ZR opens symbols");
    pressLabel(":"); assert.strictEqual(field(), "*_");
    kb.action("zr"); assert(find("#+=") && find("q"), "ZR returns to letters");
    kb.action("menu"); kb.action("plus");
    assert.strictEqual(await p, "", "X deletes, + finishes");
    // Scheme quick keys replace each other; 128-character limit.
    const q = kb.open("Server", "", {maxLength: 128, quickKeys: ["http://", "https://"]});
    pressLabel("https://"); assert.strictEqual(field(), "https://_");
    for (const ch of "10.0.0.5") typeChar(ch);
    pressLabel("http://"); assert.strictEqual(field(), "http://10.0.0.5_", "scheme replaced, not stacked");
    pressLabel("Done"); assert.strictEqual(await q, "http://10.0.0.5");
    const long = kb.open("Server", "http://", {maxLength: 128, quickKeys: ["http://", "https://"]});
    for (let i = 0; i < 200; i++) { pressLabel("a"); }
    pressLabel("https://");
    pressLabel("Done");
    const result = await long;
    assert.strictEqual(result.length, 128, "capped at 128: " + result.length);
    assert(result.startsWith("https://aaaa"));
    console.log("keyboard: ALL OK");
})().catch((e) => { console.error(e); process.exit(1); });
