"use strict";
const assert = require("assert");
const http = require("../app/src/http.js");

function parse(wire, chunkSize, opts) {
    const out = {head: null, body: [], ended: false};
    const p = http.createParser(Object.assign({onHead: (h) => { out.head = h; }, onBody: (b) => out.body.push(Buffer.from(b)), onEnd: () => { out.ended = true; }}, opts || {}));
    for (let o = 0; o < wire.length; o += chunkSize) p.push(new Uint8Array(wire.subarray(o, Math.min(wire.length, o + chunkSize))));
    return {out, p};
}
const body = Buffer.from("héllo wörld ".repeat(500), "utf8");
const lenResp = Buffer.concat([Buffer.from(`HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: ${body.length}\r\n\r\n`), body]);
let chunked = Buffer.from("HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\nX-A: 1\r\n\r\n");
for (let o = 0; o < body.length; o += 777) { const part = body.subarray(o, o + 777); chunked = Buffer.concat([chunked, Buffer.from(part.length.toString(16) + (o === 0 ? ";ext=1" : "") + "\r\n"), part, Buffer.from("\r\n")]); }
chunked = Buffer.concat([chunked, Buffer.from("0\r\nTrailer: x\r\n\r\n")]);

for (const size of [1, 2, 3, 7, 100, 4096, 1e6]) {
    for (const [name, wire] of [["length", lenResp], ["chunked", chunked]]) {
        const {out} = parse(wire, size);
        assert(out.ended, name + " ended @" + size);
        assert.strictEqual(out.head.status, 200);
        assert.deepStrictEqual(Buffer.concat(out.body), body, name + " body @" + size);
    }
}
// close-delimited
{ const {out, p} = parse(Buffer.from("HTTP/1.1 200 OK\r\nConnection: close\r\n\r\nabc"), 2); assert(!out.ended); p.push(Uint8Array.of(100)); p.eof(); assert(out.ended); assert.strictEqual(Buffer.concat(out.body).toString(), "abcd"); }
// truncated length body is an error on eof
{ const {p} = parse(Buffer.from("HTTP/1.1 200 OK\r\nContent-Length: 10\r\n\r\nabc"), 5); assert.throws(() => p.eof()); }
// 100-continue then real response; 204; HEAD-style noBody
{ const {out} = parse(Buffer.from("HTTP/1.1 100 Continue\r\n\r\nHTTP/1.1 204 No Content\r\n\r\n"), 4); assert.strictEqual(out.head.status, 204); assert(out.ended); }
{ const {out} = parse(Buffer.from("HTTP/1.1 200 OK\r\nContent-Length: 5\r\n\r\n"), 9, {noBody: true}); assert(out.ended && !out.body.length); }
// errors
assert.throws(() => parse(Buffer.from("garbage\r\n\r\n"), 100));
assert.throws(() => parse(Buffer.from("HTTP/1.1 200 OK\r\nContent-Length: abc\r\n\r\n"), 100));
assert.throws(() => parse(Buffer.from("HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\nzz\r\n"), 100));
// header folding of repeated names, case-insensitive
{ const {out} = parse(Buffer.from("HTTP/1.1 200 OK\r\nSet-Cookie: a\r\nset-cookie: b\r\nContent-Length: 0\r\n\r\n"), 100); assert.strictEqual(out.head.headers["set-cookie"], "a, b"); }

// Request builder
const req = Buffer.from(http.buildRequest({host: "10.0.0.5", port: 8096, method: "POST", path: "/Users/AuthenticateByName", headers: {"Content-Type": "application/json", Authorization: 'MediaBrowser Client="X"'}, body: '{"Pw":"é"}'})).toString();
assert(req.startsWith("POST /Users/AuthenticateByName HTTP/1.1\r\nHost: 10.0.0.5:8096\r\n"));
assert(req.includes("Content-Length: 11\r\n") && req.endsWith('\r\n\r\n{"Pw":"é"}'));
assert(http.buildRequest({host: "h", port: 80, path: "/"}).length > 0);
assert.throws(() => http.buildRequest({host: "h", port: 80, path: "/a b"}));
assert.throws(() => http.buildRequest({host: "h", port: 80, path: "/a\r\nX: y"}));
assert.throws(() => http.buildRequest({host: "h", port: 80, path: "/", headers: {"X\r\nEvil": "1"}}));
assert.throws(() => http.buildRequest({host: "h", port: 80, path: "/", headers: {X: "a\r\nEvil: 1"}}));
// UTF-8 round trip incl. astral plane
const s = "Ünïcode ✓ 日本語 😀 ok";
assert.strictEqual(http.decodeText(http.encodeText(s)), s);
assert.deepStrictEqual(Buffer.from(http.encodeText(s)), Buffer.from(s, "utf8"));
// base64
for (const t of ["", "a", "ab", "abc", "abcd", "\u00ff\u0000\u0001"]) { const b = Buffer.from(t, "latin1"); assert.strictEqual(http.toBase64(new Uint8Array(b)), b.toString("base64")); }
// Host header: server name, port omitted only for the scheme's default.
const hostOf = (o) => Buffer.from(http.buildRequest(Object.assign({path: "/"}, o))).toString().split("\r\n")[1];
assert.strictEqual(hostOf({host: "jellyfin.example.com", port: 443, tls: true}), "Host: jellyfin.example.com");
assert.strictEqual(hostOf({host: "jellyfin.example.com", port: 8920, tls: true}), "Host: jellyfin.example.com:8920");
assert.strictEqual(hostOf({host: "nas.lan", port: 80}), "Host: nas.lan");
assert.strictEqual(hostOf({host: "nas.lan", port: 443}), "Host: nas.lan:443");
console.log("http: ALL OK");
