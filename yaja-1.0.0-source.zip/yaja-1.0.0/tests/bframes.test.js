"use strict";
// Reproduces the field reports (12 of 24 fps shown) and checks the fix.
// Decoder model: frames leave in display order as soon as display order is
// complete, so a B-frame is released together with the frame before it. The
// native presenter shows only the newest finished frame per drain.
const assert = require("assert");
global.window = global; global.JF = {};
for (const f of ["http", "hls", "h264-sps", "ts-demux", "jellyfin-api", "player"]) require("../app/src/" + f + ".js");
const transport = require("./node-transport.js")();
const startMock = require("./mock-jellyfin.js");
const FRAME = 3750;                                   // 24 fps in 90 kHz ticks

async function play(api, path) {
    let player, decoded = [], next = null, ready = [], shown = 0, replaced = 0, ages = [];
    const now = () => performance.now();
    const sink = {
        setup() {}, audioFrame() {}, drainAudio() {}, close() {},
        videoFrame(au) {
            decoded.push({pts: au.pts, at: now() + 5, submitted: now()});
            return true;
        },
        drainVideo() {
            const t = now();
            decoded.sort((a, b) => a.pts - b.pts);
            if (next === null && decoded.length && decoded[0].at <= t) next = decoded[0].pts;
            // Release every finished frame that continues display order.
            while (decoded.length && decoded[0].at <= t && decoded[0].pts === next) { ready.push(decoded.shift()); next += FRAME; }
            if (!ready.length) return;
            const latest = ready[ready.length - 1]; replaced += ready.length - 1; ready = []; shown++;
            ages.push(t - latest.submitted);
        },
        latency() { return ages.length >= 8 ? ages.reduce((a, b) => a + b, 0) / ages.length / 1000 : null; }
    };
    player = JF.player.create({api, sink, transport, now, sleep: (ms) => new Promise((r) => setTimeout(r, ms)), log() {}});
    await player.load(path, 0);
    await new Promise((resolve, reject) => {
        const t = setInterval(() => { player.tick(); if (player.state() === "ended") { clearInterval(t); resolve(); } if (player.state() === "error") { clearInterval(t); reject(player.error()); } }, 1000 / 60);
    });
    return {shown, replaced, ratio: shown / (shown + replaced), bframes: player.stats.bframes};
}

(async () => {
    const mock = await startMock({seconds: 7, bframes: 1, variants: true});
    const api = JF.jellyfin.create({transport, host: "127.0.0.1", port: mock.port, token: "tok-123", userId: "u1"});
    const item = await api.item("m1");
    const stream = api.masterPlaylistPath(item, {videoBitrate: 4e6, maxWidth: 1280, maxHeight: 720});
    assert(stream.path.includes("profile=baseline"), "app requests Baseline");

    const before = await play(api, stream.path.replace("profile=baseline", "profile=high"));
    console.log(`previous request (High, B-frames): shown ${before.shown}, replaced ${before.replaced} -> ${(before.ratio * 24).toFixed(1)} of 24 fps shown, B-frames detected: ${before.bframes}`);
    assert(before.bframes, "B-frames detected in the High stream");
    assert(Math.abs(before.ratio - 0.5) < 0.06, "reproduces the field reports: half the frames shown");

    const after = await play(api, stream.path);
    console.log(`new request (Baseline):            shown ${after.shown}, replaced ${after.replaced} -> ${(after.ratio * 24).toFixed(1)} of 24 fps shown, B-frames detected: ${after.bframes}`);
    assert(!after.bframes, "no B-frames in the Baseline stream");
    assert(after.ratio > 0.97, "all frames shown");
    mock.close();
    console.log("bframes: ALL OK"); process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
