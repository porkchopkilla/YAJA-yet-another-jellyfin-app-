"use strict";
// Y during playback records a report, includes the server's live transcode info,
// saves it as a file and shows it under Settings -> Playback report.
const assert = require("assert");
const dom = require("./fake-dom.js")();
global.JF = {};
for (const f of ["http", "dns", "hls", "h264-sps", "ts-demux", "jellyfin-api", "player", "diagnostics", "ui-kit", "app"]) require("../app/src/" + f + ".js");
JF.diagnostics.RECORD_SECONDS = 3;              // short recording for the test
const transport = require("./node-transport.js")();
const startMock = require("./mock-jellyfin.js");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function until(cond, label, ms = 15000) { const end = Date.now() + ms; while (!cond()) { if (Date.now() > end) throw new Error("Timed out: " + label + "\n" + dom.text().slice(0, 700)); await sleep(20); } }
const title = () => dom.body.children[0].children[0].children[1].textContent;

(async () => {
    const mock = await startMock({seconds: 13, transcodingInfo: {VideoCodec: "h264", AudioCodec: "opus", Width: 1280, Height: 720, Framerate: 12, HardwareAccelerationType: "none", Bitrate: 4000000}});
    const files = {};
    let saved = {server: "http://127.0.0.1:" + mock.port, host: "127.0.0.1", port: mock.port, token: "tok-123", userId: "u1", userName: "alice", deviceId: "dev-report"};
    let bits = 0n, polls = 0;
    const counters = {decoded: 0, presented: 0, intervalCount: 0, intervalMs: 0, intervalSquaredMs: 0, decodeMs: 0, decodeSamples: 0};
    const platform = {transport, sleep,
        storage: {load: () => saved, save: (d) => { saved = d; }, writeText: (rel, text) => { files[rel] = text; return "civhomebrew/jellyfin/" + rel; }},
        createController: () => ({poll: () => { polls++; return bits; }, close() {}}),
        createSink: () => ({setup() {}, audioFrame() {}, drainAudio() {}, close() {}, mode: () => "synchronous", latency: () => 0.07,
            videoFrame: () => { counters.decoded++; counters.presented++; counters.intervalCount++; counters.intervalMs += 41.7; counters.intervalSquaredMs += 41.7 * 41.7; counters.decodeMs += 5; counters.decodeSamples++; return true; },
            drainVideo() {}, stats: () => Object.assign({}, counters)})};
    const app = JF.startApp(platform);
    await until(() => title() === "Home" && dom.text().includes("Continue watching"), "home");
    dom.press("ArrowDown"); dom.press("Enter");
    await until(() => dom.text().includes("A movie."), "details"); dom.press("Enter");
    await until(() => dom.text().includes("Y: 30 s report"), "playing with report hint");
    // Y starts the report; the overlay shows recording progress, then the result.
    bits = 0x8n; { const p = polls; await until(() => polls > p + 1, "poll"); } bits = 0n;
    await until(() => dom.text().includes("RECORDING REPORT"), "recording shown");
    await until(() => dom.text().includes("REPORT READY"), "report ready", 20000);
    const names = Object.keys(files);
    assert.strictEqual(names.length, 1); assert(/^reports\/report-\d{8}-\d{6}\.txt$/.test(names[0]), names[0]);
    const text = files[names[0]];
    console.log(text.split("\n").slice(0, 12).join("\n"));
    assert(text.startsWith("YAJA (Yet another jellyfin app) 1.0.0 playback report"), "report header uses the app name");
    assert(text.includes("Title:      Test Movie"));
    assert(text.includes("Source:     1920x1080 @ 24.000 fps (hevc)"));
    assert(text.includes("Stream:     1280x720 H.264"));
    assert(text.includes("Video path: synchronous presentation   controller: native"));
    assert(/transcoding at 12\.0 fps, hardware: none/.test(text));
    assert(/^1\. SERVER TOO SLOW/m.test(text), "server finding first");
    assert(dom.text().includes("saved civhomebrew/jellyfin/reports/"), "path shown on the overlay");
    // Report screen in Settings.
    dom.press("Escape"); await until(() => title() === "Test Movie", "back to details");
    dom.press("Escape"); await until(() => title() === "Home" && dom.text().includes("Libraries"), "home");
    dom.press("y");                                             // Y opens Settings from Home
    await until(() => title() === "Settings", "settings");
    for (let i = 0; i < 10; i++) dom.press("ArrowDown");                   // past qualities, auto-play, certificates, sign out, diagnostics
    dom.press("Enter");
    await until(() => title() === "Playback report", "report screen");
    assert(dom.text().includes("Saved as civhomebrew/jellyfin/reports/") && dom.text().includes("FINDINGS") && dom.text().includes("SERVER TOO SLOW"));
    await app.close(); mock.close();
    console.log("report: ALL OK"); process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
