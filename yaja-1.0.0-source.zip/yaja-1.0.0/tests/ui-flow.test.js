"use strict";
const assert = require("assert");
const dom = require("./fake-dom.js")();
global.JF = {};
for (const f of ["http", "dns", "hls", "h264-sps", "ts-demux", "jellyfin-api", "player", "diagnostics", "ui-kit", "app"]) require("../app/src/" + f + ".js");
const transport = require("./node-transport.js")();
const startMock = require("./mock-jellyfin.js");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function until(cond, label, ms = 15000) { const end = Date.now() + ms; while (!cond()) { if (Date.now() > end) throw new Error("Timed out waiting for: " + label + "\nScreen: " + dom.text().slice(0, 600)); await sleep(20); } }
async function type(text) { for (const ch of text) dom.press(ch); dom.press("Enter"); await sleep(10); }
const title = () => { const header = dom.body.children[0].children[0]; return header.children[1].textContent; };

(async () => {
    const mock = await startMock({seconds: 7});
    let saved = null;
    const sinkCalls = {setup: 0, video: 0, audio: 0, closes: 0};
    const platform = {
        transport, sleep,
        storage: {load: () => saved, save: (d) => { saved = JSON.parse(JSON.stringify(d)); }},
        createSink: () => ({setup: () => sinkCalls.setup++, videoFrame: () => { sinkCalls.video++; return true; }, audioFrame: () => sinkCalls.audio++, drainVideo() {}, drainAudio() {}, close: () => sinkCalls.closes++})
    };
    const app = JF.startApp(platform);
    assert.strictEqual(title(), "Connect to a server");

    // An https:// address is kept as typed, and Connect explains it is unsupported.
    dom.press("Enter");
    for (let i = 0; i < 7; i++) dom.press("Backspace");
    await type("https://127.0.0.1:" + mock.port);
    await until(() => dom.text().includes("Server: https://127.0.0.1:" + mock.port), "https label");
    dom.press("ArrowDown"); dom.press("Enter");
    // The mock speaks plain HTTP, so a secure connection to it fails with an error.
    await until(() => dom.body.children[0].children[2].style.color === JF.colors.danger, "https error shown");
    assert.strictEqual(title(), "Connect to a server");
    assert.strictEqual(saved.server, "https://127.0.0.1:" + mock.port, "typed address kept");
    // Fix it with the http:// quick key (D-pad to it on the keyboard), then Connect.
    dom.press("ArrowUp"); dom.press("Enter");
    await until(() => dom.text().includes("https://"), "keyboard reopened");
    for (let i = 0; i < 3; i++) dom.press("ArrowDown");          // from the q-row down to the quick-key row
    dom.pad("accept");                                           // A on the first quick key: http://
    await until(() => dom.text().includes("http://127.0.0.1:" + mock.port + "_"), "scheme swapped in the field");
    dom.press("Enter");                                          // physical Enter = done
    await until(() => dom.text().includes("Server: http://127.0.0.1:" + mock.port), "http label");
    dom.press("ArrowDown"); dom.press("Enter");
    await until(() => title() === "Sign in to Mock", "login screen");

    // Wrong password first: error shown, still on login.
    dom.press("Enter"); await type("alice"); dom.press("ArrowDown"); dom.press("Enter"); await type("nope");
    dom.press("ArrowDown"); dom.press("Enter");
    await until(() => dom.text().includes("rejected"), "login error");
    assert.strictEqual(title(), "Sign in to Mock");
    dom.press("ArrowUp"); dom.press("Enter"); for (let i = 0; i < 4; i++) dom.press("Backspace"); await type("secret");
    dom.press("ArrowDown"); dom.press("Enter");
    await until(() => title() === "Home" && dom.text().includes("Libraries"), "home");
    assert(saved.token === "tok-123" && saved.userId === "u1" && saved.host === "127.0.0.1", "session persisted");
    assert(!JSON.stringify(saved).includes("secret"), "password never stored");
    assert(dom.text().includes("Continue watching") && dom.text().includes("Next up"));
    // Home uses wide art: the movie's backdrop and the series thumb for the next-up episode.
    await until(() => mock.log.some((l) => l.startsWith("GET /Items/m1/Images/Backdrop?")) && mock.log.some((l) => l.startsWith("GET /Items/s1/Images/Thumb?")), "landscape artwork requests");
    assert(mock.log.some((l) => /^GET \/Items\/m1\/Images\/Backdrop\?format=Png&maxHeight=\d+/.test(l)), "backdrop requested as PNG at card height");

    // Continue watching -> details -> play to the end.
    dom.press("ArrowDown"); dom.press("Enter");
    await until(() => dom.text().includes("Play") && dom.text().includes("A movie."), "details");
    dom.press("Enter");
    await until(() => sinkCalls.setup === 1, "playback started");
    await until(() => sinkCalls.closes >= 2 && !dom.text().includes("A: pause"), "playback finished and overlay removed", 20000);
    console.log("sink:", JSON.stringify(sinkCalls));
    assert(sinkCalls.video >= 7 * 24 - 2 && sinkCalls.audio > 300);
    await until(() => mock.log.some((l) => l.startsWith("POST /Sessions/Playing/Stopped")) && mock.log.some((l) => l.startsWith("DELETE /Videos/ActiveEncodings")), "stop reported");
    assert(mock.log.some((l) => l === "POST /Sessions/Playing"), "start reported");

    // Back to home, open the library grid, then a series and its episodes.
    dom.press("Escape");
    await until(() => title() === "Home" && dom.text().includes("Libraries"), "home again");
    dom.press("ArrowDown"); dom.press("ArrowDown"); dom.press("ArrowDown"); dom.press("Enter");
    await until(() => title() === "Movies" && dom.text().includes("2 titles - A-Z"), "library grid");
    dom.press("ArrowRight"); dom.press("Enter");
    await until(() => title() === "Test Show" && dom.text().includes("Pilot"), "series screen");
    dom.press("Enter");                                          // focus starts on the first episode
    await until(() => dom.text().includes("Play") && title() === "Test Show", "episode details");

    // Settings: change quality, check persistence, open diagnostics.
    dom.press("Escape"); dom.press("Escape"); dom.press("Escape");
    await until(() => title() === "Home", "home 3");
    dom.press("y");
    await until(() => title() === "Settings", "settings");
    dom.press("ArrowDown"); dom.press("ArrowDown"); dom.press("Enter");
    assert.strictEqual(saved.quality, 2, "quality saved");
    for (let i = 0; i < 7; i++) dom.press("ArrowDown"); dom.press("Enter");   // from quality 3: q4, q5, auto-play, certificates, time zone, sign out, diagnostics
    await until(() => title() === "Diagnostics", "diagnostics");
    assert(dom.text().includes("YAJA (Yet another jellyfin app) 1.0.0 started"));

    // Restart the app with the saved session: it should open straight to Home.
    await app.close();
    assert.strictEqual(dom.body.children.length, 0, "DOM removed on close");
    const before = dom.listenerCount();
    const app2 = JF.startApp(platform);
    await until(() => title() === "Home" && dom.text().includes("Libraries"), "auto sign-in");
    await app2.close();
    assert(dom.listenerCount() <= before, "listeners removed");
    mock.close();
    console.log("ui-flow: ALL OK");
    process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
