"use strict";
// Sliding Continue Watching row, auto-play of the next episode, and its cancel/off paths.
const assert = require("assert");
const dom = require("./fake-dom.js")();
global.JF = {};
for (const f of ["http", "dns", "hls", "h264-sps", "ts-demux", "jellyfin-api", "player", "diagnostics", "ui-kit", "app"]) require("../app/src/" + f + ".js");
JF.UP_NEXT_SECONDS = 2;
const transport = require("./node-transport.js")();
const startMock = require("./mock-jellyfin.js");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function until(cond, label, ms = 20000) { const end = Date.now() + ms; while (!cond()) { if (Date.now() > end) throw new Error("Timed out: " + label + "\n" + dom.text().slice(0, 600)); await sleep(20); } }
const title = () => dom.body.children[0].children[0].children[1].textContent;
function visibleCards(heading) {
    // Cards of the row that follows the heading, with their display state.
    const content = dom.body.children[0].children[1].children[0];
    let row = null, found = false;
    (function walk(n) { if (row) return; if (n.textContent === heading && n.children.length === 0) found = true; else if (found && n.style && n.style.display === "flex" && n.children.length > 3) row = n; n.children.forEach(walk); })(content);
    // Card parts by type: [gradient img], artwork div (holding the artwork img), title, subtitle.
    return row.children.map((c) => {
        const divs = c.children.filter((ch) => ch.tagName === "DIV"), art = divs[0];
        return {name: divs[1] ? divs[1].textContent : "", shown: c.style.display !== "none", img: art.children.find((ch) => ch.tagName === "IMG")};
    });
}

(async () => {
    const mock = await startMock({seconds: 7, resumeCount: 10});
    const setups = [];
    let saved = {server: "http://127.0.0.1:" + mock.port, host: "127.0.0.1", port: mock.port, token: "tok-123", userId: "u1", userName: "alice", deviceId: "dev-auto"};
    const platform = {transport, sleep, storage: {load: () => saved, save: (d) => { saved = d; }},
        createSink: () => ({setup: (f) => setups.push(f), videoFrame: () => true, audioFrame() {}, drainVideo() {}, drainAudio() {}, close() {}})};
    const app = JF.startApp(platform);
    await until(() => title() === "Home" && dom.text().includes("Libraries"), "home");

    // Continue watching: 10 items, 3 visible, sliding with the focus.
    assert(dom.text().includes("1-3 of 10  >"), "counter shows the window");
    let cards = visibleCards("Continue watching");
    assert.strictEqual(cards.length, 10); assert.deepStrictEqual(cards.map((c) => c.shown), [true, true, true, false, false, false, false, false, false, false]);
    dom.press("ArrowDown");                                   // into the row
    for (let i = 0; i < 5; i++) dom.press("ArrowRight");      // focus the 6th card
    await sleep(50);
    cards = visibleCards("Continue watching");
    assert.deepStrictEqual(cards.map((c) => c.shown), [false, false, false, true, true, true, false, false, false, false], "window slid to 4-6");
    assert(dom.text().includes("<  4-6 of 10  >"));
    await until(() => cards.filter((c) => c.img.src).every((c, i, all) => true) && visibleCards("Continue watching").some((c) => c.shown && c.img.src), "visible art loads");
    assert(visibleCards("Continue watching").every((c) => c.shown || !c.img.src), "hidden cards hold no images");
    for (let i = 0; i < 9; i++) dom.press("ArrowRight");      // clamp at the end
    await sleep(30);
    assert(dom.text().includes("<  8-10 of 10") && !dom.text().includes("8-10 of 10  >"));
    for (let i = 0; i < 12; i++) dom.press("ArrowLeft");
    await sleep(30);
    assert(dom.text().includes("1-3 of 10  >") && !dom.text().includes("<  1-3"));

    // Auto-play: play episode 1 of the series; it ends, Up next counts down, episode 2 starts.
    for (let i = 0; i < 4; i++) dom.press("ArrowDown"); dom.press("Enter");          // Libraries -> Movies
    await until(() => title() === "Movies" && dom.text().includes("titles"), "library");
    dom.press("ArrowRight"); dom.press("Enter");
    await until(() => title() === "Test Show" && dom.text().includes("Pilot"), "series");
    dom.press("Enter");                                          // focus starts on the first episode
    await until(() => dom.text().includes("First episode."), "episode 1 details"); dom.press("Enter");
    await until(() => setups.length === 1 && dom.text().includes("A: pause"), "episode 1 playing");
    await until(() => dom.text().includes("UP NEXT") && dom.text().includes("S1:E2 - Second") && dom.text().includes("Starting in"), "up next shown", 25000);
    await until(() => setups.length === 2 && dom.text().includes("A: pause"), "episode 2 auto-started");
    await until(() => dom.text().includes("Second episode."), "details screen now shows episode 2");
    assert(mock.log.some((l) => l.startsWith("GET /Shows/s1/Episodes?") && l.includes("startItemId=e1") && l.includes("limit=2")), "next episode looked up with startItemId");
    assert(mock.log.some((l) => l.startsWith("GET /Videos/e2/master.m3u8?")), "episode 2 streamed");
    // Episode 2 is the last: when it ends, playback simply stops.
    await until(() => !dom.text().includes("A: pause"), "stops after the last episode", 25000);
    assert(!dom.text().includes("UP NEXT"));

    // B during Up next cancels; with auto-play off there is no Up next at all.
    dom.press("Escape"); await until(() => title() === "Test Show" && dom.text().includes("Pilot"), "series again");
    await sleep(30); dom.press("Enter");
    await until(() => dom.text().includes("First episode."), "episode 1 details again"); dom.press("Enter");
    await until(() => dom.text().includes("UP NEXT"), "up next again", 25000);
    dom.press("Escape");
    await until(() => !dom.text().includes("A: pause") && dom.text().includes("First episode."), "B cancels to details");
    await sleep(2500); assert.strictEqual(setups.length, 3, "nothing auto-started after cancel");
    saved.autoplay = false; await app.close();
    const app2 = JF.startApp(platform);
    await until(() => title() === "Home" && dom.text().includes("Libraries"), "home (auto-play off)");
    for (let i = 0; i < 5; i++) dom.press("ArrowDown"); dom.press("Enter");
    await until(() => title() === "Movies" && dom.text().includes("titles"), "library 2"); dom.press("ArrowRight"); dom.press("Enter");
    await until(() => dom.text().includes("Pilot"), "series 2"); await sleep(30); dom.press("Enter");
    await until(() => dom.text().includes("First episode."), "details 2"); dom.press("Enter");
    await until(() => setups.length === 4, "playing with auto-play off");
    await until(() => !dom.text().includes("A: pause"), "ended", 25000);
    assert(!dom.text().includes("UP NEXT") && setups.length === 4, "no auto-play when off");
    await app2.close(); mock.close();
    console.log("home-autoplay: ALL OK"); process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
