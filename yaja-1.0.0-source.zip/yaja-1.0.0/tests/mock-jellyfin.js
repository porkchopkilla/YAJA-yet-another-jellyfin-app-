"use strict";
// Minimal Jellyfin stand-in for the routes the app uses (verified against the server source).
const httpMod = require("http");
const fs = require("fs");
const path = require("path");
const {execFileSync} = require("child_process");

module.exports = function startMock(opts) {
    const dir = fs.mkdtempSync("/tmp/mockjf-");
    // "seg": High profile with B-frames (what a server returns for profile=high);
    // "base": Baseline profile, no B-frames (only generated when opts.variants is set).
    function encode(prefix, video) {
        execFileSync("ffmpeg", ["-y", "-v", "error", "-f", "lavfi", "-i", "testsrc=size=1280x720:rate=24", "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=48000",
            "-t", String(opts.seconds || 13), "-c:v", "libx264", "-preset", "veryfast", ...video, "-g", "48", "-pix_fmt", "yuv420p",
            "-c:a", "libopus", "-ac", "2", "-b:a", "128k", "-f", "hls", "-hls_time", "6", "-hls_segment_type", "mpegts", "-hls_playlist_type", "vod",
            "-hls_segment_filename", path.join(dir, prefix + "_%d.ts"), path.join(dir, prefix + ".m3u8")]);
    }
    encode("seg", ["-profile:v", "high", "-bf", String(opts.bframes === undefined ? 2 : opts.bframes)]);
    if (opts.variants) encode("base", ["-profile:v", "baseline"]);
    fs.copyFileSync(path.join(dir, "seg.m3u8"), path.join(dir, "src.m3u8"));
    // Live TV: 2 s segments revealed over time in an EVENT playlist.
    let liveSegs = [], liveStartedAt = null;
    if (opts.live) {
        execFileSync("ffmpeg", ["-y", "-v", "error", "-f", "lavfi", "-i", "testsrc=size=1280x720:rate=30", "-f", "lavfi", "-i", "sine=frequency=550:sample_rate=48000",
            "-t", String(opts.liveSeconds || 20), "-c:v", "libx264", "-preset", "veryfast", "-profile:v", "baseline", "-g", "60", "-pix_fmt", "yuv420p",
            "-c:a", "libopus", "-ac", "2", "-b:a", "128k", "-f", "hls", "-hls_time", "2", "-hls_segment_type", "mpegts", "-hls_playlist_type", "event",
            "-hls_segment_filename", path.join(dir, "live_%d.ts"), path.join(dir, "live.m3u8")]);
        liveSegs = fs.readFileSync(path.join(dir, "live.m3u8"), "utf8").split("\n").filter((l) => l.startsWith("#EXTINF")).map((l) => Number(l.slice(8).split(",")[0]));
    }
    const half = 30 * 60 * 1000, base = Math.floor(Date.now() / half) * half;
    const channels = [
        {Id: "ch1", Name: "News One", Number: "2.1", Type: "TvChannel", ImageTags: {Primary: "logo1"}, CurrentProgram: {Name: "Evening News"}},
        {Id: "ch3", Name: "Quiet", Number: "10", Type: "TvChannel", ImageTags: {}},
        {Id: "ch2", Name: "Movies Plus", Number: "4.1", Type: "TvChannel", ImageTags: {Primary: "logo2"}}
    ];
    function guide(channelId, from, to) {
        if (channelId === "ch3") return [];                                  // a channel without guide data
        const out = [], len = channelId === "ch1" ? half : 2 * half;
        for (let t = base - 2 * half; t < base + 16 * half; t += len) {
            if (t + len <= from || t >= to) continue;
            out.push({Id: channelId + "-" + t, ChannelId: channelId, Name: (channelId === "ch1" ? "Show " : "Feature ") + new Date(t).toISOString().slice(11, 16),
                StartDate: new Date(t).toISOString(), EndDate: new Date(t + len).toISOString(), Overview: "About " + channelId + " at " + new Date(t).toISOString().slice(11, 16), Type: "Program"});
        }
        return out;
    }
    execFileSync("ffmpeg", ["-y", "-v", "error", "-f", "lavfi", "-i", "color=c=steelblue:s=240x360", "-frames:v", "1", path.join(dir, "poster.png")]);
    const segs = fs.readFileSync(path.join(dir, "src.m3u8"), "utf8").split("\n").filter((l) => l.startsWith("#EXTINF")).map((l) => Number(l.slice(8).split(",")[0]));
    const log = [], TOKEN = "tok-123", USER = "u1";
    const items = [
        {Id: "m1", Name: "Test Movie", Type: "Movie", ProductionYear: 2024, RunTimeTicks: 130000000, Overview: "A movie.", ImageTags: {Primary: "t1"}, BackdropImageTags: ["b1"], PrimaryImageAspectRatio: 0.667,
            MediaSources: [{Id: "ms1", DefaultAudioStreamIndex: 1, MediaStreams: [{Type: "Video", Codec: "hevc", Width: 1920, Height: 1080, RealFrameRate: 24}, {Type: "Audio", Codec: "eac3", Index: 1, DisplayTitle: "English 5.1"}]
                .concat(opts.tracks ? [{Type: "Subtitle", Index: 2, DisplayTitle: "English"}, {Type: "Subtitle", Index: 4, DisplayTitle: "Spanish"}, {Type: "Audio", Index: 3, DisplayTitle: "Commentary"}] : [])}], UserData: {PlaybackPositionTicks: 0}},
        {Id: "s1", Name: "Test Show", Type: "Series", ImageTags: {Primary: "t2"}}
    ];
    function json(res, code, obj) { const b = Buffer.from(JSON.stringify(obj)); res.writeHead(code, {"Content-Type": "application/json", "Content-Length": b.length}); res.end(b); }
    const handler = (req, res) => {
        if (opts.basePath) {
            if (!req.url.startsWith(opts.basePath + "/")) { log.push("OUTSIDE-BASE " + req.method + " " + req.url); res.writeHead(404); return res.end(); }
            req.url = req.url.slice(opts.basePath.length);
        }
        if (opts.tls) log.push("TLS host=" + req.headers.host);
        if (opts.clockOffsetMs) res.setHeader("Date", new Date(Date.now() + opts.clockOffsetMs).toUTCString());
        const u = new URL(req.url, "http://x"), p = u.pathname, auth = req.headers.authorization || "";
        if (auth && !log.some((l) => l.startsWith("AUTH "))) log.push("AUTH " + auth);
        log.push(req.method + " " + req.url);
        let body = ""; req.on("data", (c) => body += c);
        req.on("end", () => {
            if (!/^MediaBrowser Client="[^"]+", Device="[^"]+", DeviceId="[^"]+", Version="[^"]+"/.test(auth)) return json(res, 400, {title: "bad auth header"});
            if (p === "/System/Info/Public") return json(res, 200, {ServerName: "Mock", Version: "10.11.0", Id: "srv"});
            if (p === "/Users/AuthenticateByName" && req.method === "POST") {
                const b = JSON.parse(body);
                if (b.Username === "alice" && b.Pw === "secret") return json(res, 200, {AccessToken: TOKEN, User: {Id: USER, Name: "alice"}});
                log.push("REJECTED " + JSON.stringify(b));
                return json(res, 401, {});
            }
            if (p === "/QuickConnect/Enabled") return json(res, 200, true);
            if (p === "/QuickConnect/Initiate") return json(res, 200, {Code: "123456", Secret: "qs"});
            if (p === "/QuickConnect/Connect") return json(res, 200, {Authenticated: u.searchParams.get("secret") === "qs", Code: "123456"});
            if (p === "/Users/AuthenticateWithQuickConnect") return json(res, 200, {AccessToken: TOKEN, User: {Id: USER, Name: "alice"}});
            if (!auth.includes('Token="' + TOKEN + '"')) return json(res, 401, {});
            if (p === "/UserViews") return json(res, 200, {Items: [{Id: "lib1", Name: "Movies", CollectionType: "movies"}].concat(opts.extraViews || [])});
            if (p === "/Items") {
                if (!opts.libraryItems && !opts.libraryList) return json(res, 200, {Items: items, TotalRecordCount: items.length});
                const start = Number(u.searchParams.get("startIndex") || 0), limit = Number(u.searchParams.get("limit") || 60);
                const all = opts.libraryList || Array.from({length: opts.libraryItems}, (_, i) => ({Id: "x" + i, Name: "Film " + i, Type: "Movie", ImageTags: {Primary: "tag" + i}, MediaSources: [{Id: "ms" + i}]}));
                return json(res, 200, {Items: all.slice(start, start + limit), TotalRecordCount: all.length});
            }
            if (p === "/UserItems/Resume") {
                const extra = Array.from({length: Math.max(0, (opts.resumeCount || 1) - 1)}, (_, i) => ({Id: "r" + i, Name: "Resume " + (i + 2), Type: "Movie", ImageTags: {Primary: "rp" + i}, BackdropImageTags: ["rb" + i]}));
                return json(res, 200, {Items: [items[0]].concat(extra)});
            }
            if (p === "/Shows/NextUp") return json(res, 200, {Items: [{Id: "e2", Name: "Second", Type: "Episode", SeriesName: "Test Show", SeriesId: "s1", IndexNumber: 2, ParentIndexNumber: 1, ParentThumbItemId: "s1", ParentThumbImageTag: "th1"}]});
            if (p === "/Items/m1") return json(res, 200, items[0]);
            if (p === "/Items/s1") return json(res, 200, {Id: "s1", Name: "Test Show", Type: "Series", ImageTags: {Primary: "t2"}, BackdropImageTags: ["sb1"]});
            if (p === "/Items/e1") return json(res, 200, {Id: "e1", Name: "Pilot", Type: "Episode", SeriesName: "Test Show", SeriesId: "s1", IndexNumber: 1, ParentIndexNumber: 1, Overview: "First episode.", MediaSources: [{Id: "mse1"}], UserData: {}});
            if (p === "/Items/e2") return json(res, 200, {Id: "e2", Name: "Second", Type: "Episode", SeriesName: "Test Show", SeriesId: "s1", IndexNumber: 2, ParentIndexNumber: 1, Overview: "Second episode.", MediaSources: [{Id: "mse2"}], UserData: {}});
            if (p === "/Shows/s1/Seasons" && opts.series) return json(res, 200, {Items: opts.series.seasons});
            if (p === "/Shows/s1/Episodes" && opts.series && !u.searchParams.get("startItemId")) return json(res, 200, {Items: opts.series.episodes[u.searchParams.get("seasonId")] || []});
            if (p === "/Shows/s1/Seasons") return json(res, 200, {Items: [{Id: "se1", Name: "Season 1", Type: "Season"}, {Id: "se2", Name: "Season 2", Type: "Season"}]});
            if (p === "/Shows/s1/Episodes") {
                const eps = [{Id: "e1", Name: "Pilot", Type: "Episode", IndexNumber: 1, ParentIndexNumber: 1, SeriesName: "Test Show", SeriesId: "s1", RunTimeTicks: 13e8},
                             {Id: "e2", Name: "Second", Type: "Episode", IndexNumber: 2, ParentIndexNumber: 1, SeriesName: "Test Show", SeriesId: "s1", RunTimeTicks: 13e8}];
                const start = u.searchParams.get("startItemId"), at = start ? eps.findIndex((e) => e.Id === start) : 0;
                const limit = Number(u.searchParams.get("limit") || eps.length);
                return json(res, 200, {Items: eps.slice(Math.max(0, at), Math.max(0, at) + limit)});
            }
            if (p.startsWith("/Items/") && /\/Images\/(Primary|Thumb|Backdrop)$/.test(p)) { const png = fs.readFileSync(path.join(dir, "poster.png")); res.writeHead(200, {"Content-Type": "image/png", "Content-Length": png.length}); return res.end(png); }
            const vid = /^\/Videos\/([^/]+)\//.exec(p), itemId = vid ? vid[1] : null;
            if (vid && p === "/Videos/" + itemId + "/master.m3u8") {
                for (const k of ["MediaSourceId", "VideoCodec", "AudioCodec", "SegmentContainer"]) if (!u.searchParams.get(k)) return json(res, 400, {title: "missing " + k});
                if (u.searchParams.get("AudioCodec") !== "opus" || u.searchParams.get("SegmentContainer") !== "ts") return json(res, 400, {title: "unexpected codecs"});
                res.writeHead(200, {"Content-Type": "application/x-mpegURL"});
                return res.end("#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=3000000,RESOLUTION=1280x720,CODECS=\"avc1.640028,Opus\"\nmain.m3u8?" + u.searchParams.toString() + "\n");
            }
            if (vid && p === "/Videos/" + itemId + "/main.m3u8") {
                let pl = "#EXTM3U\n#EXT-X-PLAYLIST-TYPE:VOD\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:6\n#EXT-X-MEDIA-SEQUENCE:0\n";
                const set = opts.variants && u.searchParams.get("profile") === "baseline" ? "base" : "seg";
                segs.forEach((d, i) => { pl += "#EXTINF:" + d.toFixed(6) + ", nodesc\nhls1/main/" + i + ".ts?set=" + set + "&runtimeTicks=" + Math.round(i * 6e7) + "&actualSegmentLengthTicks=" + Math.round(d * 1e7) + "\n"; });
                res.writeHead(200, {"Content-Type": "application/x-mpegURL"}); return res.end(pl + "#EXT-X-ENDLIST\n");
            }
            const m = /^\/Videos\/[^/]+\/hls1\/main\/(\d+)\.ts$/.exec(p);
            if (m) {
                const f = path.join(dir, (u.searchParams.get("set") === "base" ? "base" : "seg") + "_" + m[1] + ".ts");
                if (!fs.existsSync(f)) return json(res, 404, {});
                // No Content-Length: Node falls back to chunked encoding, exercising that path.
                res.writeHead(200, {"Content-Type": "video/mp2t"});
                const data = fs.readFileSync(f); let o = 0;
                (function pump() { if (o >= data.length) return res.end(); res.write(data.subarray(o, o + 65536)); o += 65536; setImmediate(pump); })();
                return;
            }
            if (p === "/LiveTv/Info") return json(res, 200, {IsEnabled: !!opts.live || !!opts.liveTv, Services: [{Name: "Tuner", Status: "Ok"}]});
            if (p === "/LiveTv/Channels") return json(res, 200, {Items: opts.live || opts.liveTv ? channels : [], TotalRecordCount: opts.live || opts.liveTv ? channels.length : 0});
            if (p === "/LiveTv/Programs") {
                const ids = (u.searchParams.get("channelIds") || "").split(",").filter(Boolean);
                const from = Date.parse(u.searchParams.get("minEndDate")), to = Date.parse(u.searchParams.get("maxStartDate"));
                return json(res, 200, {Items: ids.flatMap((id) => guide(id, from, to)).sort((a, b) => Date.parse(a.StartDate) - Date.parse(b.StartDate))});
            }
            if (/^\/Items\/ch\d\/PlaybackInfo$/.test(p) && req.method === "POST") {
                log.push("PLAYBACKINFO " + body);
                return json(res, 200, {MediaSources: [{Id: "ms-" + p.split("/")[2], LiveStreamId: "ls-" + p.split("/")[2], IsInfiniteStream: true}], PlaySessionId: "ps-live"});
            }
            if (/^\/Videos\/ch\d\/live\.m3u8$/.test(p)) {
                for (const k of ["LiveStreamId", "MediaSourceId", "VideoCodec", "AudioCodec", "SegmentContainer"]) if (!u.searchParams.get(k)) return json(res, 400, {title: "missing " + k});
                if (liveStartedAt === null) liveStartedAt = Date.now();
                const speed = opts.liveSpeed || 1, revealed = Math.min(liveSegs.length, 4 + Math.floor((Date.now() - liveStartedAt) * speed / 2000));
                let pl = "#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:2\n#EXT-X-MEDIA-SEQUENCE:0\n#EXT-X-PLAYLIST-TYPE:EVENT\n";
                for (let i = 0; i < revealed; i++) pl += "#EXTINF:" + liveSegs[i].toFixed(6) + ",\nhls/live1/" + i + ".ts\n";
                if (revealed === liveSegs.length && opts.liveEnds) pl += "#EXT-X-ENDLIST\n";
                res.writeHead(200, {"Content-Type": "application/x-mpegURL"}); return res.end(pl);
            }
            const lseg = /^\/Videos\/ch\d\/hls\/live1\/(\d+)\.ts$/.exec(p);
            if (lseg) { const f = path.join(dir, "live_" + lseg[1] + ".ts"); if (!fs.existsSync(f)) return json(res, 404, {}); const data = fs.readFileSync(f); res.writeHead(200, {"Content-Type": "video/mp2t", "Content-Length": data.length}); return res.end(data); }
            if (p === "/LiveStreams/Close" && req.method === "POST") { log.push("CLOSE " + u.searchParams.get("liveStreamId")); res.writeHead(204); return res.end(); }
            if (p.startsWith("/Sessions/Playing")) { if (/Playing$/.test(p)) log.push("REPORT-START " + body); res.writeHead(204); return res.end(); }
            if (p === "/Sessions") return json(res, 200, [{DeviceId: u.searchParams.get("deviceId"), TranscodingInfo: opts.transcodingInfo || null}]);
            if (p === "/Videos/ActiveEncodings" && req.method === "DELETE") { res.writeHead(204); return res.end(); }
            json(res, 404, {title: "no route " + p});
        });
    };
    let server;
    if (opts.tls) {
        execFileSync("openssl", ["req", "-x509", "-newkey", "rsa:2048", "-nodes", "-keyout", path.join(dir, "key.pem"), "-out", path.join(dir, "cert.pem"), "-days", "1", "-subj", "/CN=localhost"], {stdio: "ignore"});
        server = require("https").createServer({key: fs.readFileSync(path.join(dir, "key.pem")), cert: fs.readFileSync(path.join(dir, "cert.pem"))}, handler);
    } else server = httpMod.createServer(handler);
    return new Promise((resolve) => server.listen(0, "127.0.0.1", () => resolve({port: server.address().port, log, segs, close: () => server.close()})));
};
