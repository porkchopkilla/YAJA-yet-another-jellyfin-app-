"use strict";
// Playback media bar: pause, skip, subtitles (burned in), audio and quality, each restarting
// the stream with the right request.
const assert = require("assert");
const dom = require("./fake-dom.js")();
global.JF = {};
for (const f of ["http", "dns", "hls", "h264-sps", "ts-demux", "jellyfin-api", "player", "diagnostics", "ui-kit", "app"]) require("../app/src/" + f + ".js");
const transport = require("./node-transport.js")();
const startMock = require("./mock-jellyfin.js");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function until(cond, label, ms = 20000) { const end = Date.now() + ms; while (!cond()) { if (Date.now() > end) throw new Error("Timed out: " + label + "\n" + dom.text().slice(0, 700)); await sleep(15); } }
const title = () => dom.body.children[0].children[0].children[1].textContent;
function focused() {                       // the highlighted button on the player screen (above the details page)
    const root = dom.body.children[0], player = root.children.find((n) => n.style.zIndex === "20") || root;
    let found = null;
    (function walk(n) { if (n.style && (n.style.backgroundColor === "#ffffff" && n.style.color === "#000000")) found = found || n; n.children.forEach(walk); })(player);
    return found ? found.textContent.trim() : null;
}
const masters = (mock) => mock.log.filter((l) => l.startsWith("GET /Videos/m1/master.m3u8?"));

(async () => {
    const mock = await startMock({seconds: 90, tracks: true});            // long enough not to finish during the test
    let saved = {server: "http://127.0.0.1:" + mock.port, host: "127.0.0.1", port: mock.port, token: "tok-123", userId: "u1", userName: "alice", deviceId: "dev-bar"};
    const platform = {transport, sleep, storage: {load: () => saved, save: (d) => { saved = d; }},
        createSink: () => ({setup() {}, videoFrame: () => true, audioFrame() {}, drainVideo() {}, drainAudio() {}, close() {}})};
    const app = JF.startApp(platform);
    await until(() => title() === "Home" && dom.text().includes("Libraries"), "home");
    dom.press("ArrowDown"); dom.press("Enter");
    await until(() => dom.text().includes("A movie.") && dom.text().includes("> Play"), "details"); dom.press("Enter");
    await until(() => dom.text().includes("A: pause") && dom.text().includes("Quality: 720p - 4 Mbps"), "playing with the media bar");
    for (const b of ["<< 10", "|| Pause", "10 >>", "Subtitles: Off", "Audio: English 5.1", "Quality: 720p - 4 Mbps"]) assert(dom.text().includes(b), "bar has " + b);
    assert.strictEqual(focused(), "|| Pause", "focus starts on Pause");
    await until(() => !dom.text().includes("Starting transcode"), "started");

    // Pause / play.
    dom.press("Enter"); await sleep(30);
    assert.strictEqual(focused(), "> Play", "pause button turns into play"); assert(dom.text().includes("Paused"));
    dom.press("Enter"); await sleep(30); assert.strictEqual(focused(), "|| Pause");

    // Subtitles: English, burned in by the server; the old transcode is stopped.
    dom.press("ArrowRight"); dom.press("ArrowRight"); assert.strictEqual(focused(), "Subtitles: Off");
    dom.press("Enter"); await sleep(20);
    assert(dom.text().includes("SUBTITLES") && dom.text().includes("Spanish"), "subtitle menu");
    dom.press("Escape"); await sleep(20);
    assert(!dom.text().includes("SUBTITLES") && dom.text().includes("A: pause"), "B closes the menu, playback continues");
    assert.strictEqual(masters(mock).length, 1, "no restart when closing the menu");
    dom.press("Enter"); dom.press("ArrowDown"); dom.press("Enter");
    await until(() => masters(mock).length === 2, "restart for subtitles");
    assert(/SubtitleStreamIndex=2&SubtitleMethod=Encode/.test(masters(mock)[1]), masters(mock)[1]);
    assert(mock.log.some((l) => l.startsWith("DELETE /Videos/ActiveEncodings")), "old transcode stopped");
    assert(dom.text().includes("Subtitles: English"));

    // Audio: the commentary track.
    dom.press("ArrowRight"); assert.strictEqual(focused(), "Audio: English 5.1");
    dom.press("Enter"); dom.press("ArrowDown"); dom.press("Enter");
    await until(() => masters(mock).length === 3, "restart for audio");
    assert(/AudioStreamIndex=3/.test(masters(mock)[2]) && /SubtitleStreamIndex=2/.test(masters(mock)[2]), "audio changed, subtitles kept");

    // Quality: 1080p 8 Mbps for this video.
    dom.press("ArrowRight"); assert.strictEqual(focused(), "Quality: 720p - 4 Mbps");
    dom.press("Enter"); dom.press("ArrowDown"); dom.press("ArrowDown"); dom.press("Enter");
    await until(() => masters(mock).length === 4, "restart for quality");
    assert(/VideoBitrate=8000000/.test(masters(mock)[3]) && /MaxWidth=1920/.test(masters(mock)[3]), masters(mock)[3]);
    assert(dom.text().includes("Quality: 1080p - 8 Mbps"));
    await until(() => !dom.text().includes("Starting transcode") && !dom.text().includes("Buffering"), "playing again after the switch");

    // With the bar hidden, left/right skip 10 s instead of moving between buttons.
    const overlay = (() => { let o = null; (function walk(n) { if (n.style && n.style.backgroundColor === "rgba(0,0,0,0.55)") o = o || n; n.children.forEach(walk); })(dom.body); return o; })();
    try { await until(() => overlay.style.display === "none", "bar hides once playing again (even if it was buffering at 5 s)", 15000); }
    catch (e) { console.log("DEBUG overlay attached:", !!overlay.parentNode, "text:", dom.text().slice(-200)); throw e; }
    dom.press("ArrowRight"); await sleep(20);
    assert(/Seek to \d+:\d\d/.test(dom.text()), "hidden bar: right skips forward");
    dom.press("Escape");
    await until(() => !dom.text().includes("A: pause"), "B stops");
    await app.close(); mock.close();
    console.log("mediabar: ALL OK"); process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
