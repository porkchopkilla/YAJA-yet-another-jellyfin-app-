"use strict";
// Guide follows the server's clock (Date header) and the chosen time zone; channel cells use the gradient.
const assert = require("assert");
const dom = require("./fake-dom.js")();
global.JF = {};
for (const f of ["http", "dns", "hls", "h264-sps", "ts-demux", "jellyfin-api", "player", "diagnostics", "ui-kit", "app"]) require("../app/src/" + f + ".js");
const transport = require("./node-transport.js")();
const startMock = require("./mock-jellyfin.js");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function until(cond, label, ms = 20000) { const end = Date.now() + ms; while (!cond()) { if (Date.now() > end) throw new Error("Timed out: " + label + "\n" + dom.text().slice(0, 700)); await sleep(15); } }
const title = () => dom.body.children[0].children[0].children[1].textContent;
const half = 30 * 60000, AHEAD = 2 * 3600000;
const fmt = (ms, zoneMin) => { const d = new Date(ms + zoneMin * 60000), h = d.getUTCHours(), m = d.getUTCMinutes(); return ((h % 12) || 12) + ":" + (m < 10 ? "0" : "") + m + (h < 12 ? " AM" : " PM"); };

(async () => {
    const mock = await startMock({seconds: 3, liveTv: true, live: true, liveSeconds: 4, clockOffsetMs: AHEAD});
    let saved = {server: "http://127.0.0.1:" + mock.port, host: "127.0.0.1", port: mock.port, token: "tok-123", userId: "u1", userName: "alice", deviceId: "dev-epg", tz: 120};
    const platform = {transport, sleep, storage: {load: () => saved, save: (d) => { saved = d; }}, createSink: () => ({setup() {}, videoFrame: () => true, audioFrame() {}, drainVideo() {}, drainAudio() {}, close() {}})};
    const app = JF.startApp(platform);
    await until(() => title() === "Home" && dom.text().includes("Live TV"), "home with Live TV");
    dom.press("ArrowRight"); dom.press("ArrowRight"); dom.press("Enter");
    await until(() => title() === "Live TV" && dom.text().includes("News One") && dom.text().includes("On now"), "guide");

    // "Now" is the server's time (2 h ahead of the console): the program on air is 2 h later.
    const serverHalf = Math.floor((Date.now() + AHEAD) / half) * half;
    assert(dom.text().includes("Show " + new Date(serverHalf).toISOString().slice(11, 16)), "program on air by the server's clock");
    assert(!dom.text().includes("Show " + new Date(Math.floor(Date.now() / half) * half).toISOString().slice(11, 16) + " ") || AHEAD < half, "not the console's");
    // Ruler and clock in the chosen zone (UTC+02:00).
    assert(dom.text().includes(fmt(serverHalf, 120)), "ruler label in UTC+2: " + fmt(serverHalf, 120));
    assert(dom.text().includes("UTC+02:00") && dom.text().includes("server time"), "clock shows its zone and that it is server time");
    const all = []; (function walk(n) { all.push(n); n.children.forEach(walk); })(dom.body);
    const clockNode = all.find((n) => n.style && n.style.fontSize === "30px" && /AM|PM/.test(n.textContent));
    const expected = fmt(Date.now() + AHEAD, 120);
    assert.strictEqual(clockNode.textContent, expected, "clock reads server time in UTC+2");
    // Channel cells on the gradient.
    assert.strictEqual(all.filter((n) => n.tagName === "IMG" && n.src === JF.gradientUrl).length, 3, "gradient behind each channel cell");

    // Settings: the time zone chooser changes the guide.
    dom.press("y"); await until(() => title() === "Settings" && dom.text().includes("Time zone: UTC+02:00"), "settings shows the zone");
    for (let i = 0; i < 7; i++) dom.press("ArrowDown"); dom.press("Enter");
    await until(() => title() === "Time zone", "zone chooser");
    assert(dom.text().includes("(*) UTC+02:00"), "current zone marked");
    dom.press("ArrowDown"); dom.press("Enter");                          // UTC+03:00
    await until(() => title() === "Settings" && dom.text().includes("Time zone: UTC+03:00"), "zone changed");
    assert.strictEqual(saved.tz, 180);
    dom.press("q"); await until(() => title() === "Live TV" && dom.text().includes("UTC+03:00"), "guide in the new zone");
    await until(() => dom.text().includes("News One") && dom.text().includes(fmt(serverHalf, 180)), "ruler moved to UTC+3");
    await app.close(); mock.close();
    console.log("epg-time: ALL OK"); process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
