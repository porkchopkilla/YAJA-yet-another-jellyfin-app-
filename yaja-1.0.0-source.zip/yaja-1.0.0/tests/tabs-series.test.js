"use strict";
// L / R tab cycling (Home, Movies, Shows, Settings) and the two-pane series screen.
const assert = require("assert");
const dom = require("./fake-dom.js")();
global.JF = {};
for (const f of ["http", "dns", "hls", "h264-sps", "ts-demux", "jellyfin-api", "player", "diagnostics", "ui-kit", "app"]) require("../app/src/" + f + ".js");
const transport = require("./node-transport.js")();
const startMock = require("./mock-jellyfin.js");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function until(cond, label, ms = 15000) { const end = Date.now() + ms; while (!cond()) { if (Date.now() > end) throw new Error("Timed out: " + label + "\n" + dom.text().slice(0, 600)); await sleep(15); } }
const title = () => dom.body.children[0].children[0].children[1].textContent;
function focused() {
    let found = null;
    (function walk(n) { if (n.style && (n.style.backgroundColor === "#ffffff" && n.style.color === "#000000" || n.style.outline === "4px solid #ffffff")) found = found || n; n.children.forEach(walk); })(dom.body);
    return found ? found.textContent.trim() : null;
}
function activeTab() {                     // the tab pill drawn as the current tab
    let found = null;
    (function walk(n) { if (n.style && n.style.backgroundColor === JF.colors.accentDark && /^(Home|Movies|Shows|Settings)$/.test(n.textContent)) found = n.textContent; n.children.forEach(walk); })(dom.body);
    return found;
}
const ep = (id, n, season) => ({Id: id, Name: "Episode " + n, Type: "Episode", IndexNumber: n, ParentIndexNumber: season, SeriesName: "Test Show", SeriesId: "s1", RunTimeTicks: 13e9, Overview: "Overview " + n, ImageTags: {Primary: "t" + id}});

(async () => {
    const mock = await startMock({seconds: 3, extraViews: [{Id: "lib2", Name: "Shows", CollectionType: "tvshows"}], series: {
        seasons: [{Id: "sp", Name: "Specials", IndexNumber: 0}, {Id: "se2", Name: "Season 2", IndexNumber: 2}, {Id: "se1", Name: "Season 1", IndexNumber: 1}],
        episodes: {se1: [ep("a3", 3, 1), ep("a1", 1, 1), ep("a2", 2, 1)], se2: [ep("b2", 2, 2), ep("b1", 1, 2)], sp: [ep("x1", 1, 0)]}
    }});
    let saved = {server: "http://127.0.0.1:" + mock.port, host: "127.0.0.1", port: mock.port, token: "tok-123", userId: "u1", userName: "alice", deviceId: "dev-tabs"};
    const platform = {transport, sleep, storage: {load: () => saved, save: (d) => { saved = d; }}, createSink: () => ({setup() {}, videoFrame: () => true, audioFrame() {}, drainVideo() {}, drainAudio() {}, close() {}})};
    const app = JF.startApp(platform);
    await until(() => title() === "Home" && dom.text().includes("Libraries"), "home");
    assert.strictEqual(focused(), "Home", "Home tab focused (its focus highlight replaces the current-tab shading)");

    // R steps forward through the tabs and wraps; each tab shows the bar with itself highlighted.
    dom.press("e"); await until(() => title() === "Movies" && dom.text().includes("titles"), "R -> Movies");
    assert.strictEqual(activeTab(), "Movies"); assert(focused().startsWith("Test Movie"), "focus on the first title, not the tab bar: " + focused());
    dom.press("e"); await until(() => title() === "Shows" && dom.text().includes("titles"), "R -> Shows");
    assert.strictEqual(activeTab(), "Shows");
    dom.press("e"); await until(() => title() === "Settings", "R -> Settings");
    assert.strictEqual(activeTab(), "Settings"); assert(focused().includes("720p - 4 Mbps"), "focus on the first option: " + focused());
    dom.press("e"); await until(() => title() === "Home" && dom.text().includes("Libraries"), "R wraps to Home");
    dom.press("q"); await until(() => title() === "Settings", "L wraps back to Settings");
    dom.press("q"); await until(() => title() === "Shows", "L -> Shows");
    // B from a tab returns Home, not to the previous tab.
    dom.press("Escape"); await until(() => title() === "Home" && dom.text().includes("Libraries"), "B from Shows -> Home");
    dom.press("Escape"); await sleep(20);
    assert(dom.body.children.length === 0, "B on Home exits (Home is the root)");
    const app2 = JF.startApp(platform);
    await until(() => title() === "Home" && dom.text().includes("Libraries"), "home 2");

    // Y opens the Settings tab; changing an option keeps focus on it.
    dom.press("y"); await until(() => title() === "Settings", "Y -> Settings");
    for (let i = 0; i < 5; i++) dom.press("ArrowDown");
    assert(focused().startsWith("Auto-play next episode: On"));
    dom.press("Enter"); await sleep(20);
    assert(focused().startsWith("Auto-play next episode: Off"), "focus kept on the changed option: " + focused());
    dom.press("Enter"); await sleep(20);

    // About & credits.
    dom.press("y"); await until(() => title() === "Settings", "settings for about");
    for (let i = 0; i < 12; i++) dom.press("ArrowDown"); dom.press("Enter");
    await until(() => title() === "About & credits", "about screen");
    for (const t of ["YAJA (Yet another jellyfin app) 1.0.0", "unofficial client for Jellyfin media servers", "XITRIX - CivHomebrew", "XITRIX - Moonlight-CivSwitch", "Gezine - CivSwitch", "The Jellyfin project", "MIT licensed"])
        assert(dom.text().includes(t), "about shows " + t);
    dom.press("Escape"); await until(() => title() === "Settings", "back to settings");

    // Series: seasons left (Season 1, Season 2, Specials), episodes right (1, 2, 3).
    dom.press("q"); dom.press("q"); await until(() => title() === "Movies" && dom.text().includes("titles"), "to Movies");
    dom.press("ArrowRight"); dom.press("Enter");
    await until(() => title() === "Test Show" && dom.text().includes("Episode 3"), "series screen");
    const t = dom.text();
    assert(t.indexOf("Season 1") < t.indexOf("Season 2") && t.indexOf("Season 2") < t.indexOf("Specials"), "seasons in order, Specials last");
    assert(t.indexOf("1. Episode 1") < t.indexOf("2. Episode 2") && t.indexOf("2. Episode 2") < t.indexOf("3. Episode 3"), "episodes in order");
    assert(mock.log.some((l) => /\/Shows\/s1\/Episodes\?.*seasonId=se1/.test(l)), "Season 1 loaded first");
    assert(focused().startsWith("1. Episode 1"), "focus starts on episode 1: " + focused());
    // Look: gradient behind every episode row, the show's backdrop behind the panes,
    // a solid underline under the show name and a solid line between the panes.
    const all = []; (function walk(n) { all.push(n); n.children.forEach(walk); })(dom.body);
    assert.strictEqual(all.filter((n) => n.tagName === "IMG" && n.src === JF.gradientUrl).length, 3, "gradient behind each of the 3 episodes");
    await until(() => mock.log.some((l) => l.startsWith("GET /Items/s1/Images/Backdrop?format=Png&maxHeight=540")), "show backdrop requested");
    const backdropLayer = dom.body.children[0].children[3];
    assert.strictEqual(backdropLayer.style.display, "", "backdrop layer shown on the show page");
    await until(() => backdropLayer.children[0].src && backdropLayer.children[0].src.startsWith("data:image/png"), "backdrop image displayed");
    assert(all.some((n) => n.style && n.style.borderBottom === "4px solid #ffffff" && n.textContent === "Test Show"), "underlined show name");
    assert(all.some((n) => n.style && n.style.borderLeft === "3px solid #ffffff" && n.textContent.includes("1. Episode 1")), "divider between the panes");
    dom.press("ArrowUp"); assert(focused().startsWith("1. Episode 1"), "up at the first episode stays");
    dom.press("ArrowDown"); assert(focused().startsWith("2. Episode 2"));
    dom.press("ArrowRight"); assert(focused().startsWith("2. Episode 2"), "right in the episode pane stays");
    dom.press("ArrowLeft"); assert.strictEqual(focused(), "Season 1", "left goes to the selected season");
    dom.press("ArrowDown"); assert.strictEqual(focused(), "Season 2");
    dom.press("ArrowRight"); assert(focused().startsWith("1. Episode 1"), "right from a season goes to the episodes");
    dom.press("ArrowLeft"); dom.press("ArrowDown"); dom.press("Enter");                   // select Season 2
    await until(() => dom.text().includes("1. Episode 1") && dom.text().includes("2. Episode 2") && !dom.text().includes("3. Episode 3"), "season 2 episodes");
    assert(focused().startsWith("1. Episode 1"), "focus moves to season 2's first episode");
    dom.press("ArrowLeft"); assert.strictEqual(focused(), "Season 2", "season 2 is now the selected season");
    dom.press("ArrowDown"); assert.strictEqual(focused(), "Specials"); dom.press("ArrowDown"); assert.strictEqual(focused(), "Specials", "down at the last season stays");
    dom.press("ArrowRight"); dom.press("Enter");
    await until(() => dom.text().includes("S2 - E1"), "Season 2 episode 1 details opened from the pane");
    const layer = dom.body.children[0].children[3];
    assert.strictEqual(layer.style.display, "", "the episode page uses the full-screen backdrop");
    await until(() => mock.log.some((l) => l.startsWith("GET /Items/b1/Images/Primary?format=Png&maxHeight=540")), "the episode's own still, at screen size");
    assert(!mock.log.some((l) => l.startsWith("GET /Items/s1/Images/Backdrop?format=Png&maxHeight=540") && mock.log.indexOf(l) > mock.log.findIndex((x) => x.includes("/Items/b1/Images/Primary"))), "not the show's backdrop");
    assert.strictEqual(layer.children[2].style.display, "", "with the bottom fade for its text");
    await app2.close(); mock.close();
    console.log("tabs-series: ALL OK"); process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
