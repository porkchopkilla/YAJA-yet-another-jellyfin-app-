"use strict";
// Mash the D-pad around a large library and check stability and bounded artwork.
const assert = require("assert");
const dom = require("./fake-dom.js")();
global.JF = {};
for (const f of ["http", "dns", "hls", "h264-sps", "ts-demux", "jellyfin-api", "player", "diagnostics", "ui-kit", "app"]) require("../app/src/" + f + ".js");
const transport = require("./node-transport.js")();
const startMock = require("./mock-jellyfin.js");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
(async () => {
    const mock = await startMock({seconds: 7, libraryItems: 150});
    let saved = {server: "http://127.0.0.1:" + mock.port, host: "127.0.0.1", port: mock.port, token: "tok-123", userId: "u1", userName: "alice", deviceId: "d"};
    const errors = []; process.on("uncaughtException", (e) => errors.push(e));
    const app = JF.startApp({transport, sleep, storage: {load: () => saved, save: (d) => { saved = d; }}, createSink() { throw new Error("no sink"); }});
    const end = Date.now() + 8000; while (!dom.text().includes("Libraries") && Date.now() < end) await sleep(20);
    // Open the library (last row on Home).
    for (let i = 0; i < 6; i++) dom.press("ArrowDown"); dom.press("Enter");
    while (!dom.text().includes("150 titles - A-Z") && Date.now() < end) await sleep(20);
    assert(dom.text().includes("150 titles - A-Z"), "library opened");
    const imgs = () => { const out = []; (function walk(n) { if (n.tagName === "IMG") out.push(n); n.children.forEach(walk); })(dom.body); return out; };
    const moves = ["ArrowRight", "ArrowRight", "ArrowDown", "ArrowLeft", "ArrowUp", "ArrowUp", "ArrowDown", "ArrowDown", "ArrowRight", "ArrowDown", "ArrowDown", "ArrowLeft"];
    let maxShown = 0;
    for (let round = 0; round < 25; round++) {
        for (const m of moves) { dom.press(m); await sleep(2); }
        await sleep(15);
        maxShown = Math.max(maxShown, imgs().filter((i) => i.src).length);
    }
    const total = imgs().length;
    console.log("library cards:", total, "max images held at once:", maxShown);
    assert(total >= 60, "pages loaded while scrolling");
    assert(maxShown <= 4 * 6, "only rows near the focus hold images");
    assert.strictEqual(errors.length, 0, "no uncaught errors: " + errors.map((e) => e.message).join("; "));
    await app.close(); mock.close();
    console.log("navigation: ALL OK"); process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
