"use strict";
// Live HLS: start near the live edge, follow a growing EVENT playlist, end on ENDLIST.
const assert = require("assert");
global.window = global; global.JF = {};
for (const f of ["http", "hls", "h264-sps", "ts-demux", "jellyfin-api", "player"]) require("../app/src/" + f + ".js");
const transport = require("./node-transport.js")();
const startMock = require("./mock-jellyfin.js");
(async () => {
    const SPEED = 4;
    const mock = await startMock({seconds: 3, live: true, liveSeconds: 20, liveSpeed: SPEED, liveEnds: true});
    const api = JF.jellyfin.create({transport, host: "127.0.0.1", port: mock.port, token: "tok-123", userId: "u1"});
    const info = await api.liveTvInfo(); assert.strictEqual(info.IsEnabled, true);
    const ch = await api.channels(0, 50); assert.strictEqual(ch.total, 3);
    const now = new Date(), progs = await api.programs(["ch1", "ch2", "ch3"], new Date(now - 30 * 60000), new Date(+now + 3 * 3600000));
    assert(progs.some((p) => p.ChannelId === "ch1") && progs.some((p) => p.ChannelId === "ch2") && !progs.some((p) => p.ChannelId === "ch3"));
    const settings = {videoBitrate: 4e6, maxWidth: 1280, maxHeight: 720};
    const stream = await api.openLiveStream("ch1", settings);
    assert.deepStrictEqual(stream, {mediaSourceId: "ms-ch1", liveStreamId: "ls-ch1", playSessionId: "ps-live"});
    const body = JSON.parse(mock.log.find((l) => l.startsWith("PLAYBACKINFO ")).slice(13));
    assert.strictEqual(body.AutoOpenLiveStream, true); assert.strictEqual(body.UserId, "u1");
    const path = api.livePlaylistPath("ch1", stream, settings);
    for (const k of ["LiveStreamId=ls-ch1", "MediaSourceId=ms-ch1", "VideoCodec=h264", "AudioCodec=opus", "SegmentContainer=ts", "profile=baseline", "DeInterlace=true"]) assert(path.includes(k), k);

    const t0 = Date.now(), clock = () => t0 + (Date.now() - t0) * SPEED, logs = [], fed = {video: 0, audio: 0};
    const sink = {setup() {}, videoFrame: () => { fed.video++; return true; }, audioFrame: () => { fed.audio++; }, drainVideo() {}, drainAudio() {}, close() {}};
    const p = JF.player.create({api, sink, transport, now: clock, sleep: (ms) => new Promise((r) => setTimeout(r, ms / SPEED)), log: (m) => logs.push(m)});
    await p.load(path, 0);
    assert(p.live(), "detected as live");
    const before = p.position(); p.seek(0); assert.strictEqual(p.position(), before, "seek ignored while live");
    await new Promise((resolve, reject) => {
        const t = setInterval(() => { p.tick(); if (p.state() === "ended") { clearInterval(t); resolve(); } if (p.state() === "error") { clearInterval(t); reject(p.error()); } }, 4);
        setTimeout(() => { clearInterval(t); reject(new Error("timeout: " + p.state() + " " + logs.join(" | "))); }, 30000);
    });
    const segs = mock.log.filter((l) => /hls\/live1\/\d+\.ts/.test(l)).map((l) => Number(/live1\/(\d+)\.ts/.exec(l)[1]));
    const refreshes = mock.log.filter((l) => l.startsWith("GET /Videos/ch1/live.m3u8")).length;
    console.log("started:", logs.find((l) => l.startsWith("Live stream")), "| segments fetched:", segs.join(","), "| playlist reads:", refreshes, "| frames:", fed.video, "audio:", fed.audio, "| stalls:", p.stats.stalls);
    assert.strictEqual(segs[0], 1, "starts 3 segments behind the edge (4 available -> segment 1)");
    assert.deepStrictEqual(segs, Array.from({length: 9}, (_, i) => i + 1), "every later segment fetched once, in order");
    assert(refreshes >= 4, "playlist re-read as it grew");
    assert(fed.video >= 9 * 2 * 30 - 4, "video for 18 s of live playback");
    assert.strictEqual(p.stats.stalls, 0, "no stalls when following the live edge");
    mock.close();
    console.log("live: ALL OK"); process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
