"use strict";
const assert = require("assert");
global.window = global; global.JF = {};
require("../app/src/native-sink.js");
const created = [];
global.MoonlightNativeTexture = {};
global.MoonlightStreamMedia = {create(io, core, options) {
    const m = {options, closed: false, audio: 0,
        videoSetup() { if (!options.synchronousGpu) throw new Error("GPU sync pointer range rejected"); return 0; },
        audioSetup() { m.audio++; return 0; }, close() { m.closed = true; }, videoFrame() { return 0; }, drainVideo() {}, finishVideo() {}, drainAudio() {}, stats() { return {}; }};
    created.push(m); return m;
}};
const logs = [];
const sink = JF.createNativeSink({}, new Uint8Array(8 * 1048576), 1048576, {log: (m) => logs.push(m)});
sink.setup({width: 1280, height: 720});
assert.strictEqual(created.length, 2, "async attempt, then synchronous");
assert(created[0].closed && created[0].options.synchronousGpu === false, "failed async media closed");
assert(created[1].options.synchronousGpu === true && created[1].audio === 1, "sync media in use with audio");
assert(logs.some((l) => /synchronous presentation/.test(l)), "fallback logged: " + logs.join(" | "));
assert(sink.videoFrame({data: new Uint8Array(100), pts: 9000, sps: new Uint8Array([0x67, 1, 2, 3]), pps: new Uint8Array([0x68, 1])}));
sink.setup({width: 1280, height: 720});
assert.strictEqual(created.length, 3, "later sessions go straight to synchronous");
assert(created[1].closed && created[2].options.synchronousGpu === true);
// Unrelated errors are not swallowed.
delete global.__jellyfinSyncGpu;
global.MoonlightStreamMedia.create = () => ({videoSetup() { throw new Error("Unsupported H.264 renderer dimensions"); }, close() {}});
assert.throws(() => sink.setup({width: 4000, height: 3000}), /Unsupported H.264/);
console.log("sink-fallback: ALL OK");
