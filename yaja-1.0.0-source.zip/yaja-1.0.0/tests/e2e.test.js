"use strict";
const assert = require("assert");
global.JF = {};
require("../app/src/http.js"); require("../app/src/hls.js"); require("../app/src/h264-sps.js"); require("../app/src/ts-demux.js");
const jellyfin = require("../app/src/jellyfin-api.js"); const player = require("../app/src/player.js");
const transport = require("./node-transport.js")();
const startMock = require("./mock-jellyfin.js");

(async () => {
    const mock = await startMock({seconds: 13});
    const api = jellyfin.create({transport, host: "127.0.0.1", port: mock.port, deviceId: "dev1"});
    assert.strictEqual((await api.publicInfo()).ServerName, "Mock");
    await assert.rejects(api.login("alice", "wrong"), (e) => e.status === 401);
    const who = await api.login("alice", "secret");
    assert.strictEqual(who.userId, "u1");
    assert.strictEqual(await api.quickConnectEnabled(), true);
    const qc = await api.quickConnectStart(); assert.strictEqual(qc.Code, "123456");
    assert.strictEqual((await api.quickConnectState(qc.Secret)).Authenticated, true);
    assert.strictEqual((await api.views())[0].Name, "Movies");
    const lib = await api.library("lib1"); assert.strictEqual(lib.total, 2);
    assert.strictEqual((await api.resume())[0].Id, "m1");
    const img = await api.fetchImage("m1", "Primary", "t1", 360);
    assert(img.startsWith("data:image/png;base64,iVBORw0KGgo"), "png data url");
    const item = await api.item("m1");

    // Full playback through the real player with a recording sink and an 8x clock.
    const t0 = Date.now(), SPEED = 8, now = () => t0 + (Date.now() - t0) * SPEED;
    const calls = {setup: [], video: [], audio: 0, drains: 0, closes: 0}; let busy = 0;
    const sink = {
        setup: (s) => calls.setup.push(s),
        videoFrame: (au) => { if (busy++ % 7 === 3) return false; calls.video.push(au.dts); return true; }, // simulate a busy decoder now and then
        audioFrame: () => { calls.audio++; }, drainVideo: () => { calls.drains++; }, drainAudio: () => {}, close: () => { calls.closes++; }
    };
    const states = [], logs = [];
    const p = player.create({api, sink, transport, now, sleep: (ms) => new Promise((r) => setTimeout(r, ms / SPEED)), onState: (s) => states.push(s), log: (m) => logs.push(m)});
    const master = api.masterPlaylistPath(item, {videoBitrate: 4000000, maxWidth: 1280, maxHeight: 720});
    assert(master.path.includes("VideoCodec=h264") && master.path.includes("AudioCodec=opus") && master.path.includes("SegmentContainer=ts") && master.path.includes("MediaSourceId=ms1"));
    await p.load(master.path, 0);
    const positions = [];
    await new Promise((resolve, reject) => {
        const timer = setInterval(() => {
            p.tick(); positions.push(p.position());
            if (p.state() === "ended") { clearInterval(timer); resolve(); }
            if (p.state() === "error") { clearInterval(timer); reject(p.error()); }
        }, 4);
        setTimeout(() => { clearInterval(timer); reject(new Error("timeout; state=" + p.state() + " logs=" + logs.join(" | "))); }, 20000);
    });
    console.log("states:", states.join(" > "));
    console.log("stats:", JSON.stringify(p.stats));
    assert.deepStrictEqual(calls.setup, [{width: 1280, height: 720}]);
    const expectedFrames = 13 * 24;
    assert(Math.abs(calls.video.length - expectedFrames) <= 2, "all frames fed: " + calls.video.length);
    for (let i = 1; i < calls.video.length; i++) assert(calls.video[i] > calls.video[i - 1], "decode order preserved");
    assert(calls.audio >= 640, "audio packets fed: " + calls.audio);
    assert.strictEqual(p.stats.audioDropped, 0, "no audio dropped in steady playback");
    for (let i = 1; i < positions.length; i++) assert(positions[i] >= positions[i - 1] - 1e-9, "position monotonic");
    assert(states.includes("playing") && states[states.length - 1] === "ended");
    assert(mock.log.some((l) => l.startsWith("GET /Videos/m1/main.m3u8?")), "followed master -> variant");
    assert.strictEqual(mock.log.filter((l) => /hls1\/main\/\d+\.ts/.test(l)).length, mock.segs.length, "fetched every segment once");

    // Seek into the second segment, then pause/resume.
    calls.video.length = 0; calls.setup.length = 0; states.length = 0;
    await p.load(master.path, 0);
    await new Promise((r) => { const t = setInterval(() => { p.tick(); if (p.state() === "playing") { clearInterval(t); r(); } }, 4); });
    p.seek(7.5);
    await new Promise((r) => { const t = setInterval(() => { p.tick(); if (p.state() === "playing") { clearInterval(t); r(); } }, 4); });
    assert(p.position() >= 6 && p.position() < 9, "seek landed in segment 2: " + p.position());
    p.pause(); const frozen = p.position(); await new Promise((r) => setTimeout(r, 60)); p.tick();
    assert.strictEqual(p.position(), frozen, "position frozen while paused");
    p.resume(); await new Promise((r) => setTimeout(r, 60)); p.tick();
    assert(p.position() > frozen, "position advances after resume");
    p.stop(); assert.strictEqual(p.state(), "stopped");
    await api.reportStopped({itemId: "m1", mediaSourceId: master.mediaSourceId, playSessionId: master.playSessionId, position: 12});
    await api.stopTranscode(master.playSessionId);
    mock.close();
    console.log("e2e: ALL OK");
})().catch((e) => { console.error(e); process.exit(1); });
