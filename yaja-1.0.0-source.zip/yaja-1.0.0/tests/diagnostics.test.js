"use strict";
const assert = require("assert");
global.window = global; global.JF = {};
const D = require("../app/src/diagnostics.js");

// Drive a monitor through N seconds of synthetic counters.
function simulate(seconds, perSecond, ticksPerSecond, gapOf) {
    let t = 0;
    const m = D.create({now: () => t, recordSeconds: seconds});
    const cum = {player: {videoFed: 0, lateFrames: 0, videoSkipped: 0, stalls: 0, audioFed: 0, audioDropped: 0, bytes: 0},
        sink: {decoded: 0, presented: 0, videoSuperseded: 0, videoExpired: 0, videoBacklogDrops: 0, audioEmptyEpisodes: 0, audioEmptyMs: 0, decodeMs: 0, decodeSamples: 0, gpuTransferMs: 0, gpuTransfers: 0, intervalCount: 0, intervalMs: 0, intervalSquaredMs: 0}};
    let rows = null;
    m.second(Object.assign({buffer: 10, playing: true, slice: 0, lead: 30, latency: 0.07}, cum));       // primes
    m.record((r) => { rows = r; });
    for (let sec = 0; sec < seconds; sec++) {
        for (let k = 0; k < ticksPerSecond; k++) { t += gapOf(sec, k); m.tick(perSecond.buffer !== undefined ? perSecond.buffer(sec) : 10); }
        const p = perSecond.fn(sec);
        for (const k in p.player || {}) cum.player[k] = typeof p.player[k] === "boolean" ? p.player[k] : (cum.player[k] || 0) + p.player[k];
        for (const k in p.sink || {}) cum.sink[k] += p.sink[k];
        m.second({player: cum.player, sink: cum.sink, slice: p.slice || 0, buffer: 10, playing: true, lead: 30, latency: 0.07});
    }
    return {rows, recent: m.recent()};
}
const steady = (fps, interval, jitter) => () => ({player: {videoFed: fps, audioFed: 50, bytes: 500000}, sink: {decoded: fps, presented: fps, decodeMs: fps * 6, decodeSamples: fps, gpuTransferMs: fps * 2, gpuTransfers: fps,
    intervalCount: fps, intervalMs: fps * interval, intervalSquaredMs: fps * (interval * interval + jitter * jitter)}});
const even = () => 1000 / 60;

// Steady 24 fps film.
let r = simulate(30, {fn: steady(24, 41.7, 2)}, 60, even);
assert.strictEqual(r.rows.length, 30, "30 rows recorded");
assert(Math.abs(r.recent.shownFps - 24) < 0.01 && Math.abs(r.recent.intervalJitter - 2) < 0.01, "rolling values");
let out = D.formatReport(r.rows, {version: "t", item: "Film", sourceFps: 23.976, server: {Framerate: 70, HardwareAccelerationType: "vaapi"}, mode: "asynchronous"});
console.log("steady film ->", out.findings[0].slice(0, 70));
assert(/60 Hz screen's cadence/.test(out.findings[0]) && out.findings.length === 1);
// The field report (Modern Family): 24 fps at 41.7 ms +/- 8.3 ms is the screen's cadence, not a fault.
r = simulate(30, {fn: steady(24, 41.7, 8.3)}, 60, even);
out = D.formatReport(r.rows, {version: "t", item: "Finding Fizbo", sourceFps: 23.976});
console.log("field 24 fps cadence ->", out.findings[0].slice(0, 80));
assert(!out.findings.some((f) => /^UNEVEN/.test(f)), "8.3 ms at 24 fps is not flagged");
// Real unevenness on top of the cadence is still flagged, and 30 fps has no cadence allowance.
r = simulate(10, {fn: steady(24, 41.7, 14)}, 60, even);
assert(D.formatReport(r.rows, {version: "t", item: "x", sourceFps: 24}).findings.some((f) => /^UNEVEN/.test(f)));
r = simulate(10, {fn: steady(30, 33.3, 6)}, 60, even);
assert(D.formatReport(r.rows, {version: "t", item: "x", sourceFps: 29.97}).findings.some((f) => /^UNEVEN/.test(f)));
assert(out.text.includes("PER SECOND") && out.text.split("\n").filter((l) => /^\s+\d+\s+24/.test(l)).length === 30, "30 per-second lines");

// Server slower than real time.
out = D.formatReport(r.rows, {version: "t", item: "x", sourceFps: 24, server: {Framerate: 14.2, HardwareAccelerationType: "none"}});
console.log("slow server ->", out.findings[0].slice(0, 70)); assert(/^SERVER TOO SLOW/.test(out.findings[0]) && /no hardware acceleration/.test(out.findings[0]));

// Starving buffer.
r = simulate(10, {fn: (s) => Object.assign(steady(24, 41.7, 2)(), s === 4 ? {player: {stalls: 1, videoFed: 10}} : {}), buffer: (s) => s >= 4 ? 0.3 : 8}, 60, even);
out = D.formatReport(r.rows, {version: "t", item: "x", sourceFps: 24});
console.log("starving ->", out.findings[0].slice(0, 70)); assert(/^STARVING/.test(out.findings[0]));

// Long loop pauses caused by download processing vs. by something else.
const hitchy = (s, k) => (k % 20 === 0 ? 140 : 1000 / 60);
r = simulate(10, {fn: (s) => Object.assign(steady(24, 41.7, 15)(), {slice: 120})}, 60, hitchy);
out = D.formatReport(r.rows, {version: "t", item: "x", sourceFps: 24});
console.log("download hitches ->", out.findings[0].slice(0, 70)); assert(/^CONSOLE BUSY WITH THE STREAM/.test(out.findings[0]));
r = simulate(10, {fn: () => Object.assign(steady(24, 41.7, 15)(), {slice: 8})}, 60, hitchy);
out = D.formatReport(r.rows, {version: "t", item: "x", sourceFps: 24, mode: "synchronous"});
console.log("other hitches ->", out.findings[0].slice(0, 70)); assert(/^FRAME LOOP BLOCKED ELSEWHERE/.test(out.findings[0]) && /synchronous/.test(out.findings[0]));
assert(out.findings.some((f) => /^UNEVEN SPACING/.test(f)), "jitter reported");

// Decoded but replaced before shown, and a slow decoder.
r = simulate(10, {fn: () => ({player: {videoFed: 24}, sink: {decoded: 24, presented: 16, videoSuperseded: 8, intervalCount: 16, intervalMs: 16 * 62, intervalSquaredMs: 16 * (62 * 62 + 20 * 20)}})}, 60, even);
out = D.formatReport(r.rows, {version: "t", item: "x", sourceFps: 24});
assert(out.findings.some((f) => /^FRAMES REPLACED BEFORE SHOWN: 80/.test(f)), out.findings.join(" | "));
r = simulate(10, {fn: () => ({player: {videoFed: 24}, sink: {decoded: 15, presented: 15, decodeMs: 15 * 70, decodeSamples: 15}})}, 60, even);
out = D.formatReport(r.rows, {version: "t", item: "x", sourceFps: 24});
assert(out.findings.some((f) => /^DECODER BEHIND: 15.0/.test(f)), out.findings.join(" | "));
// B-frames in the stream with frames replaced: named first, header says so.
r = simulate(10, {fn: () => ({player: {videoFed: 24, bframes: true}, sink: {decoded: 24, presented: 12, videoSuperseded: 12, intervalCount: 12, intervalMs: 12 * 83.3, intervalSquaredMs: 12 * (83.3 * 83.3 + 40 * 40)}})}, 60, even);
out = D.formatReport(r.rows, {version: "t", item: "x", sourceFps: 23.976, stream: "960x720 H.264"});
console.log("field report pattern ->", out.findings[0].slice(0, 70));
assert(/^B-FRAMES IN THE STREAM/.test(out.findings[0]) && out.text.includes("B-frames: yes"));
r = simulate(5, {fn: steady(24, 41.7, 2)}, 60, even);
assert(D.formatReport(r.rows, {version: "t", item: "x", sourceFps: 24}).text.includes("B-frames: no"));
console.log("diagnostics: ALL OK");
