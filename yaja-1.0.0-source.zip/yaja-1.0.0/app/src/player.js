/* Playback engine: HLS (MPEG-TS) download -> demux -> timed delivery to a media sink.
 * Platform-independent; the sink, clock, scheduler and API are injected.
 *
 * Sink interface:
 *   setup({width, height})            once per session, before the first frame
 *   videoFrame(au) -> boolean         false = decoder busy, retry later
 *   audioFrame(packet)
 *   drainVideo() / drainAudio()       called every tick
 *   close()                           release native resources (sink may be reused)
 *
 * The native audio path keeps only ~60 ms of PCM and drops anything fed faster
 * than real time, so audio is released by timestamp, never in bulk. */
/* Credits: the sink interface (videoSetup/videoFrame/audioFrame/drain) is shaped
 * around XITRIX's MoonlightStreamMedia from Moonlight-CivSwitch, which does the
 * native decoding and output on the console. */
(function () {
    "use strict";
    var G = typeof window !== "undefined" ? window : globalThis;
    var JF = G.JF = G.JF || {};

    var START_BUFFER = 2.0;     // seconds buffered before (re)starting the clock
    var MAX_AHEAD = 24;         // stop downloading this far ahead of the playhead
    var EARLY_AHEAD = 6;        // ...but start with a short read-ahead and grow it, so the
                                // first seconds are not one long download burst (that is
                                // when the console's audio briefly ran dry in field reports)
    // The native presenter shows whichever frame finished decoding last, so each
    // frame must reach the decoder exactly as early as the decoder will delay it.
    // That delay (reordering + processing) is measured at runtime via sink.latency().
    var VIDEO_PER_TICK = 2;     // never hand over a burst that would skip frames
    var LIVE_EDGE_SEGMENTS = 3; // live streams start this many segments behind the newest
    var AUDIO_LEAD = 0.05;      // hand audio over this far before its time
    var LATE_AUDIO = 0.25;      // drop audio older than this
    var LATE_VIDEO = 1.5;       // beyond this, skip ahead to the next keyframe

    function create(deps) {
        var api = deps.api, sink = deps.sink, http = JF.http, hls = JF.hls, sps = JF.h264Sps, demuxer = JF.tsDemux;
        var now = deps.now || function () { return Date.now(); };
        var log = deps.log || function () {};
        var onState = deps.onState || function () {};

        var playlist = null, playlistPath = null, state = "idle", generation = 0, live = false;
        var videoQ = [], audioQ = [], ptsBase = null, sessionStart = 0, reorder = 0;
        var clockStart = null, clockPos = 0, paused = false, buffering = true, ended = false;
        var downloading = false, downloadDone = false, abort = {aborted: false};
        var configured = false, lastBuffered = 0, error = null, warnedAudio = false, duration = 0;
        var stats = {bframes: false, segments: 0, bytes: 0, videoFed: 0, audioFed: 0, audioDropped: 0, videoSkipped: 0, stalls: 0, maxTickGapMs: 0, lateFrames: 0};
        var videoInfo = null, lastTickAt = null, offsetSum = 0, offsetCount = 0, latency = null, latencyAt = -1e9;

        function setState(next, detail) {
            if (state === next && !detail) return;
            state = next;
            try { onState(next, detail || null); } catch (e) { log("state handler: " + e.message); }
        }

        function seconds(ts) { return (ts - ptsBase) / 90000 + sessionStart; }

        function position() {
            if (clockStart === null || paused || buffering) return clockPos;
            return clockPos + (now() - clockStart) / 1000;
        }

        function bufferedUntil() {
            var v = videoQ.length ? seconds(videoQ[videoQ.length - 1].pts) : null;
            var a = audioQ.length ? seconds(audioQ[audioQ.length - 1].pts) : null;
            if (v === null) return a === null ? position() : a;
            if (a === null) return v;
            return Math.min(v, a);
        }

        function freezeClock() { clockPos = position(); clockStart = null; }

        // ---- Download -------------------------------------------------------

        async function loadPlaylist(path, signal) {
            var text = await api.fetchText(path, signal);
            var variant = hls.firstVariant(text);
            if (variant) {
                playlistPath = hls.resolve(path, variant);
                text = await api.fetchText(playlistPath, signal);
            } else playlistPath = path;
            var parsed = hls.parsePlaylist(text);
            if (parsed.fmp4) throw new Error("Server sent fMP4 segments; MPEG-TS is required.");
            if (parsed.encrypted) throw new Error("Encrypted HLS is not supported.");
            if (!parsed.segments.length) throw new Error("The stream has no segments.");
            return parsed;
        }

        async function download(fromIndex, myGeneration, signal) {
            downloading = true; downloadDone = false;
            try {
                for (var i = fromIndex; ; i++) {
                    if (i >= playlist.segments.length) {
                        if (!live || playlist.endList) break;
                        // Live (EVENT or sliding) playlist: wait for the next segment, re-read it,
                        // and continue from the same sequence number.
                        var sequence = playlist.mediaSequence + i;
                        await deps.sleep(Math.max(1000, (playlist.targetDuration || 3) * 500));
                        if (signal.aborted || myGeneration !== generation) return;
                        var fresh = hls.parsePlaylist(await api.fetchText(playlistPath, signal));
                        if (fresh.fmp4 || fresh.encrypted) throw new Error("The live stream changed to an unsupported format.");
                        if (sequence < fresh.mediaSequence) log("Live playlist moved past segment " + sequence + "; continuing from " + fresh.mediaSequence + ".");
                        playlist = fresh; duration = fresh.totalDuration;
                        i = Math.max(0, sequence - fresh.mediaSequence) - 1;   // the loop's i++ lands on it
                        continue;
                    }
                    // Back-pressure: wait while far enough ahead of the playhead.
                    while (!signal.aborted && bufferedUntil() - position() > aheadLimit()) await deps.sleep(250);
                    if (signal.aborted || myGeneration !== generation) return;
                    var segment = playlist.segments[i];
                    var path = hls.resolve(playlistPath, segment.uri);
                    var demux = demuxer.create({
                        onVideo: function (au) { if (myGeneration === generation) acceptVideo(au); },
                        onAudio: function (pkt) { if (myGeneration === generation) acceptAudio(pkt); },
                        onUnsupportedAudio: function (info) {
                            if (!warnedAudio) { warnedAudio = true; log("Audio stream type 0x" + info.streamType.toString(16) + " is not Opus; playing without sound."); }
                        }
                    });
                    var attempt = 0;
                    for (;;) {
                        try {
                            await deps.transport.request({
                                host: api.server.host, port: api.server.port, tls: api.server.tls, method: "GET", path: path,
                                headers: api.headers(), timeoutMs: 90000, signal: signal
                            }, {
                                onHead: function (head) { if (head.status !== 200) throw new Error("Segment request failed: HTTP " + head.status); },
                                onBody: function (chunk) { stats.bytes += chunk.length; demux.push(chunk); }
                            });
                            demux.end();
                            break;
                        } catch (e) {
                            if (signal.aborted || myGeneration !== generation) return;
                            // The first segment can take a while while the server starts transcoding.
                            if (++attempt >= 3) throw e;
                            log("Segment " + i + " retry " + attempt + ": " + e.message);
                            await deps.sleep(1000 * attempt);
                        }
                    }
                    stats.segments++;
                }
                if (myGeneration === generation) downloadDone = true;
            } finally {
                if (myGeneration === generation) downloading = false;
            }
        }

        // Read-ahead grows by half a second per second played: 6 s -> 24 s in ~36 s.
        function aheadLimit() {
            return Math.min(MAX_AHEAD, EARLY_AHEAD + Math.max(0, position() - sessionStart) * 0.5);
        }

        function acceptVideo(au) {
            if (ptsBase === null) ptsBase = Math.min(au.pts, au.dts);
            if (au.pts - au.dts > reorder) { reorder = au.pts - au.dts; stats.bframes = true; }
            offsetSum += (au.pts - au.dts) / 90000; offsetCount++;
            videoQ.push(au);
        }

        // How far ahead of a frame's decode timestamp to hand it over so that it is
        // shown on time: measured feed-to-display delay minus the stream's own
        // presentation offset. Before measurements exist, assume one frame of work.
        function videoLead() {
            var t = now();
            if (sink.latency && t - latencyAt > 500) {
                latencyAt = t;
                var measured = sink.latency();
                if (measured !== null && measured !== undefined && isFinite(measured)) latency = measured;
            }
            var offset = offsetCount ? offsetSum / offsetCount : 0;
            var expected = latency !== null ? latency : offset + 0.04;
            stats.videoLeadMs = Math.round((expected - offset) * 1000);
            return Math.max(-0.1, Math.min(0.6, expected - offset));
        }

        function acceptAudio(pkt) {
            if (ptsBase === null) ptsBase = pkt.pts;
            audioQ.push(pkt);
        }

        // ---- Delivery (called by the host's frame loop) ---------------------

        function ensureConfigured() {
            if (configured) return true;
            // Drop anything before the first decodable keyframe.
            while (videoQ.length && !(videoQ[0].keyframe && videoQ[0].sps && videoQ[0].pps)) { videoQ.shift(); stats.videoSkipped++; }
            if (!videoQ.length) return false;
            var info = sps.parse(videoQ[0].sps);
            if (info.width > 1920 || info.height > 1080) throw new Error("Stream is " + info.width + "x" + info.height + "; the console decoder supports up to 1920x1080.");
            sink.setup({width: info.width, height: info.height});
            configured = true; videoInfo = info;
            log("Video " + info.width + "x" + info.height + " (H.264 profile " + info.profile + ", level " + info.level + ")");
            return true;
        }

        function skipToKeyframe(pos) {
            for (var i = 1; i < videoQ.length; i++) {
                if (videoQ[i].keyframe && seconds(videoQ[i].pts) >= pos) {
                    stats.videoSkipped += i; videoQ.splice(0, i);
                    log("Video fell behind; skipped " + i + " frames to the next keyframe.");
                    return;
                }
            }
        }

        function tick() {
            if (state === "idle" || state === "error" || state === "stopped") return;
            var tickAt = now();
            if (lastTickAt !== null && state === "playing" && tickAt - lastTickAt > stats.maxTickGapMs) stats.maxTickGapMs = tickAt - lastTickAt;
            lastTickAt = tickAt;
            try {
                var ahead = bufferedUntil() - position();
                if (buffering) {
                    var ready = ahead >= START_BUFFER || (downloadDone && (videoQ.length || audioQ.length));
                    if (ready && !paused && ensureConfigured()) {
                        buffering = false; clockStart = now();
                        if (videoQ.length && clockPos < seconds(videoQ[0].pts) - 0.5) clockPos = Math.max(clockPos, seconds(videoQ[0].pts));
                        setState("playing");
                    } else if (downloadDone && !videoQ.length && !audioQ.length) { finish(); return; }
                    else { lastBuffered = ahead; return; }
                }
                if (paused) { sink.drainVideo(); return; }

                var pos = position();
                // Video: keep decode order; release once its presentation time is close.
                if (videoQ.length && seconds(videoQ[0].dts) + reorder / 90000 < pos - LATE_VIDEO) skipToKeyframe(pos);
                var fed = 0, lead = videoLead();
                while (videoQ.length && fed < VIDEO_PER_TICK && seconds(videoQ[0].dts) <= pos + lead) {
                    if (seconds(videoQ[0].dts) + reorder / 90000 < pos - 0.1) stats.lateFrames++;
                    if (!sink.videoFrame(videoQ[0])) break;
                    videoQ.shift(); stats.videoFed++; fed++;
                }
                sink.drainVideo();

                // Audio: drop late packets, release due ones.
                while (audioQ.length && seconds(audioQ[0].pts) < pos - LATE_AUDIO) { audioQ.shift(); stats.audioDropped++; }
                var released = 0;
                while (audioQ.length && released < 8 && seconds(audioQ[0].pts) <= pos + AUDIO_LEAD) {
                    sink.audioFrame(audioQ.shift()); stats.audioFed++; released++;
                }
                sink.drainAudio();

                if (!videoQ.length && !audioQ.length) {
                    if (downloadDone) { if (pos >= duration - 0.5 || !downloading) finish(); }
                    else { freezeClock(); buffering = true; stats.stalls++; setState("buffering"); }
                }
            } catch (e) { fail(e); }
        }

        // ---- Control --------------------------------------------------------

        function resetSession() {
            generation++; abort.aborted = true; abort = {aborted: false};
            videoQ = []; audioQ = []; ptsBase = null; reorder = 0; configured = false;
            offsetSum = 0; offsetCount = 0; latency = null; latencyAt = -1e9;
            downloadDone = false; downloading = false; buffering = true; clockStart = null;
            try { sink.close(); } catch (e) { log("sink close: " + e.message); }
        }

        function startAt(seconds_, forcedIndex) {
            resetSession();
            var index = forcedIndex !== undefined ? forcedIndex : hls.segmentAt(playlist, Math.max(0, seconds_));
            sessionStart = playlist.segments[index].start;
            clockPos = Math.max(seconds_, sessionStart);
            var myGeneration = generation, signal = abort;
            setState("buffering");
            download(index, myGeneration, signal).catch(function (e) { if (myGeneration === generation && !signal.aborted) fail(e); });
        }

        function fail(e) {
            error = e; log("Playback error: " + (e && e.message));
            resetSession(); setState("error", e);
        }

        function finish() {
            if (ended) return;
            ended = true; freezeClock(); resetSession(); setState("ended");
        }

        return {
            load: async function (path, startSeconds) {
                setState("loading");
                ended = false; error = null;
                try {
                    var signal = abort;
                    playlist = await loadPlaylist(path, signal);
                    duration = playlist.totalDuration;
                    live = !playlist.endList;
                    if (live) {
                        var edge = Math.max(0, playlist.segments.length - LIVE_EDGE_SEGMENTS);
                        log("Live stream: starting at segment " + (playlist.mediaSequence + edge) + " of " + (playlist.mediaSequence + playlist.segments.length));
                        startAt(playlist.segments[edge].start, edge);
                    } else startAt(startSeconds || 0);
                } catch (e) { fail(e); }
            },
            tick: tick,
            pause: function () { if (paused || state === "ended") return; freezeClock(); paused = true; setState("paused"); },
            resume: function () {
                if (!paused) return; paused = false;
                if (!buffering) { clockStart = now(); setState("playing"); } else setState("buffering");
            },
            toggle: function () { if (paused) this.resume(); else this.pause(); },
            seek: function (target) {
                if (!playlist || live) return;                          // no seeking in live TV
                target = Math.max(0, Math.min(duration - 1, target));
                ended = false; startAt(target);
            },
            stop: function () { resetSession(); setState("stopped"); },
            position: position,
            duration: function () { return duration; },
            buffered: function () { return Math.max(0, bufferedUntil() - position()); },
            state: function () { return state; },
            paused: function () { return paused; },
            error: function () { return error; },
            stats: stats,
            videoInfo: function () { return videoInfo; },
            live: function () { return live; }
        };
    }

    JF.player = {create: create};
    if (typeof module !== "undefined" && module.exports) module.exports = JF.player;
})();
