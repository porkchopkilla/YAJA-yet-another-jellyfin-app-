/* Minimal DNS client codec (RFC 1035): builds A-record queries and parses
 * responses, including name compression and CNAME chains. Pure logic; the
 * platform sends the bytes over UDP. */
(function () {
    "use strict";
    var G = typeof window !== "undefined" ? window : globalThis;
    var JF = G.JF = G.JF || {};

    function validName(name) {
        if (!name || name.length > 253) return false;
        var labels = name.replace(/\.$/, "").split(".");
        if (labels.length < 1) return false;
        for (var i = 0; i < labels.length; i++) {
            if (!/^[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?$/.test(labels[i])) return false;
        }
        return true;
    }

    // Query for name (type A, class IN, recursion desired).
    function buildQuery(id, name) {
        if (!validName(name)) throw new Error("Invalid server name: " + name);
        var labels = name.replace(/\.$/, "").split("."), size = 12 + 5;
        labels.forEach(function (l) { size += l.length + 1; });
        var out = new Uint8Array(size), o = 0;
        out[o++] = id >> 8 & 255; out[o++] = id & 255;
        out[o++] = 0x01; out[o++] = 0x00;            // RD
        out[o++] = 0; out[o++] = 1;                  // QDCOUNT 1
        o += 6;                                      // AN, NS, AR = 0
        labels.forEach(function (l) {
            out[o++] = l.length;
            for (var i = 0; i < l.length; i++) out[o++] = l.toLowerCase().charCodeAt(i);
        });
        out[o++] = 0;
        out[o++] = 0; out[o++] = 1;                  // QTYPE A
        out[o++] = 0; out[o++] = 1;                  // QCLASS IN
        return out;
    }

    // Reads a (possibly compressed) name at offset. Returns {name, next}.
    function readName(b, offset) {
        var labels = [], jumped = false, next = offset, hops = 0;
        for (;;) {
            if (offset >= b.length) throw new Error("DNS name runs past the message");
            var len = b[offset];
            if ((len & 0xc0) === 0xc0) {
                if (offset + 1 >= b.length) throw new Error("Truncated DNS pointer");
                if (++hops > 16) throw new Error("DNS compression loop");
                var ptr = ((len & 0x3f) << 8) | b[offset + 1];
                if (!jumped) next = offset + 2;
                jumped = true; offset = ptr; continue;
            }
            if (len & 0xc0) throw new Error("Unsupported DNS label type");
            if (len === 0) { if (!jumped) next = offset + 1; break; }
            if (offset + 1 + len > b.length) throw new Error("Truncated DNS label");
            var label = "";
            for (var i = 1; i <= len; i++) label += String.fromCharCode(b[offset + i]);
            labels.push(label); offset += 1 + len;
        }
        return {name: labels.join(".").toLowerCase(), next: next};
    }

    var RCODES = {1: "format error", 2: "server failure", 3: "name does not exist", 4: "not implemented", 5: "refused"};

    // Returns {addresses: ["1.2.3.4", ...], ttl, cname} or throws with a readable reason.
    function parseResponse(b, id, name) {
        if (b.length < 12) throw new Error("DNS response too short");
        if ((b[0] << 8 | b[1]) !== id) throw new Error("DNS response for a different query");
        if (!(b[2] & 0x80)) throw new Error("Not a DNS response");
        if (b[2] & 0x02) throw new Error("DNS response truncated");
        var rcode = b[3] & 0x0f;
        if (rcode) { var e = new Error("DNS: " + (RCODES[rcode] || "error " + rcode)); e.rcode = rcode; throw e; }
        var qd = b[4] << 8 | b[5], an = b[6] << 8 | b[7], o = 12;
        for (var q = 0; q < qd; q++) { o = readName(b, o).next + 4; }
        var target = String(name).replace(/\.$/, "").toLowerCase(), cname = null, records = [];
        for (var a = 0; a < an; a++) {
            var owner = readName(b, o); o = owner.next;
            if (o + 10 > b.length) throw new Error("Truncated DNS record");
            var type = b[o] << 8 | b[o + 1], klass = b[o + 2] << 8 | b[o + 3];
            var ttl = ((b[o + 4] << 24) >>> 0) + (b[o + 5] << 16) + (b[o + 6] << 8) + b[o + 7];
            var rdlength = b[o + 8] << 8 | b[o + 9]; o += 10;
            if (o + rdlength > b.length) throw new Error("Truncated DNS record data");
            records.push({owner: owner.name, type: type, klass: klass, ttl: ttl, start: o, length: rdlength});
            o += rdlength;
        }
        // Follow CNAMEs from the queried name to its A records.
        var current = target, ttlMin = Infinity;
        for (var hop = 0; hop < 8; hop++) {
            var found = records.filter(function (r) { return r.owner === current && r.klass === 1; });
            var aRecords = found.filter(function (r) { return r.type === 1 && r.length === 4; });
            if (aRecords.length) {
                return {
                    addresses: aRecords.map(function (r) { return b[r.start] + "." + b[r.start + 1] + "." + b[r.start + 2] + "." + b[r.start + 3]; }),
                    ttl: Math.min(ttlMin, aRecords.reduce(function (m, r) { return Math.min(m, r.ttl); }, Infinity)),
                    cname: cname
                };
            }
            var alias = found.filter(function (r) { return r.type === 5; })[0];
            if (!alias) break;
            ttlMin = Math.min(ttlMin, alias.ttl);
            current = cname = readName(b, alias.start).name;
        }
        throw new Error("DNS: no IPv4 address for " + target);
    }

    JF.dns = {buildQuery: buildQuery, parseResponse: parseResponse, validName: validName};
    if (typeof module !== "undefined" && module.exports) module.exports = JF.dns;
})();
