/* MPEG-TS demuxer: H.264 (Annex-B access units) and Opus (raw packets).
 * Pure logic, no platform dependencies. Timestamps are 90 kHz ticks. */
(function () {
    "use strict";
    var G = typeof window !== "undefined" ? window : globalThis;
    var JF = G.JF = G.JF || {};
    var PACKET = 188;

    // Samples (at 48 kHz) in one Opus packet, from its TOC byte(s).
    function opusSamples(data) {
        if (!data || data.length < 1) return 0;
        var toc = data[0], config = toc >> 3, frame;
        if (config < 12) frame = [480, 960, 1920, 2880][config & 3];
        else if (config < 16) frame = [480, 960][config & 1];
        else frame = [120, 240, 480, 960][config & 3];
        var code = toc & 3, count;
        if (code === 0) count = 1;
        else if (code === 1 || code === 2) count = 2;
        else { if (data.length < 2) return 0; count = data[1] & 0x3f; }
        return frame * count;
    }

    function readTimestamp(b, o) {
        // 33-bit value split across 5 bytes; use arithmetic, not 32-bit shifts.
        return ((b[o] >> 1) & 7) * 1073741824 + (b[o + 1] << 22 | (b[o + 2] >> 1) << 15 | b[o + 3] << 7 | b[o + 4] >> 1) * 1;
    }

    function concat(parts, total) {
        if (parts.length === 1) return parts[0];
        var out = new Uint8Array(total), at = 0;
        for (var i = 0; i < parts.length; i++) { out.set(parts[i], at); at += parts[i].length; }
        return out;
    }

    // Walks Annex-B start codes. Calls visit(type, start, end) for each NAL
    // (start/end exclude the start code).
    function eachNal(data, visit) {
        var n = data.length, i = 0, start = -1;
        while (i + 2 < n) {
            if (data[i] === 0 && data[i + 1] === 0 && data[i + 2] === 1) {
                if (start >= 0) {
                    var end = i; while (end > start && data[end - 1] === 0) end--;
                    visit(data[start] & 0x1f, start, end);
                }
                start = i + 3; i += 3;
            } else i++;
        }
        if (start >= 0 && start < n) visit(data[start] & 0x1f, start, n);
    }

    function create(callbacks) {
        callbacks = callbacks || {};
        var carry = null, pmtPid = -1, videoPid = -1, audioPid = -1, unsupportedAudio = null;
        var streams = {};            // pid -> {kind, parts, total, expected, pts, dts}
        var stats = {packets: 0, resyncs: 0, video: 0, audio: 0};
        var sections = {};           // pid -> {parts, total} for PAT/PMT reassembly

        function emitVideo(stream) {
            var data = concat(stream.parts, stream.total);
            if (!data.length) return;
            var keyframe = false, sps = null, pps = null;
            eachNal(data, function (type, s, e) {
                if (type === 5) keyframe = true;
                else if (type === 7 && !sps) sps = data.subarray(s, e);
                else if (type === 8 && !pps) pps = data.subarray(s, e);
            });
            stats.video++;
            if (callbacks.onVideo) callbacks.onVideo({
                pts: stream.pts, dts: stream.dts === null ? stream.pts : stream.dts,
                data: data, keyframe: keyframe, sps: sps, pps: pps
            });
        }

        function emitAudio(stream) {
            var b = concat(stream.parts, stream.total), pos = 0, ts = stream.pts;
            while (pos + 3 <= b.length) {
                if (b[pos] !== 0x7f || (b[pos + 1] & 0xe0) !== 0xe0) break; // not an Opus control header
                var flags = b[pos + 1]; pos += 2;
                var size = 0, v;
                do { if (pos >= b.length) return; v = b[pos++]; size += v; } while (v === 255);
                if (flags & 0x10) pos += 2;           // start trim
                if (flags & 0x08) pos += 2;           // end trim
                if (flags & 0x04) { if (pos >= b.length) return; pos += 1 + b[pos]; } // control extension
                if (size < 1 || pos + size > b.length) return;
                var packet = b.subarray(pos, pos + size); pos += size;
                var samples = opusSamples(packet);
                stats.audio++;
                if (callbacks.onAudio) callbacks.onAudio({pts: ts, data: packet, samples: samples});
                ts += samples * 90000 / 48000;
            }
        }

        function flush(stream) {
            if (!stream || !stream.total) { if (stream) { stream.parts = []; stream.total = 0; } return; }
            try { if (stream.kind === "video") emitVideo(stream); else if (stream.kind === "audio") emitAudio(stream); }
            finally { stream.parts = []; stream.total = 0; stream.expected = 0; }
        }

        function parsePes(stream, payload) {
            // payload begins at the PES start code.
            if (payload.length < 9 || payload[0] !== 0 || payload[1] !== 0 || payload[2] !== 1) return null;
            var length = (payload[4] << 8) | payload[5], flags = payload[7], headerLength = payload[8];
            if (payload.length < 9 + headerLength) return null;
            stream.pts = null; stream.dts = null;
            if (flags & 0x80) stream.pts = readTimestamp(payload, 9);
            if (flags & 0x40) stream.dts = readTimestamp(payload, 14);
            stream.expected = length ? length + 6 : 0;
            return payload.subarray(9 + headerLength);
        }

        function addPes(pid, pusi, payload) {
            var stream = streams[pid];
            if (!stream) return;
            if (pusi) {
                flush(stream);
                var body = parsePes(stream, payload);
                if (!body) return;
                stream.parts = [body]; stream.total = body.length; stream.received = payload.length;
            } else {
                if (!stream.total && !stream.received) return;
                stream.parts.push(payload); stream.total += payload.length; stream.received += payload.length;
            }
            if (stream.expected && stream.received >= stream.expected) { flush(stream); stream.received = 0; }
        }

        function parseSection(pid, pusi, payload, handler) {
            var sec = sections[pid];
            if (pusi) {
                var pointer = payload[0]; payload = payload.subarray(1 + pointer);
                sec = sections[pid] = {parts: [], total: 0, need: -1};
            }
            if (!sec) return;
            sec.parts.push(payload); sec.total += payload.length;
            var data = concat(sec.parts, sec.total);
            if (sec.need < 0 && data.length >= 3) sec.need = 3 + (((data[1] & 0x0f) << 8) | data[2]);
            if (sec.need > 0 && data.length >= sec.need) { sections[pid] = null; handler(data.subarray(0, sec.need)); }
        }

        function onPat(section) {
            var end = section.length - 4;
            for (var o = 8; o + 4 <= end; o += 4) {
                var program = (section[o] << 8) | section[o + 1];
                if (program !== 0) { pmtPid = ((section[o + 2] & 0x1f) << 8) | section[o + 3]; return; }
            }
        }

        function onPmt(section) {
            var end = section.length - 4;
            var infoLength = ((section[10] & 0x0f) << 8) | section[11];
            var o = 12 + infoLength;
            while (o + 5 <= end) {
                var type = section[o], pid = ((section[o + 1] & 0x1f) << 8) | section[o + 2];
                var esLength = ((section[o + 3] & 0x0f) << 8) | section[o + 4];
                var isOpus = false;
                for (var d = o + 5; d + 2 <= o + 5 + esLength; ) {
                    var tag = section[d], len = section[d + 1];
                    if (tag === 0x05 && len >= 4 && section[d + 2] === 0x4f && section[d + 3] === 0x70 &&
                        section[d + 4] === 0x75 && section[d + 5] === 0x73) isOpus = true; // "Opus"
                    d += 2 + len;
                }
                if (type === 0x1b && videoPid < 0) {
                    videoPid = pid; streams[pid] = {kind: "video", parts: [], total: 0, expected: 0, received: 0, pts: null, dts: null};
                } else if (type === 0x06 && isOpus && audioPid < 0) {
                    audioPid = pid; streams[pid] = {kind: "audio", parts: [], total: 0, expected: 0, received: 0, pts: null, dts: null};
                } else if ((type === 0x0f || type === 0x11 || type === 0x03 || type === 0x04 || type === 0x81 || type === 0x87 || type === 0x06) && !isOpus && !unsupportedAudio) {
                    unsupportedAudio = {pid: pid, streamType: type};
                    if (callbacks.onUnsupportedAudio) callbacks.onUnsupportedAudio(unsupportedAudio);
                }
                o += 5 + esLength;
            }
            if (callbacks.onProgram) callbacks.onProgram({videoPid: videoPid, audioPid: audioPid});
        }

        function packet(b, o) {
            var pid = ((b[o + 1] & 0x1f) << 8) | b[o + 2];
            var pusi = (b[o + 1] & 0x40) !== 0, afc = (b[o + 3] >> 4) & 3;
            if (!(afc & 1)) return;                       // no payload
            var start = o + 4;
            if (afc & 2) start += 1 + b[o + 4];
            if (start >= o + PACKET) return;
            var payload = b.subarray(start, o + PACKET);
            stats.packets++;
            if (pid === 0) parseSection(0, pusi, payload, onPat);
            else if (pid === pmtPid) parseSection(pid, pusi, payload, onPmt);
            else if (streams[pid]) addPes(pid, pusi, payload);
        }

        function push(chunk) {
            var b = chunk;
            if (carry && carry.length) {
                b = new Uint8Array(carry.length + chunk.length);
                b.set(carry, 0); b.set(chunk, carry.length);
            }
            var o = 0, n = b.length;
            while (o + PACKET <= n) {
                if (b[o] !== 0x47) {                       // resynchronize on the next confirmed sync byte
                    var next = -1;
                    for (var s = o + 1; s + PACKET < n; s++) if (b[s] === 0x47 && b[s + PACKET] === 0x47) { next = s; break; }
                    stats.resyncs++;
                    if (next < 0) { o = n; break; }
                    o = next; continue;
                }
                packet(b, o); o += PACKET;
            }
            carry = o < n ? b.slice(o) : null;
        }

        function end() { for (var pid in streams) flush(streams[pid]); }
        return {push: push, end: end, stats: stats, program: function () { return {videoPid: videoPid, audioPid: audioPid, unsupportedAudio: unsupportedAudio}; }};
    }

    JF.tsDemux = {create: create, opusSamples: opusSamples, eachNal: eachNal};
    if (typeof module !== "undefined" && module.exports) module.exports = JF.tsDemux;
})();
