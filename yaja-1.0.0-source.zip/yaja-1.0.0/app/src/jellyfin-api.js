/* Jellyfin REST client. Routes and field names checked against the Jellyfin
 * server source (Jellyfin.Api controllers). Platform-independent: all I/O goes
 * through an injected transport (see http.js). */
/* Credits: endpoints, parameters and DTO field names were checked against the
 * Jellyfin server source (https://github.com/jellyfin/jellyfin). This is an
 * independent, unofficial client. */
(function () {
    "use strict";
    var G = typeof window !== "undefined" ? window : globalThis;
    var JF = G.JF = G.JF || {};
    var TICKS = 10000000; // Jellyfin ticks per second

    function query(params) {
        var parts = [];
        for (var k in params) {
            if (!Object.prototype.hasOwnProperty.call(params, k)) continue;
            var v = params[k];
            if (v === undefined || v === null || v === "") continue;
            parts.push(encodeURIComponent(k) + "=" + encodeURIComponent(String(v)));
        }
        return parts.length ? "?" + parts.join("&") : "";
    }

    function quote(value) { return '"' + String(value).replace(/["\\\r\n]/g, "") + '"'; }

    function randomHex(n) {
        var s = "";
        for (var i = 0; i < n; i++) s += Math.floor(Math.random() * 16).toString(16);
        return s;
    }

    function create(options) {
        var http = JF.http;
        var transport = options.transport;
        var server = {host: options.host, port: options.port || 8096, tls: !!options.tls, basePath: options.basePath || ""};
        // Server clock: each reply's Date header gives the offset to the console's clock.
        var clockOffset = 0, clockSynced = false;
        function noteServerTime(headers) {
            var t = headers && headers.date ? Date.parse(headers.date) : NaN;
            if (!isFinite(t)) return;
            // Date has 1 s resolution; the true time is within [t, t + 1000).
            clockOffset = t + 500 - Date.now(); clockSynced = true;
        }
        function full(path) { return server.basePath + path; }
        var session = {token: options.token || null, userId: options.userId || null};
        var device = {
            client: options.client || "YAJA",
            name: options.deviceName || "Nintendo Switch",
            id: options.deviceId || ("civswitch-" + randomHex(16)),
            version: options.version || "0.1.0"
        };

        function authorization() {
            var value = "MediaBrowser Client=" + quote(device.client) + ", Device=" + quote(device.name) +
                ", DeviceId=" + quote(device.id) + ", Version=" + quote(device.version);
            if (session.token) value += ", Token=" + quote(session.token);
            return value;
        }

        function headers(extra) {
            var h = {Authorization: authorization(), Accept: "application/json"};
            for (var k in extra || {}) h[k] = extra[k];
            return h;
        }

        function failure(res, path) {
            var message = "Server error " + res.status;
            if (res.status === 401) message = "Your session has expired or the login was rejected.";
            else if (res.status === 403) message = "This account is not allowed to do that.";
            else if (res.status === 404) message = "Not found on the server.";
            else if (res.data && typeof res.data === "object" && (res.data.title || res.data.Message)) message += ": " + (res.data.title || res.data.Message);
            var error = new Error(message);
            error.status = res.status; error.path = path;
            return error;
        }

        async function call(method, path, params, body, opts) {
            opts = opts || {};
            var target = full(path) + query(params || {});
            var res = await http.fetchJson(transport, {
                host: server.host, port: server.port, tls: server.tls, method: method, path: target,
                headers: headers(body !== undefined ? {"Content-Type": "application/json"} : null),
                body: body !== undefined ? JSON.stringify(body) : null,
                timeoutMs: opts.timeoutMs || 15000, maxBytes: opts.maxBytes || 4 * 1048576, signal: opts.signal
            });
            noteServerTime(res.headers);
            if (res.status >= 400) throw failure(res, target);
            return res.data;
        }

        function requireUser() { if (!session.userId || !session.token) throw new Error("Not signed in."); }

        var itemFields = "Overview,PrimaryImageAspectRatio,MediaSources,ProductionYear,RunTimeTicks,UserData,SortName";

        var api = {
            device: device,
            server: server,
            session: function () { return {token: session.token, userId: session.userId}; },
            setSession: function (token, userId) { session.token = token; session.userId = userId; },
            // Current time by the server's clock (falls back to the console's).
            now: function () { return Date.now() + clockOffset; },
            clockSynced: function () { return clockSynced; },
            authorization: authorization,
            ticks: TICKS,

            publicInfo: function () { return call("GET", "/System/Info/Public", null, undefined, {timeoutMs: 6000}); },

            login: async function (username, password) {
                var result = await call("POST", "/Users/AuthenticateByName", null, {Username: username, Pw: password || ""});
                if (!result || !result.AccessToken || !result.User) throw new Error("Unexpected login response.");
                session.token = result.AccessToken; session.userId = result.User.Id;
                return {token: session.token, userId: session.userId, userName: result.User.Name};
            },

            quickConnectEnabled: async function () { try { return (await call("GET", "/QuickConnect/Enabled")) === true; } catch (e) { return false; } },
            quickConnectStart: function () { return call("POST", "/QuickConnect/Initiate"); },
            quickConnectState: function (secret) { return call("GET", "/QuickConnect/Connect", {secret: secret}); },
            quickConnectFinish: async function (secret) {
                var result = await call("POST", "/Users/AuthenticateWithQuickConnect", null, {Secret: secret});
                if (!result || !result.AccessToken || !result.User) throw new Error("Unexpected Quick Connect response.");
                session.token = result.AccessToken; session.userId = result.User.Id;
                return {token: session.token, userId: session.userId, userName: result.User.Name};
            },

            currentUser: function () { requireUser(); return call("GET", "/Users/Me"); },

            views: async function () { requireUser(); var r = await call("GET", "/UserViews", {userId: session.userId}); return (r && r.Items) || []; },

            items: async function (params) {
                requireUser();
                var p = {userId: session.userId, fields: itemFields, enableImageTypes: "Primary", imageTypeLimit: 1, enableTotalRecordCount: true};
                for (var k in params || {}) p[k] = params[k];
                var r = await call("GET", "/Items", p);
                return {items: (r && r.Items) || [], total: (r && r.TotalRecordCount) || 0};
            },

            library: function (parentId, startIndex, limit) {
                return api.items({parentId: parentId, recursive: true, includeItemTypes: "Movie,Series", sortBy: "SortName,ProductionYear", sortOrder: "Ascending", startIndex: startIndex || 0, limit: limit || 48});
            },

            resume: async function () {
                requireUser();
                var r = await call("GET", "/UserItems/Resume", {userId: session.userId, mediaTypes: "Video", limit: 24, fields: itemFields, enableImageTypes: "Primary,Thumb,Backdrop", imageTypeLimit: 1});
                return (r && r.Items) || [];
            },

            nextUp: async function () {
                requireUser();
                var r = await call("GET", "/Shows/NextUp", {userId: session.userId, limit: 24, fields: itemFields, enableImageTypes: "Primary,Thumb,Backdrop", imageTypeLimit: 1});
                return (r && r.Items) || [];
            },

            seasons: async function (seriesId) { requireUser(); var r = await call("GET", "/Shows/" + encodeURIComponent(seriesId) + "/Seasons", {userId: session.userId}); return (r && r.Items) || []; },

            episodes: async function (seriesId, seasonId) {
                requireUser();
                var r = await call("GET", "/Shows/" + encodeURIComponent(seriesId) + "/Episodes", {userId: session.userId, seasonId: seasonId, fields: itemFields});
                return (r && r.Items) || [];
            },

            // The episode after `episode` in its series (crossing seasons), or null.
            nextEpisode: async function (episode) {
                requireUser();
                if (!episode || episode.Type !== "Episode" || !episode.SeriesId) return null;
                var r = await call("GET", "/Shows/" + encodeURIComponent(episode.SeriesId) + "/Episodes",
                    {userId: session.userId, startItemId: episode.Id, limit: 2, fields: itemFields, enableImageTypes: "Primary,Thumb,Backdrop", imageTypeLimit: 1});
                var items = (r && r.Items) || [];
                return items.length > 1 && items[1].Id !== episode.Id ? items[1] : null;
            },

            item: function (itemId) { requireUser(); return call("GET", "/Items/" + encodeURIComponent(itemId), {userId: session.userId}); },

            // PNG so the console's image path (proven with Moonlight artwork) can show it.
            imagePath: function (itemId, kind, tag, maxHeight) {
                return full("/Items/" + encodeURIComponent(itemId) + "/Images/" + (kind || "Primary") + query({format: "Png", maxHeight: maxHeight || 360, quality: 90, tag: tag}));
            },

            fetchImage: async function (itemId, kind, tag, maxHeight, signal) {
                var res = await http.fetchBytes(transport, {host: server.host, port: server.port, tls: server.tls, method: "GET", path: api.imagePath(itemId, kind, tag, maxHeight),
                    headers: {Authorization: authorization(), Accept: "image/png"}, timeoutMs: 15000, maxBytes: 3 * 1048576, signal: signal});
                if (res.status !== 200 || !res.body.length) return null;
                if (res.body[0] !== 0x89 || res.body[1] !== 0x50) return null; // not a PNG
                return http.toDataUrl(res.body, "image/png");
            },

            // HLS transcode to H.264 + stereo Opus in MPEG-TS: the only formats the
            // console's native pipeline (movie::Decoder + libopus) is known to accept.
            masterPlaylistPath: function (item, settings) {
                var source = (item.MediaSources && item.MediaSources[0]) || null;
                if (!source) throw new Error("This item has no playable media.");
                var playSessionId = randomHex(32);
                var p = {
                    DeviceId: device.id, MediaSourceId: source.Id, PlaySessionId: playSessionId,
                    VideoCodec: "h264", AudioCodec: "opus", SegmentContainer: "ts", MinSegments: 1,
                    BreakOnNonKeyFrames: true, TranscodingMaxAudioChannels: 2, MaxAudioChannels: 2,
                    AudioStreamIndex: settings.audioStreamIndex != null ? settings.audioStreamIndex : source.DefaultAudioStreamIndex,
                    // Subtitles are burned into the video by the server (Encode).
                    SubtitleStreamIndex: settings.subtitleStreamIndex != null && settings.subtitleStreamIndex >= 0 ? settings.subtitleStreamIndex : undefined,
                    SubtitleMethod: settings.subtitleStreamIndex != null && settings.subtitleStreamIndex >= 0 ? "Encode" : undefined,
                    VideoBitrate: settings.videoBitrate, AudioBitrate: 128000, MaxWidth: settings.maxWidth, MaxHeight: settings.maxHeight,
                    // Baseline forbids B-frames. The console's media path shows only the newest
                    // finished frame, and B-frames make the decoder release frames in pairs,
                    // which halved the frame rate (12 of 24 fps shown) on real hardware.
                    MaxFramerate: settings.maxFramerate, profile: "baseline", level: settings.level || "41",
                    AllowVideoStreamCopy: false, AllowAudioStreamCopy: false, EnableAutoStreamCopy: false, RequireAvc: false
                };
                return {path: full("/Videos/" + encodeURIComponent(item.Id) + "/master.m3u8" + query(p)), playSessionId: playSessionId, mediaSourceId: source.Id};
            },

            fetchText: async function (path, signal) {
                var res = await http.fetchBytes(transport, {host: server.host, port: server.port, tls: server.tls, method: "GET", path: path, headers: {Authorization: authorization()}, timeoutMs: 60000, maxBytes: 4 * 1048576, signal: signal});
                if (res.status >= 400) throw failure({status: res.status, data: null}, path);
                return http.decodeText(res.body);
            },

            // ---- Live TV ------------------------------------------------------
            liveTvInfo: function () { return call("GET", "/LiveTv/Info", {}); },
            channels: async function (startIndex, limit) {
                requireUser();
                var r = await call("GET", "/LiveTv/Channels", {userId: session.userId, startIndex: startIndex || 0, limit: limit || 100,
                    enableImages: true, imageTypeLimit: 1, enableImageTypes: "Primary", addCurrentProgram: true, enableUserData: false});
                return {items: (r && r.Items) || [], total: (r && r.TotalRecordCount) || 0};
            },
            // Programs on these channels overlapping [from, to) (Date objects).
            programs: async function (channelIds, from, to) {
                requireUser();
                if (!channelIds.length) return [];
                var r = await call("GET", "/LiveTv/Programs", {userId: session.userId, channelIds: channelIds.join(","),
                    minEndDate: from.toISOString(), maxStartDate: to.toISOString(), sortBy: "StartDate", sortOrder: "Ascending",
                    enableImages: false, enableUserData: false, enableTotalRecordCount: false, fields: "Overview", limit: 5000}, undefined, {maxBytes: 8 * 1048576});
                return (r && r.Items) || [];
            },
            // Opens the channel's tuner stream; returns {mediaSourceId, liveStreamId, playSessionId}.
            openLiveStream: async function (channelId, settings) {
                requireUser();
                var r = await call("POST", "/Items/" + encodeURIComponent(channelId) + "/PlaybackInfo", {}, {
                    UserId: session.userId, AutoOpenLiveStream: true, EnableDirectPlay: false, EnableDirectStream: false, EnableTranscoding: true,
                    AllowVideoStreamCopy: false, AllowAudioStreamCopy: false, MaxStreamingBitrate: settings.videoBitrate + 128000, MaxAudioChannels: 2
                }, {timeoutMs: 45000});
                var source = r && r.MediaSources && r.MediaSources[0];
                if (!source) throw new Error("The server did not open this channel" + (r && r.ErrorCode ? " (" + r.ErrorCode + ")." : "."));
                return {mediaSourceId: source.Id, liveStreamId: source.LiveStreamId || null, playSessionId: r.PlaySessionId || randomHex(32)};
            },
            // Live HLS (an EVENT playlist that grows), same formats as on-demand playback.
            livePlaylistPath: function (channelId, stream, settings) {
                var p = {
                    DeviceId: device.id, MediaSourceId: stream.mediaSourceId, LiveStreamId: stream.liveStreamId, PlaySessionId: stream.playSessionId,
                    VideoCodec: "h264", AudioCodec: "opus", SegmentContainer: "ts", MinSegments: 2, profile: "baseline", level: settings.level || "41",
                    VideoBitrate: settings.videoBitrate, AudioBitrate: 128000, MaxAudioChannels: 2, TranscodingMaxAudioChannels: 2,
                    Width: settings.maxWidth, MaxFramerate: 30, DeInterlace: true,
                    AllowVideoStreamCopy: false, AllowAudioStreamCopy: false, EnableAutoStreamCopy: false, RequireAvc: false
                };
                return full("/Videos/" + encodeURIComponent(channelId) + "/live.m3u8" + query(p));
            },
            closeLiveStream: function (liveStreamId) { return call("POST", "/LiveStreams/Close", {liveStreamId: liveStreamId}); },

            reportStart: function (state) { return call("POST", "/Sessions/Playing", null, report(state)); },
            reportProgress: function (state) { var r = report(state); r.EventName = "TimeUpdate"; return call("POST", "/Sessions/Playing/Progress", null, r); },
            reportStopped: function (state) { return call("POST", "/Sessions/Playing/Stopped", null, report(state)); },
            // This device's session, including TranscodingInfo while transcoding.
            sessionInfo: async function () {
                var sessions = await call("GET", "/Sessions", {deviceId: device.id});
                return (sessions || [])[0] || null;
            },
            stopTranscode: function (playSessionId) { return call("DELETE", "/Videos/ActiveEncodings", {deviceId: device.id, playSessionId: playSessionId}); }
        };

        function report(state) {
            return {ItemId: state.itemId, MediaSourceId: state.mediaSourceId, PlaySessionId: state.playSessionId,
                PositionTicks: Math.max(0, Math.round((state.position || 0) * TICKS)), IsPaused: !!state.paused,
                CanSeek: !state.liveStreamId, PlayMethod: "Transcode", LiveStreamId: state.liveStreamId || undefined};
        }

        api.headers = function () { return {Authorization: authorization()}; };
        return api;
    }

    // Parses what the user typed in the server field:
    //   [http:// | https://] (IPv4 | server name) [:port] [/base/path]
    // Default ports: https 443, http 8096 (Jellyfin's own). Returns
    // {scheme, tls, host, port, basePath, isIp, privateIp}.
    function parseServerAddress(input) {
        var text = String(input || "").trim();
        if (!text) throw new Error("Set the server address first.");
        var m = /^(?:([a-zA-Z][a-zA-Z0-9+.-]*):\/\/)?([^\/?#]*)([^?#]*)?(.*)$/.exec(text);
        var scheme = (m[1] || "http").toLowerCase(), authority = m[2] || "", path = m[3] || "";
        if (scheme !== "http" && scheme !== "https") throw new Error("Unsupported address type \"" + scheme + "://\". Use http:// or https://.");
        if (authority.indexOf("@") >= 0) throw new Error("Remove the user name from the address; sign in on the next screen.");
        if (authority[0] === "[") throw new Error("IPv6 addresses aren't supported yet. Use an IPv4 address or a server name.");
        var hp = /^([^:]*)(?::(\d{1,5}))?$/.exec(authority);
        if (!hp || !hp[1]) throw new Error("Enter an address such as http://192.168.1.20:8096 or https://jellyfin.example.com.");
        var host = hp[1].toLowerCase().replace(/\.$/, ""), port = hp[2] ? Number(hp[2]) : (scheme === "https" ? 443 : 8096);
        var isIp = /^\d{1,3}(\.\d{1,3}){3}$/.test(host);
        if (isIp && host.split(".").some(function (o) { return Number(o) > 255; })) throw new Error("\"" + host + "\" is not a valid IPv4 address.");
        if (!isIp && !(JF.dns ? JF.dns.validName(host) : /^[a-z0-9.-]+$/.test(host))) throw new Error("\"" + host + "\" is not a valid server name.");
        if (port < 1 || port > 65535) throw new Error("Port must be between 1 and 65535.");
        if (m[4]) throw new Error("Remove the ? or # part from the address.");
        var basePath = path.replace(/\/+$/, "");
        if (basePath && !/^(\/[A-Za-z0-9._~!$&'()*+,;=:@%-]+)+$/.test(basePath)) throw new Error("The path \"" + path + "\" contains characters that aren't allowed.");
        var o = isIp ? host.split(".").map(Number) : null;
        var privateIp = !!o && (o[0] === 10 || o[0] === 127 || (o[0] === 192 && o[1] === 168) || (o[0] === 172 && o[1] >= 16 && o[1] <= 31) || (o[0] === 169 && o[1] === 254) || (o[0] === 100 && o[1] >= 64 && o[1] <= 127));
        return {scheme: scheme, tls: scheme === "https", host: host, port: port, basePath: basePath, isIp: isIp, privateIp: privateIp};
    }

    // Plain HTTP that leaves the home network exposes the password and token.
    function insecureRemote(address) { return !address.tls && !address.privateIp; }

    // Picks a wide (16:9) image for an item: {id, kind, tag, fill}. fill=false
    // means only a tall poster exists and it should be centred, not stretched.
    function landscapeImage(it) {
        var tags = it.ImageTags || {};
        if (tags.Thumb) return {id: it.Id, kind: "Thumb", tag: tags.Thumb, fill: true};
        if (it.Type === "Episode" && tags.Primary) return {id: it.Id, kind: "Primary", tag: tags.Primary, fill: true};
        if (it.ParentThumbItemId && it.ParentThumbImageTag) return {id: it.ParentThumbItemId, kind: "Thumb", tag: it.ParentThumbImageTag, fill: true};
        if (it.BackdropImageTags && it.BackdropImageTags.length) return {id: it.Id, kind: "Backdrop", tag: it.BackdropImageTags[0], fill: true};
        if (it.ParentBackdropItemId && it.ParentBackdropImageTags && it.ParentBackdropImageTags.length)
            return {id: it.ParentBackdropItemId, kind: "Backdrop", tag: it.ParentBackdropImageTags[0], fill: true};
        if (tags.Primary) return {id: it.Id, kind: "Primary", tag: tags.Primary, fill: (it.PrimaryImageAspectRatio || 0) >= 1.2};
        if (it.SeriesPrimaryImageTag && it.SeriesId) return {id: it.SeriesId, kind: "Primary", tag: it.SeriesPrimaryImageTag, fill: false};
        return null;
    }

    JF.jellyfin = {landscapeImage: landscapeImage, create: create, query: query, TICKS: TICKS, parseServerAddress: parseServerAddress, insecureRemote: insecureRemote};
    if (typeof module !== "undefined" && module.exports) module.exports = JF.jellyfin;
})();
