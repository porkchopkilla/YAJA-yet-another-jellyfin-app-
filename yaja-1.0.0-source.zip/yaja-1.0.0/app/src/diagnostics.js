/* Playback diagnostics: per-second measurements, a rolling 5-second view for the
 * stats overlay, and a 30-second recorded report with plain-language findings.
 * Pure logic: the app feeds it counters; nothing here touches the platform. */
(function () {
    "use strict";
    var G = typeof window !== "undefined" ? window : globalThis;
    var JF = G.JF = G.JF || {};

    var RECORD_SECONDS = 30;

    // Cumulative counters from the player and the native media module become
    // per-second deltas. Missing sink counters (non-native sinks) read as 0.
    function create(options) {
        options = options || {};
        var now = options.now || function () { return Date.now(); };
        var recordSeconds = options.recordSeconds || RECORD_SECONDS;
        var buckets = [], recording = null, lastTickAt = null, startedAt = null, primed = false;
        var current = fresh(), previous = null;

        function fresh() { return {ticks: 0, maxGap: 0, gaps50: 0, gaps100: 0, minBuffer: Infinity}; }

        // Called on every frame-loop iteration.
        function tick(buffer) {
            var t = now();
            if (startedAt === null) startedAt = t;
            if (lastTickAt !== null) {
                var gap = t - lastTickAt;
                if (gap > current.maxGap) current.maxGap = gap;
                if (gap > 50) current.gaps50++;
                if (gap > 100) current.gaps100++;
            }
            lastTickAt = t; current.ticks++;
            if (buffer !== undefined && buffer < current.minBuffer) current.minBuffer = buffer;
        }

        // Called once per second with cumulative counters.
        // snapshot: {player: player.stats, sink: media stats or null, slice: ms, buffer, lead, latency, playing}
        function second(snapshot) {
            var p = snapshot.player || {}, s = snapshot.sink || {};
            var cum = {
                fed: p.videoFed || 0, late: p.lateFrames || 0, skipped: p.videoSkipped || 0, stalls: p.stalls || 0,
                audioFed: p.audioFed || 0, audioDropped: p.audioDropped || 0, bytes: p.bytes || 0,
                decoded: s.decoded || 0, presented: s.presented || 0, superseded: s.videoSuperseded || 0,
                expired: (s.videoExpired || 0) + (s.videoBacklogDrops || 0), underruns: s.audioEmptyEpisodes || 0, underrunMs: s.audioEmptyMs || 0,
                decodeMs: s.decodeMs || 0, decodeSamples: s.decodeSamples || 0, gpuMs: s.gpuTransferMs || 0, gpuCount: s.gpuTransfers || 0,
                intervalCount: s.intervalCount || 0, intervalMs: s.intervalMs || 0, intervalSq: s.intervalSquaredMs || 0
            };
            var d = {};
            for (var k in cum) d[k] = previous ? Math.max(0, cum[k] - previous[k]) : 0;
            previous = cum;
            var mean = d.intervalCount ? d.intervalMs / d.intervalCount : 0;
            var variance = d.intervalCount ? Math.max(0, d.intervalSq / d.intervalCount - mean * mean) : 0;
            var bucket = {
                at: Math.round(((now() - (startedAt || now())) / 1000)), playing: !!snapshot.playing,
                ticks: current.ticks, maxGap: Math.round(current.maxGap), gaps50: current.gaps50, gaps100: current.gaps100,
                slice: Math.round(snapshot.slice || 0), buffer: isFinite(current.minBuffer) ? current.minBuffer : (snapshot.buffer || 0),
                fed: d.fed, decoded: d.decoded, shown: d.presented, late: d.late, skipped: d.skipped, stalls: d.stalls,
                superseded: d.superseded, expired: d.expired, audioFed: d.audioFed, audioDropped: d.audioDropped,
                underruns: d.underruns, underrunMs: Math.round(d.underrunMs), kbps: Math.round(d.bytes * 8 / 1000),
                decodeAvg: d.decodeSamples ? d.decodeMs / d.decodeSamples : 0, gpuAvg: d.gpuCount ? d.gpuMs / d.gpuCount : 0,
                intervalMean: mean, intervalJitter: Math.sqrt(variance),
                lead: snapshot.lead, latency: snapshot.latency, bframes: !!(snapshot.player && snapshot.player.bframes)
            };
            current = fresh();
            if (!primed) { primed = true; return null; }                          // first call only primes the deltas
            buckets.push(bucket);
            if (buckets.length > 5) buckets.shift();
            if (recording && bucket.playing) {
                recording.rows.push(bucket);
                if (recording.rows.length >= recordSeconds) { var done = recording; recording = null; if (done.onDone) done.onDone(done.rows); }
            }
            return bucket;
        }

        // Aggregate of the last few seconds for the overlay.
        function recent() {
            if (!buckets.length) return null;
            return summarize(buckets);
        }

        return {
            tick: tick,
            second: second,
            recent: recent,
            record: function (onDone) { if (recording) return false; recording = {rows: [], onDone: onDone}; return true; },
            recording: function () { return recording ? {seconds: recording.rows.length, total: recordSeconds} : null; },
            cancel: function () { recording = null; }
        };
    }

    function summarize(rows) {
        var n = rows.length, sum = function (k) { return rows.reduce(function (a, r) { return a + (r[k] || 0); }, 0); };
        var max = function (k) { return rows.reduce(function (a, r) { return Math.max(a, r[k] || 0); }, 0); };
        var withIntervals = rows.filter(function (r) { return r.intervalMean > 0; });
        var jitters = withIntervals.map(function (r) { return r.intervalJitter; }).sort(function (a, b) { return a - b; });
        return {
            seconds: n, ticks: sum("ticks"), shownFps: sum("shown") / n, decodedFps: sum("decoded") / n, fedFps: sum("fed") / n,
            maxGap: max("maxGap"), gaps50: sum("gaps50"), gaps100: sum("gaps100"), maxSlice: max("slice"),
            minBuffer: rows.reduce(function (a, r) { return Math.min(a, r.buffer); }, Infinity),
            late: sum("late"), skipped: sum("skipped"), stalls: sum("stalls"), superseded: sum("superseded"), expired: sum("expired"),
            underruns: sum("underruns"), audioDropped: sum("audioDropped"), kbps: sum("kbps") / n,
            intervalMean: withIntervals.length ? withIntervals.reduce(function (a, r) { return a + r.intervalMean; }, 0) / withIntervals.length : 0,
            intervalJitter: jitters.length ? jitters[Math.floor(jitters.length / 2)] : 0,
            worstJitter: jitters.length ? jitters[jitters.length - 1] : 0,
            decodeAvg: rows.reduce(function (a, r) { return a + r.decodeAvg; }, 0) / n,
            gpuAvg: rows.reduce(function (a, r) { return a + r.gpuAvg; }, 0) / n,
            lead: rows[n - 1].lead, latency: rows[n - 1].latency,
            bframes: rows.some(function (r) { return r.bframes; })
        };
    }

    // Plain-language findings, most likely cause first. context: {sourceFps, server: TranscodingInfo or null, mode}
    function analyze(sum, context) {
        context = context || {};
        var findings = [], fps = context.sourceFps || (sum.fedFps > 5 ? sum.fedFps : 0);
        var server = context.server;
        if (sum.bframes && (sum.superseded > 0 || (sum.decodedFps > 5 && sum.shownFps < sum.decodedFps * 0.9)))
            findings.push("B-FRAMES IN THE STREAM: the decoder releases B-frame video in pairs and only the newer frame of each pair can be shown. " +
                "The app asks Jellyfin for Baseline H.264 (no B-frames); this stream still has them, so the server may be ignoring the profile request.");
        if (server && server.Framerate && fps && server.Framerate < fps * 0.95)
            findings.push("SERVER TOO SLOW: Jellyfin transcodes at " + server.Framerate.toFixed(1) + " fps, below the video's " + fps.toFixed(2) +
                " fps" + (server.HardwareAccelerationType && server.HardwareAccelerationType !== "none" ? "" : " (no hardware acceleration)") +
                ". Enable hardware transcoding on the server or choose a lower quality.");
        if (sum.stalls > 0 || sum.minBuffer < 1)
            findings.push("STARVING: the buffer fell to " + sum.minBuffer.toFixed(1) + " s" + (sum.stalls ? " and playback paused " + sum.stalls + "x" : "") +
                ". Downloads are not keeping ahead (server speed or network).");
        var blockedTicks = sum.ticks ? sum.gaps50 / sum.ticks : 0;
        if (sum.maxGap > 100 || blockedTicks > 0.02) {
            if (sum.maxSlice >= sum.maxGap * 0.5)
                findings.push("CONSOLE BUSY WITH THE STREAM: the frame loop paused up to " + sum.maxGap + " ms (" + sum.gaps50 +
                    " pauses over 50 ms) while processing downloads (slices up to " + sum.maxSlice + " ms).");
            else
                findings.push("FRAME LOOP BLOCKED ELSEWHERE: pauses up to " + sum.maxGap + " ms (" + sum.gaps50 + " over 50 ms) not explained by downloads (slices " +
                    sum.maxSlice + " ms). Average GPU copy " + sum.gpuAvg.toFixed(1) + " ms in " + (context.mode || "unknown") + " mode.");
        }
        if (fps && sum.decodedFps < fps * 0.9)
            findings.push("DECODER BEHIND: " + sum.decodedFps.toFixed(1) + " decoded frames/s for a " + fps.toFixed(2) + " fps video (average decode " + sum.decodeAvg.toFixed(1) + " ms).");
        if (sum.superseded > 0 || (sum.decodedFps > 5 && sum.shownFps < sum.decodedFps * 0.9))
            findings.push("FRAMES REPLACED BEFORE SHOWN: " + sum.superseded + " decoded frames were overtaken by newer ones (" + sum.shownFps.toFixed(1) +
                " shown/s vs " + sum.decodedFps.toFixed(1) + " decoded/s). Frames are reaching the screen in bursts.");
        if (sum.skipped > 0) findings.push("FELL BEHIND: " + sum.skipped + " frames were skipped to catch up to the next keyframe.");
        if (sum.late > 0) findings.push("LATE FRAMES: " + sum.late + " frames reached the decoder after their time.");
        // A 60 Hz screen can only change picture every 16.7 ms, so a frame rate that does
        // not divide 60 alternates between whole refreshes (24 fps: 2 and 3, i.e. 33.3 and
        // 50 ms, +/- 8.3 ms). Only spacing beyond that built-in variation is a problem.
        var cadence = expectedCadenceJitter(fps);
        if (sum.intervalJitter > cadence + 4)
            findings.push("UNEVEN SPACING: frames appear every " + sum.intervalMean.toFixed(1) + " ms on average, varying by about " + sum.intervalJitter.toFixed(1) +
                " ms (worst second " + sum.worstJitter.toFixed(1) + " ms); the screen's own cadence for this frame rate accounts for " + cadence.toFixed(1) + " ms.");
        if (sum.underruns > 0) findings.push("AUDIO RAN DRY " + sum.underruns + "x, a sign of general overload.");
        if (!findings.length) {
            if (cadence > 1)
                findings.push("DELIVERY LOOKS STEADY. Frames follow the 60 Hz screen's cadence for " + fps.toFixed(3) + " fps (alternating " +
                    "whole refreshes, +/- " + cadence.toFixed(1) + " ms), the normal judder of film on a 60 Hz display.");
            else findings.push("DELIVERY LOOKS STEADY: no stalls, loop pauses, skipped or late frames measured.");
        }
        return findings;
    }

    // Standard deviation of on-screen frame durations when fps frames are shown on a
    // 60 Hz display (each frame lasts a whole number of 16.7 ms refreshes).
    function expectedCadenceJitter(fps) {
        if (!fps || fps <= 0 || fps > 60) return 0;
        var refresh = 1000 / 60, n = 60 / fps, frac = n - Math.floor(n);
        if (frac < 0.01 || frac > 0.99) return 0;
        return refresh * Math.sqrt(frac * (1 - frac));
    }

    function pad(value, width) { value = String(value); while (value.length < width) value = " " + value; return value; }

    // Full text report. info: {version, item, sourceFps, sourceRes, stream, quality, mode, controller, server, startedAt}
    function formatReport(rows, info) {
        var sum = summarize(rows), findings = analyze(sum, {sourceFps: info.sourceFps, server: info.server, mode: info.mode});
        var lines = [];
        lines.push("YAJA (Yet another jellyfin app) " + info.version + " playback report   " + (info.startedAt || ""));
        lines.push("Title:      " + info.item);
        lines.push("Source:     " + (info.sourceRes || "?") + " @ " + (info.sourceFps ? info.sourceFps.toFixed(3) + " fps" : "? fps") + (info.sourceCodec ? " (" + info.sourceCodec + ")" : ""));
        lines.push("Stream:     " + (info.stream || "?") + "   B-frames: " + (sum.bframes ? "yes" : "no") + "   quality setting: " + (info.quality || "?"));
        lines.push("Video path: " + (info.mode || "?") + " presentation   controller: " + (info.controller || "?"));
        var sv = info.server;
        lines.push("Server:     " + (sv ? (sv.VideoCodec || "?") + "/" + (sv.AudioCodec || "?") + " " + (sv.Width || "?") + "x" + (sv.Height || "?") +
            " transcoding at " + (sv.Framerate ? sv.Framerate.toFixed(1) + " fps" : "? fps") + ", hardware: " + (sv.HardwareAccelerationType || "none") +
            (sv.Bitrate ? ", " + Math.round(sv.Bitrate / 1000) + " kbps" : "") : "no transcode info (session not found)"));
        lines.push("");
        lines.push("FINDINGS");
        findings.forEach(function (f, i) { lines.push((i + 1) + ". " + f); });
        lines.push("");
        lines.push("SUMMARY over " + sum.seconds + " s");
        lines.push("  shown " + sum.shownFps.toFixed(1) + " fps, decoded " + sum.decodedFps.toFixed(1) + " fps, fed " + sum.fedFps.toFixed(1) + " fps");
        lines.push("  frame spacing " + sum.intervalMean.toFixed(1) + " ms +/- " + sum.intervalJitter.toFixed(1) + " ms (worst second +/- " + sum.worstJitter.toFixed(1) + " ms)");
        lines.push("  loop pauses: max " + sum.maxGap + " ms, " + sum.gaps50 + " over 50 ms, " + sum.gaps100 + " over 100 ms, of " + sum.ticks + " ticks");
        lines.push("  download slices max " + sum.maxSlice + " ms, " + Math.round(sum.kbps) + " kbps, buffer min " + sum.minBuffer.toFixed(1) + " s");
        lines.push("  late " + sum.late + ", skipped " + sum.skipped + ", stalls " + sum.stalls + ", replaced " + sum.superseded + ", expired " + sum.expired);
        lines.push("  decode avg " + sum.decodeAvg.toFixed(1) + " ms, GPU copy avg " + sum.gpuAvg.toFixed(1) + " ms, lead " + sum.lead + " ms, measured latency " +
            (sum.latency !== null && sum.latency !== undefined ? Math.round(sum.latency * 1000) + " ms" : "?"));
        lines.push("  audio: underruns " + sum.underruns + ", dropped " + sum.audioDropped);
        lines.push("");
        lines.push("PER SECOND");
        lines.push("   s shown dec  fed spacing+-jit  gapMax >50 slice buf  late skip repl undr  kbps");
        rows.forEach(function (r, i) {
            lines.push(pad(i + 1, 4) + pad(r.shown, 6) + pad(r.decoded, 4) + pad(r.fed, 5) + pad(r.intervalMean.toFixed(1), 8) + pad(r.intervalJitter.toFixed(1), 6) +
                pad(r.maxGap, 7) + pad(r.gaps50, 4) + pad(r.slice, 6) + pad(r.buffer.toFixed(1), 5) + pad(r.late, 5) + pad(r.skipped, 5) +
                pad(r.superseded, 5) + pad(r.underruns, 5) + pad(r.kbps, 6));
        });
        return {text: lines.join("\n"), findings: findings, summary: sum};
    }

    JF.diagnostics = {expectedCadenceJitter: expectedCadenceJitter, create: create, summarize: summarize, analyze: analyze, formatReport: formatReport, RECORD_SECONDS: RECORD_SECONDS};
    if (typeof module !== "undefined" && module.exports) module.exports = JF.diagnostics;
})();
