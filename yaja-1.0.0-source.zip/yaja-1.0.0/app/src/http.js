/* HTTP/1.1 over an injected byte transport: request builder, incremental response
 * parser (content-length, chunked, close-delimited) and convenience helpers. */
(function () {
    "use strict";
    var G = typeof window !== "undefined" ? window : globalThis;
    var JF = G.JF = G.JF || {};

    function encodeText(text) {
        var out = new Uint8Array(text.length * 3), n = 0;
        for (var i = 0; i < text.length; i++) {
            var c = text.charCodeAt(i);
            if (c >= 0xd800 && c < 0xdc00 && i + 1 < text.length) { c = 0x10000 + ((c - 0xd800) << 10) + (text.charCodeAt(++i) - 0xdc00); }
            if (c < 0x80) out[n++] = c;
            else if (c < 0x800) { out[n++] = 0xc0 | c >> 6; out[n++] = 0x80 | c & 63; }
            else if (c < 0x10000) { out[n++] = 0xe0 | c >> 12; out[n++] = 0x80 | c >> 6 & 63; out[n++] = 0x80 | c & 63; }
            else { out[n++] = 0xf0 | c >> 18; out[n++] = 0x80 | c >> 12 & 63; out[n++] = 0x80 | c >> 6 & 63; out[n++] = 0x80 | c & 63; }
        }
        return out.subarray(0, n);
    }

    function decodeText(bytes) {
        var s = "", i = 0, n = bytes.length;
        while (i < n) {
            var c = bytes[i++], cp;
            if (c < 0x80) cp = c;
            else if (c >= 0xc0 && c < 0xe0 && i < n) cp = (c & 31) << 6 | bytes[i++] & 63;
            else if (c >= 0xe0 && c < 0xf0 && i + 1 < n) { cp = (c & 15) << 12 | (bytes[i] & 63) << 6 | bytes[i + 1] & 63; i += 2; }
            else if (c >= 0xf0 && i + 2 < n) { cp = (c & 7) << 18 | (bytes[i] & 63) << 12 | (bytes[i + 1] & 63) << 6 | bytes[i + 2] & 63; i += 3; }
            else cp = 0xfffd;
            if (cp >= 0x10000) { cp -= 0x10000; s += String.fromCharCode(0xd800 + (cp >> 10), 0xdc00 + (cp & 1023)); }
            else s += String.fromCharCode(cp);
        }
        return s;
    }

    // Returns the full request as bytes. body: string | Uint8Array | null.
    function buildRequest(options) {
        var body = options.body == null ? null : (typeof options.body === "string" ? encodeText(options.body) : options.body);
        // Host carries the server name (reverse proxies route on it); the port is
        // omitted only when it is the scheme's default.
        var defaultPort = options.tls ? 443 : 80;
        var headers = {Host: options.host + (options.port && options.port !== defaultPort ? ":" + options.port : ""), Connection: "close", Accept: "*/*"};
        var given = options.headers || {};
        for (var k in given) if (Object.prototype.hasOwnProperty.call(given, k)) headers[k] = given[k];
        if (body) headers["Content-Length"] = String(body.length);
        if (/[\r\n]/.test(options.path) || !/^\/[^ ]*$/.test(options.path)) throw new Error("Invalid request path");
        var head = (options.method || "GET") + " " + options.path + " HTTP/1.1\r\n";
        for (var name in headers) {
            if (/[\r\n:]/.test(name) || /[\r\n]/.test(String(headers[name]))) throw new Error("Invalid header");
            head += name + ": " + headers[name] + "\r\n";
        }
        var headBytes = encodeText(head + "\r\n");
        if (!body) return headBytes;
        var out = new Uint8Array(headBytes.length + body.length);
        out.set(headBytes, 0); out.set(body, headBytes.length);
        return out;
    }

    // Incremental response parser. Callbacks: onHead({status, reason, headers}), onBody(Uint8Array), onEnd().
    function createParser(cb) {
        var state = "head", buffer = new Uint8Array(0), remaining = 0, chunkRemaining = 0, ended = false, head = null, noBody = false;
        function append(chunk) {
            if (!buffer.length) { buffer = chunk; return; }
            var merged = new Uint8Array(buffer.length + chunk.length);
            merged.set(buffer, 0); merged.set(chunk, buffer.length); buffer = merged;
        }
        function find(crlf2) {
            for (var i = 0; i + 1 < buffer.length; i++) {
                if (crlf2) { if (i + 3 < buffer.length && buffer[i] === 13 && buffer[i + 1] === 10 && buffer[i + 2] === 13 && buffer[i + 3] === 10) return i; }
                else if (buffer[i] === 13 && buffer[i + 1] === 10) return i;
            }
            return -1;
        }
        function finish() { if (!ended) { ended = true; state = "done"; if (cb.onEnd) cb.onEnd(); } }
        function parseHead(text) {
            var lines = text.split("\r\n"), m = /^HTTP\/1\.[01] (\d{3})(?: (.*))?$/.exec(lines[0]);
            if (!m) throw new Error("Invalid HTTP status line");
            var headers = {};
            for (var i = 1; i < lines.length; i++) {
                var at = lines[i].indexOf(":");
                if (at < 1) throw new Error("Invalid HTTP header");
                var name = lines[i].slice(0, at).trim().toLowerCase(), value = lines[i].slice(at + 1).trim();
                headers[name] = headers[name] === undefined ? value : headers[name] + ", " + value;
            }
            return {status: Number(m[1]), reason: m[2] || "", headers: headers};
        }
        function drain() {
            for (;;) {
                if (state === "head") {
                    var end = find(true);
                    if (end < 0) { if (buffer.length > 65536) throw new Error("HTTP headers too large"); return; }
                    head = parseHead(decodeText(buffer.subarray(0, end)));
                    buffer = buffer.subarray(end + 4);
                    if (head.status >= 100 && head.status < 200 && head.status !== 101) { head = null; continue; } // interim response
                    if (cb.onHead) cb.onHead(head);
                    noBody = head.status === 204 || head.status === 304 || cb.noBody === true;
                    var te = head.headers["transfer-encoding"], cl = head.headers["content-length"];
                    if (noBody) { finish(); return; }
                    if (te && /chunked/i.test(te)) state = "chunk-size";
                    else if (cl !== undefined) {
                        if (!/^\d+$/.test(cl)) throw new Error("Invalid content length");
                        remaining = Number(cl); state = "length";
                        if (!remaining) { finish(); return; }
                    } else state = "close";
                } else if (state === "length") {
                    if (!buffer.length) return;
                    var take = Math.min(remaining, buffer.length);
                    if (cb.onBody) cb.onBody(buffer.subarray(0, take));
                    buffer = buffer.subarray(take); remaining -= take;
                    if (!remaining) { finish(); return; }
                } else if (state === "close") {
                    if (!buffer.length) return;
                    if (cb.onBody) cb.onBody(buffer); buffer = new Uint8Array(0); return;
                } else if (state === "chunk-size") {
                    var eol = find(false);
                    if (eol < 0) { if (buffer.length > 1024) throw new Error("Invalid chunk header"); return; }
                    var line = decodeText(buffer.subarray(0, eol)).split(";")[0].trim();
                    if (!/^[0-9a-fA-F]+$/.test(line)) throw new Error("Invalid chunk size");
                    chunkRemaining = parseInt(line, 16); buffer = buffer.subarray(eol + 2);
                    state = chunkRemaining ? "chunk-data" : "trailers";
                } else if (state === "chunk-data") {
                    if (!buffer.length) return;
                    var n = Math.min(chunkRemaining, buffer.length);
                    if (cb.onBody) cb.onBody(buffer.subarray(0, n));
                    buffer = buffer.subarray(n); chunkRemaining -= n;
                    if (!chunkRemaining) state = "chunk-end";
                } else if (state === "chunk-end") {
                    if (buffer.length < 2) return;
                    if (buffer[0] !== 13 || buffer[1] !== 10) throw new Error("Invalid chunk terminator");
                    buffer = buffer.subarray(2); state = "chunk-size";
                } else if (state === "trailers") {
                    var t = find(false);
                    if (t < 0) { if (buffer.length > 8192) throw new Error("HTTP trailers too large"); return; }
                    var empty = t === 0; buffer = buffer.subarray(t + 2);
                    if (empty) { finish(); return; }
                } else return;
            }
        }
        return {
            push: function (chunk) { if (ended || !chunk.length) return; append(chunk); drain(); },
            // Connection closed by the peer.
            eof: function () {
                if (ended) return;
                if (state === "close") finish();
                else throw new Error("Connection closed before the response completed");
            },
            done: function () { return ended; }
        };
    }

    // Collects a whole response. transport.request(options, handlers) -> Promise.
    async function fetchBytes(transport, options) {
        var parts = [], total = 0, info = null, limit = options.maxBytes || 8 * 1048576;
        await transport.request(options, {
            onHead: function (head) {
                info = head;
                var cl = Number(head.headers["content-length"]);
                if (isFinite(cl) && cl > limit) throw new Error("Response larger than " + limit + " bytes");
            },
            onBody: function (chunk) {
                total += chunk.length;
                if (total > limit) throw new Error("Response larger than " + limit + " bytes");
                parts.push(chunk.slice());
            }
        });
        var body = new Uint8Array(total), at = 0;
        for (var i = 0; i < parts.length; i++) { body.set(parts[i], at); at += parts[i].length; }
        return {status: info.status, headers: info.headers, body: body};
    }

    async function fetchJson(transport, options) {
        var res = await fetchBytes(transport, options);
        var text = decodeText(res.body), data = null;
        if (text) { try { data = JSON.parse(text); } catch (e) { if (res.status < 400) throw new Error("Server returned invalid JSON"); } }
        return {status: res.status, headers: res.headers, data: data, text: text};
    }

    var B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    function toBase64(bytes) {
        var out = "", n = bytes.length, i = 0;
        for (; i + 2 < n; i += 3) {
            var v = bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
            out += B64[v >> 18 & 63] + B64[v >> 12 & 63] + B64[v >> 6 & 63] + B64[v & 63];
        }
        if (i < n) {
            var w = bytes[i] << 16 | (i + 1 < n ? bytes[i + 1] << 8 : 0);
            out += B64[w >> 18 & 63] + B64[w >> 12 & 63] + (i + 1 < n ? B64[w >> 6 & 63] : "=") + "=";
        }
        return out;
    }

    // data: URL for binary content. Uses the engine's btoa when present (as
    // Moonlight does), building the binary string in chunks to limit garbage.
    function toDataUrl(bytes, mime) {
        if (typeof G.btoa === "function") {
            var parts = [];
            for (var i = 0; i < bytes.length; i += 8192) parts.push(String.fromCharCode.apply(null, bytes.subarray(i, i + 8192)));
            return "data:" + mime + ";base64," + G.btoa(parts.join(""));
        }
        return "data:" + mime + ";base64," + toBase64(bytes);
    }

    JF.http = {toDataUrl: toDataUrl, encodeText: encodeText, decodeText: decodeText, buildRequest: buildRequest, createParser: createParser,
        fetchBytes: fetchBytes, fetchJson: fetchJson, toBase64: toBase64};
    if (typeof module !== "undefined" && module.exports) module.exports = JF.http;
})();
