/* Console platform: Nintendo SDK calls through CivSwitch's loader helpers
 * (call_rop, malloc, read32, ...), which exist only inside the loader's scope.
 *
 * - resolveNativeSymbol: export lookup in the SDK module's ELF hash table.
 * - transport: HTTP/1.1 over nn::socket (IPv4, plain HTTP). Sockets read and
 *   write straight into a validated JS ArrayBuffer through MoonlightStreamIO,
 *   avoiding per-byte native memory access.
 * - storage: one JSON settings file under save:/civhomebrew/jellyfin. */
/* Credits: this file runs on the low-level primitives of Gezine's CivSwitch loader
 * (call_rop, malloc, read32, alloc_string, ...; https://github.com/Gezine/CivSwitch, MIT).
 * The SDK export lookup, the nn::socket call sequence and errno handling, and the
 * nn::fs save-file pattern follow XITRIX's Moonlight-CivSwitch
 * (app/src/platform/native-network.js). The controller button reading (nn::hid
 * styles, state layout, controller ids) follows XITRIX's CivHomebrew
 * (app/src/platform/native.js). Socket I/O goes through MoonlightStreamIO from
 * Moonlight-CivSwitch's native-io.js, bundled at build time. */
(function () {
    "use strict";
    var G = typeof window !== "undefined" ? window : globalThis;
    var JF = G.JF = G.JF || {};

    function available() {
        return typeof sdk_base !== "undefined" && typeof call_rop === "function" && typeof malloc === "function";
    }

    function createResolver() {
        var cache = {};
        var mod = sdk_base + read32(sdk_base + 4n);
        if (read32(mod) !== 0x30444f4dn) throw new Error("Unrecognized SDK module.");
        var dynamic = mod + BigInt.asIntN(32, read32(mod + 4n)), tags = {};
        for (var i = 0; i < 128; i++) {
            var tag = Number(read64(dynamic + BigInt(i * 16)));
            if (!tag) break;
            var value = read64(dynamic + BigInt(i * 16 + 8));
            tags[tag] = value < sdk_base ? sdk_base + value : value;
        }
        var table = tags[4], strings = tags[5], symbols = tags[6];
        if (!table || !strings || !symbols) throw new Error("SDK export table unavailable.");
        var buckets = Number(read32(table)), count = Number(read32(table + 4n));
        return function resolve(name) {
            if (cache[name]) return cache[name];
            var hash = 0;
            for (var j = 0; j < name.length; j++) {
                hash = ((hash << 4) + name.charCodeAt(j)) >>> 0;
                var high = hash & 0xf0000000;
                if (high) hash ^= high >>> 24;
                hash = (hash & ~high) >>> 0;
            }
            var index = Number(read32(table + 8n + BigInt((hash % buckets) * 4)));
            for (var k = 0; index && k < count; k++) {
                var symbol = symbols + BigInt(index * 24);
                if (read_null_terminated_string(strings + read32(symbol)) === name) {
                    var offset = read64(symbol + 8n);
                    if (!offset) break;
                    return (cache[name] = sdk_base + offset);
                }
                index = Number(read32(table + 8n + BigInt((buckets + index) * 4)));
            }
            throw new Error("Missing SDK export: " + name);
        };
    }

    function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

    // One shared, validated heap: [0, 1 MiB) network slots, the rest for media.
    var HEAP_BYTES = 8 * 1048576, NET_BYTES = 1048576, SLOT = 256 * 1024, SEND = 32 * 1024;

    // options.resolveNativeSymbol replaces the SDK export lookup (used by the simulated-console tests).
    function create(options) {
        options = options || {};
        if (!available()) throw new Error("This app must be started from CivSwitch / CivHomebrew.");
        if (!G.MoonlightStreamIO) throw new Error("Native I/O module missing from the package.");
        var resolveNativeSymbol = options.resolveNativeSymbol || createResolver();
        var io = G.MoonlightStreamIO.create({resolveNativeSymbol: resolveNativeSymbol}, {batchReceive: false});
        var heap = new Uint8Array(new ArrayBuffer(HEAP_BYTES));
        var heapBase = null;
        function base() { if (heapBase === null) heapBase = io.heapAddress(heap); return heapBase; }

        function sock(name, args) { return Number(BigInt.asIntN(32, io.invoke("_ZN2nn6socket" + name, args))); }
        function errno() { return Number(io.invoke("_ZN2nn6socket12GetLastErrnoEv", [])); }

        // Fixed slots so concurrent requests (artwork while streaming) never share buffers.
        var slots = [], waiting = [];
        for (var s = 0; s < NET_BYTES / SLOT; s++) slots.push({offset: s * SLOT, busy: false});
        function acquire() {
            for (var i = 0; i < slots.length; i++) if (!slots[i].busy) { slots[i].busy = true; return Promise.resolve(slots[i]); }
            return new Promise(function (resolve) { waiting.push(resolve); });
        }
        function release(slot) {
            var next = waiting.shift();
            if (next) next(slot); else slot.busy = false;
        }

        // ---- Name lookup ----------------------------------------------------
        // Public DNS over UDP first (UDP is proven on the console by Moonlight's
        // streaming); the console's own resolver is a fallback for names only the
        // local network knows. Results are cached for their TTL (60 s to 1 h).
        var dnsCache = {}, systemResolver;
        var DNS_SERVERS = [[1, 1, 1, 1], [8, 8, 8, 8], [9, 9, 9, 9]];
        function isIpv4(host) { return /^\d{1,3}(\.\d{1,3}){3}$/.test(host) && host.split(".").every(function (o) { return Number(o) <= 255; }); }

        async function udpLookup(host, server, slot, timeoutMs) {
            var id = Math.floor(Math.random() * 65536), query = JF.dns.buildQuery(id, host);
            var addrAt = slot.offset, queryAt = slot.offset + 64, recvAt = slot.offset + SEND;
            heap.set([16, 2, 0, 53].concat(server, [0, 0, 0, 0, 0, 0, 0, 0]), addrAt);
            heap.set(query, queryAt);
            var fd = sock("6SocketEiii", [2, 2, 0]);
            if (fd < 0) throw new Error("Cannot create a UDP socket.");
            try {
                var flags = sock("5FcntlEiiz", [fd, 3, 0]);
                if (flags < 0 || sock("5FcntlEiiz", [fd, 4, flags | 0x800]) < 0) throw new Error("Cannot configure the UDP socket.");
                if (sock("6SendToEiPKvmiPK8sockaddrj", [fd, base() + BigInt(queryAt), query.length, 0, base() + BigInt(addrAt), 16]) !== query.length) throw new Error("DNS query was not sent (errno " + errno() + ").");
                var deadline = Date.now() + timeoutMs;
                while (Date.now() < deadline) {
                    var got = sock("8RecvFromEiPvmiP8sockaddrPj", [fd, base() + BigInt(recvAt), 1500, 0x80, 0, 0]);
                    if (got > 0) {
                        try { return JF.dns.parseResponse(heap.slice(recvAt, recvAt + got), id, host); }
                        catch (e) { if (/different query|Not a DNS/.test(e.message)) continue; throw e; }
                    }
                    var e2 = errno();
                    if (got < 0 && e2 !== 11 && e2 !== 35) throw new Error("DNS receive failed (errno " + e2 + ").");
                    await sleep(10);
                }
                throw new Error("No DNS reply from " + server.join("."));
            } finally { sock("5CloseEi", [fd]); }
        }

        function systemLookup(host) {
            if (systemResolver === undefined) {
                systemResolver = null;
                ["_ZN2nn6socket16GetHostEntByNameEPKc", "_ZN2nn6socket13GetHostByNameEPKc"].some(function (name) {
                    try { systemResolver = {name: name, address: resolveNativeSymbol(name)}; return true; } catch (e) { return false; }
                });
            }
            if (!systemResolver) throw new Error("the console's resolver is not available");
            var p = alloc_string(host);
            try {
                var ent = call_rop(systemResolver.address, p);                        // struct hostent*
                if (!ent) throw new Error("the console's resolver found no address");
                var type = Number(read32(ent + 16n)), length = Number(read32(ent + 20n)), list = read64(ent + 24n);
                if (type !== 2 || length !== 4 || !list) throw new Error("the console's resolver returned no IPv4 address");
                var first = read64(list);
                if (!first) throw new Error("the console's resolver returned an empty list");
                var v = Number(read32(first));
                return {addresses: [[v & 255, v >>> 8 & 255, v >>> 16 & 255, v >>> 24 & 255].join(".")], ttl: 300, via: "console resolver"};
            } finally { free(p); }
        }

        async function lookup(host, report) {
            if (isIpv4(host)) return host.split(".").map(Number);
            var cached = dnsCache[host];
            if (cached && cached.expires > Date.now()) return cached.octets;
            var slot = await acquire(), errors = [];
            try {
                for (var i = 0; i < DNS_SERVERS.length; i++) {
                    try {
                        var r = await udpLookup(host, DNS_SERVERS[i], slot, 1500);
                        return remember(host, r, "public DNS " + DNS_SERVERS[i].join("."), report);
                    } catch (e) {
                        errors.push(DNS_SERVERS[i].join(".") + ": " + e.message);
                        if (e.rcode === 3) break;                                   // the name does not exist publicly
                    }
                }
            } finally { release(slot); }
            try { return remember(host, systemLookup(host), "console resolver", report); }
            catch (e) { errors.push(e.message); }
            throw new Error("Cannot find \"" + host + "\": " + errors.join("; "));
        }
        function remember(host, result, via, report) {
            var octets = result.addresses[0].split(".").map(Number);
            dnsCache[host] = {octets: octets, expires: Date.now() + Math.max(60, Math.min(3600, result.ttl || 300)) * 1000};
            if (report) report("Found " + host + " at " + result.addresses[0] + " via " + via + (result.cname ? " (alias of " + result.cname + ")" : ""));
            return octets;
        }

        // ---- TLS (the console's nn::ssl) --------------------------------------
        // Function names are from the console's export table. Enum values follow the
        // Switch SDK: SslVersion Auto = 1; VerifyOption PeerCa|HostName|DateCheck = 7;
        // IoMode NonBlocking = 2. Untested on hardware; every step reports its result.
        var tlsVerify = true, WOULD_BLOCK = 123 | (204 << 9);
        function ssl(name, args) { return Number(BigInt.asUintN(32, io.invoke("_ZN2nn3ssl" + name, args))); }
        function resultText(r) { return r ? (2000 + (r & 0x1ff)) + "-" + String((r >>> 9) & 0x1fff).padStart(4, "0") : "ok"; }
        function zeroed(n) { var p = malloc(n); if (!p) throw new Error("Out of memory."); write_buffer(p, new Uint8Array(n)); return p; }

        // owner.ownsSocket is set as soon as the socket is handed to the TLS service, so the
        // caller never closes it again, even if the handshake then fails.
        async function tlsOpen(fd, host, check, report, owner) {
            var t = {ctx: zeroed(256), conn: zeroed(256), out: zeroed(16), ctxMade: false, connMade: false, ownsSocket: false};
            function step(label, r) { if (r) throw new Error("TLS " + label + " failed: " + resultText(r)); }
            try {
                ssl("7ContextC1Ev", [t.ctx]);
                step("context", ssl("7Context6CreateENS1_10SslVersionE", [t.ctx, 1])); t.ctxMade = true;
                ssl("10ConnectionC1Ev", [t.conn]);
                step("connection", ssl("10Connection6CreateEPNS0_7ContextE", [t.conn, t.ctx])); t.connMade = true;
                step("socket handoff", ssl("10Connection19SetSocketDescriptorEi", [t.conn, fd])); t.ownsSocket = owner.ownsSocket = true;
                var name = alloc_string(host);
                try { step("server name", ssl("10Connection11SetHostNameEPKcj", [t.conn, name, host.length])); } finally { free(name); }
                step("verify option", ssl("10Connection15SetVerifyOptionENS1_12VerifyOptionE", [t.conn, tlsVerify ? 7 : 0]));
                step("non-blocking mode", ssl("10Connection9SetIoModeENS1_6IoModeE", [t.conn, 2]));
                for (;;) {
                    check();
                    var r = ssl("10Connection11DoHandshakeEv", [t.conn]);
                    if (!r) break;
                    if (r === WOULD_BLOCK) { await sleep(10); continue; }
                    var detail = "";
                    if (!ssl("10Connection18GetVerifyCertErrorEPNS_6ResultE", [t.conn, t.out])) {
                        var v = Number(read32(t.out));
                        if (v) detail = " (certificate problem " + resultText(v) + (tlsVerify ? "; if the server uses a self-signed certificate, turn off certificate checking in Settings" : "") + ")";
                    }
                    throw new Error("TLS handshake failed: " + resultText(r) + detail);
                }
                if (report) report("Secure connection established" + (tlsVerify ? " (certificate verified)" : " (certificate NOT checked)"));
                return t;
            } catch (e) { tlsClose(t); throw e; }
        }
        function tlsWrite(t, address, length) {
            var r = ssl("10Connection5WriteEPKcPij", [t.conn, address, t.out, length]);
            if (r === WOULD_BLOCK) return 0;
            if (r) throw new Error("TLS write failed: " + resultText(r));
            return Number(read32(t.out));
        }
        // > 0 bytes read, 0 would block, -1 closed or failed (detail in t.lastError).
        function tlsRead(t, address, length) {
            var r = ssl("10Connection4ReadEPcPij", [t.conn, address, t.out, length]);
            if (r === WOULD_BLOCK) return 0;
            if (r) { t.lastError = resultText(r); return -1; }
            var n = Number(read32(t.out));
            return n > 0 ? n : -1;
        }
        function tlsClose(t) {
            if (!t) return;
            try { if (t.connMade) ssl("10Connection7DestroyEv", [t.conn]); } catch (e) {}
            try { ssl("10ConnectionD1Ev", [t.conn]); } catch (e) {}
            try { if (t.ctxMade) ssl("7Context7DestroyEv", [t.ctx]); } catch (e) {}
            try { ssl("7ContextD1Ev", [t.ctx]); } catch (e) {}
            free(t.out); free(t.conn); free(t.ctx);
        }

        // ---- HTTP over TCP (plain or TLS) -------------------------------------
        async function request(options, handlers) {
            var port = options.port || (options.tls ? 443 : 80), report = options.report;
            if (!(port >= 1 && port <= 65535)) throw new Error("Invalid port.");
            var wire = JF.http.buildRequest(options);
            if (wire.length > SEND - 64) throw new Error("Request too large.");
            var timeout = options.timeoutMs || 15000, deadline = Date.now() + timeout;
            var signal = options.signal || {aborted: false};
            function check() {
                if (signal.aborted) throw new Error("Request canceled.");
                if (Date.now() > deadline) throw new Error("The server did not respond in time.");
            }
            var octets = await lookup(options.host, report);
            var slot = await acquire(), fd = -1, tls = null, tlsOwner = {ownsSocket: false}, head = null, ended = false;
            var recvOffset = slot.offset + SEND, recvBytes = 32768;
            try {
                check();
                // sockaddr_in as the SDK expects it: length, family, port (BE), address.
                heap.set([16, 2, port >> 8, port & 255].concat(octets, [0, 0, 0, 0, 0, 0, 0, 0]), slot.offset);
                fd = sock("6SocketEiii", [2, 1, 0]);
                if (fd < 0) throw new Error("Cannot create a network socket.");
                var flags = sock("5FcntlEiiz", [fd, 3, 0]);
                if (flags < 0 || sock("5FcntlEiiz", [fd, 4, flags | 0x800]) < 0) throw new Error("Cannot configure the socket.");
                var connected = sock("7ConnectEiPK8sockaddrj", [fd, base() + BigInt(slot.offset), 16]);
                while (connected < 0) {
                    var e = errno();
                    if (e === 56 || e === 106) break;                       // already connected
                    if ([115, 114, 36, 37, 11, 35].indexOf(e) < 0) throw new Error(e === 111 || e === 61 ? "Connection refused. Is Jellyfin reachable on that address and port?" : "Cannot connect (errno " + e + ").");
                    check(); await sleep(15);
                    connected = sock("7ConnectEiPK8sockaddrj", [fd, base() + BigInt(slot.offset), 16]);
                }
                if (report) report("Connected to " + octets.join(".") + ":" + port);
                if (options.tls) { tls = await tlsOpen(fd, options.host, check, report, tlsOwner); }
                var wireAt = slot.offset + 64;
                heap.set(wire, wireAt);
                var sent = 0;
                while (sent < wire.length) {
                    check();
                    var n;
                    if (tls) n = tlsWrite(tls, base() + BigInt(wireAt + sent), wire.length - sent);
                    else {
                        n = sock("4SendEiPKvmi", [fd, base() + BigInt(wireAt + sent), wire.length - sent, 0x80]);
                        if (n < 0) { var se = errno(); if (se !== 11 && se !== 35) throw new Error("Network send failed (errno " + se + ")."); n = 0; }
                    }
                    if (n > 0) sent += n; else await sleep(5);
                }
                var parser = JF.http.createParser({
                    noBody: options.method === "HEAD",
                    onHead: function (h) { head = h; if (handlers.onHead) handlers.onHead(h); },
                    onBody: function (b) { if (handlers.onBody) handlers.onBody(b); },
                    onEnd: function () { ended = true; }
                });
                var lastYield = Date.now();
                while (!ended) {
                    check();
                    var got;
                    if (tls) got = tlsRead(tls, base() + BigInt(recvOffset), recvBytes);
                    else {
                        got = sock("4RecvEiPvmi", [fd, base() + BigInt(recvOffset), recvBytes, 0x80]);
                        if (got === 0) got = -1;
                        else if (got < 0) { var re = errno(); if (re !== 11 && re !== 35) throw new Error("Network receive failed (errno " + re + ")."); got = 0; }
                    }
                    if (got > 0) {
                        deadline = Date.now() + timeout;                     // inactivity timeout
                        var sliceStart = Date.now();
                        parser.push(heap.slice(recvOffset, recvOffset + got));
                        var slice = Date.now() - sliceStart;
                        if (slice > netStats.longestSliceMs) netStats.longestSliceMs = slice;
                        if (slice > netStats.windowMaxMs) netStats.windowMaxMs = slice;
                        // Keep the frame loop (video/audio delivery) running during big downloads.
                        if (Date.now() - lastYield >= 4) { await sleep(0); lastYield = Date.now(); }
                    } else if (got < 0) {
                        if (tls && !head) throw new Error("Secure connection closed before a response: " + (tls.lastError || "closed"));
                        parser.eof(); break;
                    } else { await sleep(4); lastYield = Date.now(); }
                }
                if (!head) throw new Error("No response from the server.");
                return {status: head.status, headers: head.headers};
            } finally {
                if (tls) tlsClose(tls);
                if (tlsOwner.ownsSocket) fd = -1;                           // the TLS service closed it
                if (fd >= 0) sock("5CloseEi", [fd]);
                release(slot);
            }
        }

        // Step-by-step check of an address, for the Test connection screen.
        async function testConnection(address, path) {
            var lines = [], ok = false, started = Date.now();
            function report(text) { lines.push(text); }
            try {
                report("Address: " + (address.tls ? "https" : "http") + "://" + address.host + ":" + address.port + (address.basePath || ""));
                var res = await JF.http.fetchJson({request: request}, {host: address.host, port: address.port, tls: address.tls, method: "GET",
                    path: (address.basePath || "") + path, headers: {Accept: "application/json"}, timeoutMs: 15000, maxBytes: 1048576, report: report});
                report("Jellyfin replied: HTTP " + res.status + (res.data && res.data.ServerName ? " from \"" + res.data.ServerName + "\" " + (res.data.Version || "") : ""));
                ok = res.status === 200 && !!(res.data && res.data.Id);
                if (!ok) report(res.status === 200 ? "That address answered, but not as a Jellyfin server. Check the path after the address." : "Unexpected reply; check the address and path.");
            } catch (e) { report("FAILED: " + e.message); }
            report("Took " + (Date.now() - started) + " ms");
            return {ok: ok, lines: lines};
        }

        var netStats = {longestSliceMs: 0, windowMaxMs: 0};

        // ---- Settings file -------------------------------------------------
        var ROOT = "save:/civhomebrew/jellyfin", FILE = ROOT + "/settings.json";
        function fs(name, args) { return call_rop.apply(null, [resolveNativeSymbol(name)].concat(args.map(BigInt))); }
        function code(v) { return Number(v & 0x3fffffn); }
        function pathCall(name, path, allowed) {
            var p = alloc_string(path);
            try { var r = code(fs(name, [p])); if (r && r !== allowed) throw new Error(name + " failed: 0x" + r.toString(16)); }
            finally { free(p); }
        }
        var storage = {
            load: function () {
                var p = alloc_string(FILE), handle = malloc(8), size = malloc(8), buffer = 0n, opened = false;
                try {
                    var r = code(fs("_ZN2nn2fs8OpenFileEPNS0_10FileHandleEPKci", [handle, p, 1]));
                    if (r === 0x202) return null;                            // not found
                    if (r) throw new Error("Settings open failed: 0x" + r.toString(16));
                    opened = true;
                    if (code(fs("_ZN2nn2fs11GetFileSizeEPlNS0_10FileHandleE", [size, read64(handle)]))) throw new Error("Settings size query failed.");
                    var length = Number(read64(size));
                    if (length <= 0 || length > 65536) return null;
                    buffer = malloc(length);
                    if (code(fs("_ZN2nn2fs8ReadFileENS0_10FileHandleElPvm", [read64(handle), 0, buffer, length]))) throw new Error("Settings read failed.");
                    return JSON.parse(bytes_to_string(read_buffer(buffer, length)));
                } catch (e) { JF.log && JF.log("Settings load: " + e.message); return null; }
                finally { if (opened) fs("_ZN2nn2fs9CloseFileENS0_10FileHandleE", [read64(handle)]); if (buffer) free(buffer); free(size); free(handle); free(p); }
            },
            save: function (data) {
                ensureDirs([]);
                writeFile(FILE, text_encode(JSON.stringify(data)));
                pathCall("_ZN2nn2fs6CommitEPKc", "save", 0);
            },
            // Text file under save:/civhomebrew/jellyfin/ (readable over CivHomebrew FTP).
            writeText: function (relative, text) {
                if (!/^[A-Za-z0-9_.-]+(\/[A-Za-z0-9_.-]+)*$/.test(relative) || relative.indexOf("..") >= 0) throw new Error("Invalid file name.");
                var parts = relative.split("/");
                ensureDirs(parts.slice(0, -1));
                writeFile(ROOT + "/" + relative, text_encode(text));
                pathCall("_ZN2nn2fs6CommitEPKc", "save", 0);
                return "civhomebrew/jellyfin/" + relative;
            }
        };

        function ensureDirs(sub) {
            pathCall("_ZN2nn2fs15CreateDirectoryEPKc", "save:/civhomebrew", 0x402);
            pathCall("_ZN2nn2fs15CreateDirectoryEPKc", ROOT, 0x402);
            for (var i = 0, path = ROOT; i < sub.length; i++) { path += "/" + sub[i]; pathCall("_ZN2nn2fs15CreateDirectoryEPKc", path, 0x402); }
        }

        function writeFile(path, bytes) {
            var p = alloc_string(path), handle = malloc(8), option = malloc(8), buffer = malloc(bytes.length + 1), opened = false;
            try {
                var created = code(fs("_ZN2nn2fs10CreateFileEPKcl", [p, bytes.length]));
                if (created && created !== 0x402) throw new Error("File create failed: 0x" + created.toString(16));
                if (code(fs("_ZN2nn2fs8OpenFileEPNS0_10FileHandleEPKci", [handle, p, 6]))) throw new Error("File open for write failed.");
                opened = true;
                if (code(fs("_ZN2nn2fs11SetFileSizeENS0_10FileHandleEl", [read64(handle), bytes.length]))) throw new Error("File resize failed.");
                write32(option, 1n); write_buffer(buffer, bytes);
                if (code(fs("_ZN2nn2fs9WriteFileENS0_10FileHandleElPKvmRKNS0_11WriteOptionE", [read64(handle), 0, buffer, bytes.length, option]))) throw new Error("File write failed.");
            } finally { if (opened) fs("_ZN2nn2fs9CloseFileENS0_10FileHandleE", [read64(handle)]); free(p); free(handle); free(option); free(buffer); }
        }

        // ---- Controller buttons --------------------------------------------
        // The engine only reports navigation, A and B as input events. Other
        // buttons are read from the controller directly through nn::hid, the
        // way CivHomebrew reads X: find the active controller, read its state,
        // and return the NpadButton bit set (A=0x1, B=0x2, X=0x4, Y=0x8,
        // L=0x40, R=0x80, ZL=0x100, ZR=0x200, Plus=0x400, Minus=0x800).
        function createController() {
            var prefix = "_ZN2nn3hid6detail", owned = [], selected = null, nextScan = 0, closed = false;
            var styleFn = resolveNativeSymbol(prefix + "15GetNpadStyleSetEPNS_4util10BitFlagSetILi32ENS0_12NpadStyleTagEEERKj");
            var getters = [[2, "17NpadHandheldState"], [1, "16NpadFullKeyState"], [4, "16NpadJoyDualState"]].map(function (g) {
                return {bit: g[0], address: resolveNativeSymbol(prefix + "13GetNpadStatesEPiPNS0_" + g[1] + "EiRKj")};
            });
            function take(n) { var p = malloc(n); if (!p) throw new Error("Controller allocation failed."); owned.push(p); return p; }
            var id = take(8), style = take(8), count = take(8), sample = take(64);
            function read(controller, getter) {
                write32(id, BigInt(controller)); write32(count, 0n);
                if (code(call_rop(getter.address, count, sample, 1n, id))) throw new Error("Controller state failed.");
                if (read32(count) !== 1n || !(read32(sample + 32n) & 1n)) return null;    // not connected
                return read64(sample + 8n);
            }
            return {
                poll: function () {
                    if (closed) return null;
                    if (selected) { var v = read(selected.id, selected.getter); if (v !== null) return v; selected = null; nextScan = 0; }
                    if (Date.now() < nextScan) return null;
                    nextScan = Date.now() + 500;
                    var ids = [32, 0, 1, 2, 3, 4, 5, 6, 7];                     // handheld first, then players 1-8
                    for (var i = 0; i < ids.length; i++) {
                        write32(id, BigInt(ids[i])); write32(style, 0n);
                        if (code(call_rop(styleFn, style, id))) throw new Error("Controller style failed.");
                        var bits = Number(read32(style));
                        for (var g = 0; g < getters.length; g++) {
                            if (!(bits & getters[g].bit)) continue;
                            var value = read(ids[i], getters[g]);
                            if (value !== null) { selected = {id: ids[i], getter: getters[g]}; return value; }
                        }
                    }
                    return null;
                },
                close: function () { if (closed) return; closed = true; owned.reverse().forEach(free); owned = []; }
            };
        }

        // ---- Keep the screen awake during playback -----------------------------
        // The Switch dims and sleeps without button presses. The SDK's media playback
        // section tells the system a video is playing; SetAutoSleepDisabled is the
        // fallback. Looking up a missing export is harmless; availability is logged.
        var awake = {fn: undefined, on: false};
        function keepAwake(on) {
            on = !!on;
            if (awake.fn === undefined) {
                awake.fn = null;
                try { awake.fn = {kind: "section", begin: resolveNativeSymbol("_ZN2nn2oe25BeginMediaPlaybackSectionEv"), end: resolveNativeSymbol("_ZN2nn2oe23EndMediaPlaybackSectionEv"), label: "media playback section"}; } catch (e) {}
                if (!awake.fn) try { awake.fn = {kind: "flag", set: resolveNativeSymbol("_ZN2nn2oe20SetAutoSleepDisabledEb"), label: "auto-sleep disabled"}; } catch (e) {}
                if (JF.log) JF.log(awake.fn ? "Screen stays awake during playback (" + awake.fn.label + ")" : "Keeping the screen awake is not available in this game's SDK");
            }
            if (!awake.fn || awake.on === on) return !!awake.fn;
            try {
                if (awake.fn.kind === "section") call_rop(on ? awake.fn.begin : awake.fn.end);
                else call_rop(awake.fn.set, on ? 1n : 0n);
                awake.on = on;
            } catch (e) { if (JF.log) JF.log("Keep-awake failed: " + e.message); awake.fn = null; }
            return true;
        }

        return {
            keepAwake: keepAwake,
            createController: createController,
            transport: {request: request, stats: netStats},
            testConnection: testConnection,
            setTlsVerify: function (on) { tlsVerify = on !== false; },
            storage: storage,
            createSink: function (options) { return JF.createNativeSink(io, heap, NET_BYTES, options); },
            sleep: sleep,
            close: function () { try { keepAwake(false); } catch (e) {} try { io.close(); } catch (e) {} }
        };
    }

    JF.nativePlatform = {available: available, create: create};
})();
