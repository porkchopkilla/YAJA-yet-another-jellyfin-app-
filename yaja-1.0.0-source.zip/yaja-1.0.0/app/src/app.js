/* YAJA (Yet another jellyfin app): screens, input, playback control and lifetime.
 * JF.startApp(platform) -> {close, lifetime}. platform = {transport, storage, createSink, sleep, close}. */
/* Credits: the app lifetime contract (window.__civswitchApp, the lifetime promise,
 * full cleanup on close) and engine input handling (InputAction names, nav-move
 * repeat) follow XITRIX's CivHomebrew launcher and its Hello example. Reading X/Y/L/R
 * natively follows CivHomebrew's controller polling. Showing decoded video as a
 * live:/ background image follows Moonlight-CivSwitch's stream screen (XITRIX).
 * The Jellyfin REST routes come from the Jellyfin server source; this client is
 * independent and not affiliated with the Jellyfin project. */
(function () {
    "use strict";
    var G = typeof window !== "undefined" ? window : globalThis;
    var JF = G.JF = G.JF || {};
    var VERSION = "1.0.0";
    var QUALITIES = [
        {label: "720p - 4 Mbps (recommended)", maxWidth: 1280, maxHeight: 720, videoBitrate: 4000000},
        {label: "720p - 6 Mbps", maxWidth: 1280, maxHeight: 720, videoBitrate: 6000000},
        {label: "1080p - 8 Mbps", maxWidth: 1920, maxHeight: 1080, videoBitrate: 8000000},
        {label: "1080p - 12 Mbps", maxWidth: 1920, maxHeight: 1080, videoBitrate: 12000000},
        {label: "480p - 2 Mbps (slow network)", maxWidth: 854, maxHeight: 480, videoBitrate: 2000000}
    ];

    function startApp(platform) {
        var ui = JF.ui, C = JF.colors, el = ui.el;
        var closed = false, finish, lifetime = new Promise(function (r) { finish = r; });
        var removers = [], timers = new Set(), diagnostics = [];
        var log = JF.log = function (message) {
            diagnostics.push(new Date().toISOString().slice(11, 19) + "  " + String(message).slice(0, 300));
            if (diagnostics.length > 80) diagnostics.shift();
        };

        // ---- Settings ---------------------------------------------------------
        var settings = null;
        try { settings = platform.storage.load(); } catch (e) { log("Settings: " + e.message); }
        settings = Object.assign({server: "", host: "", port: 8096, deviceId: "", token: null, userId: null, userName: "", quality: 0, autoplay: true, tls: false, basePath: "", tlsVerify: true, tz: "auto"}, settings || {});
        // Older versions stored only host and port.
        if (!settings.server && settings.host) settings.server = "http://" + settings.host + ":" + settings.port;
        // Versions before 0.1.9 stored no scheme or path; derive them from the address.
        try { if (settings.server) { var parsed0 = JF.jellyfin.parseServerAddress(settings.server); settings.tls = parsed0.tls; settings.basePath = parsed0.basePath; } } catch (e) {}
        if (platform.setTlsVerify) platform.setTlsVerify(settings.tlsVerify);
        if (!settings.deviceId) settings.deviceId = "civswitch-" + Math.random().toString(16).slice(2) + Date.now().toString(16);
        function persist() { try { platform.storage.save(settings); } catch (e) { log("Saving settings failed: " + e.message); } }

        var api = null;
        function makeApi() {
            api = JF.jellyfin.create({transport: platform.transport, host: settings.host, port: settings.port, tls: settings.tls, basePath: settings.basePath, deviceId: settings.deviceId,
                deviceName: "Nintendo Switch (CivSwitch)", client: "YAJA", version: VERSION, token: settings.token, userId: settings.userId});
        }

        // ---- Layout -----------------------------------------------------------
        var root = el("div", document.body, {position: "fixed", left: "0", top: "0", right: "0", bottom: "0", backgroundColor: C.bg, color: C.text,
            fontFamily: "BodyFont, Arial, sans-serif", zIndex: "1", overflow: "hidden", outline: "none"});
        root.id = "jellyfin-civswitch"; root.tabIndex = -1;
        var header = el("div", root, {position: "absolute", left: "0", right: "0", top: "0", height: "84px", display: "flex", alignItems: "center", padding: "0 48px", boxSizing: "border-box", backgroundColor: C.bg, zIndex: "5"});
        var logo = el("div", header, {fontSize: "28px", fontWeight: "bold", color: C.text, marginRight: "26px"}, "YAJA");
        var titleEl = el("div", header, {fontSize: "24px", color: C.dim, flex: "1", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis"});
        var hintEl = el("div", header, {fontSize: "17px", color: C.dim});
        var viewport = el("div", root, {position: "absolute", left: "0", right: "0", top: "84px", bottom: "56px", overflowY: "auto", overflowX: "hidden", zIndex: "1"});
        var content = el("div", viewport, {padding: "28px 48px", boxSizing: "border-box"});
        var statusEl = el("div", root, {position: "absolute", left: "0", right: "0", bottom: "0", height: "56px", lineHeight: "56px", padding: "0 48px", fontSize: "19px", color: C.dim, backgroundColor: C.bg, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", zIndex: "2"});
        // A screen may show artwork behind everything (the TV show page uses its backdrop).
        var backdrop = el("div", root, {position: "absolute", left: "0", top: "0", right: "0", bottom: "0", zIndex: "0", overflow: "hidden", display: "none"});
        var backdropImg = el("img", backdrop, {position: "absolute", left: "0", top: "0", display: "none"});
        var backdropDim = el("div", backdrop, {position: "absolute", left: "0", top: "0", right: "0", bottom: "0", backgroundColor: "rgba(12,12,15,0.7)"});
        var backdropFade = el("img", backdrop, {position: "absolute", left: "0", top: "0", display: "none"});
        backdropFade.src = JF.scrimUrl;
        // options.dim: darkening over the whole image; options.fade: the bottom fade for text.
        function setBackdrop(pick, options) {
            options = options || {};
            if (!pick) { backdrop.style.display = "none"; artwork.release(backdropImg); header.style.backgroundColor = C.bg; statusEl.style.backgroundColor = C.bg; return; }
            backdropDim.style.backgroundColor = "rgba(12,12,15," + (options.dim !== undefined ? options.dim : 0.7) + ")";
            var sw = root.clientWidth || viewport.clientWidth || 1280, sh = root.clientHeight || 720;
            backdropFade.style.display = options.fade ? "" : "none";
            backdropFade.style.width = sw + "px"; backdropFade.style.height = sh + "px";
            var w = root.clientWidth || viewport.clientWidth || 1280, h = Math.round(w * 9 / 16), screenH = root.clientHeight || 720;
            if (h < screenH) { h = screenH; w = Math.round(h * 16 / 9); }               // cover the whole screen
            backdropImg.style.width = w + "px"; backdropImg.style.height = h + "px";
            backdropImg.style.left = Math.round(((root.clientWidth || w) - w) / 2) + "px";
            backdrop.style.display = "";
            header.style.backgroundColor = "transparent"; statusEl.style.backgroundColor = "transparent";
            artwork.show(backdropImg, pick.id, pick.tag, 540, pick.kind);
        }
        // Splash: the app icon while Home loads behind it (including visible artwork), so
        // the first screen appears complete. Shown at least 0.7 s, never more than 12 s.
        // The fade steps opacity from script (no CSS animation, see ui-kit).
        var splash = el("div", root, {position: "absolute", left: "0", top: "0", right: "0", bottom: "0", zIndex: "40", backgroundColor: C.bg,
            display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center"});
        var splashIcon = el("img", splash, {width: "240px", height: "240px"});
        splashIcon.src = JF.appIconUrl;
        el("div", splash, {fontSize: "26px", fontWeight: "bold", color: C.text, marginTop: "18px"}, "Yet another jellyfin app");
        var splashNote = el("div", splash, {fontSize: "18px", color: C.dim, marginTop: "14px", minHeight: "24px"}, "");
        var splashShownAt = Date.now(), splashDone = false;
        function hideSplash() {
            if (splashDone) return;
            splashDone = true;
            var wait = Math.max(0, 700 - (Date.now() - splashShownAt)), step = 0;
            function fade() {
                step++;
                splash.style.opacity = String(Math.max(0, 1 - step / 6));
                if (step < 6) { var t = setTimeout(fade, 45); timers.add(t); }
                else if (splash.parentNode) splash.parentNode.removeChild(splash);
            }
            var t0 = setTimeout(fade, wait); timers.add(t0);
        }
        // Home is ready: wait for the visible artwork (at most 2.5 s more), then reveal it.
        function homeReady() {
            if (splashDone) return;
            var until = Date.now() + 2500;
            (function check() {
                if (artwork.idle() || Date.now() > until) { hideSplash(); return; }
                var t = setTimeout(check, 100); timers.add(t);
            })();
        }
        var splashLimit = setTimeout(hideSplash, 12000); timers.add(splashLimit);
        var nav = ui.createNavigator(viewport);
        var keyboard = ui.createKeyboard(root);
        var artwork = ui.createArtwork(function (id, tag, h, kind) { return api.fetchImage(id, kind || "Primary", tag, h); }, log);

        function status(text, isError) { statusEl.textContent = text || ""; statusEl.style.color = isError ? C.danger : C.dim; if (text) log((isError ? "Error: " : "") + text); }

        // ---- Screen stack -------------------------------------------------------
        var stack = [], current = null, busy = false;
        function show(screen, replace) {
            if (current && current.leave) current.leave();
            if (replace && stack.length) stack.pop();
            stack.push(screen); render(screen);
        }
        function back() {
            if (stack.length <= 1) return false;
            if (current && current.leave) current.leave();
            stack.pop(); render(stack[stack.length - 1], true);
            return true;
        }
        function render(screen, restoring) {
            setBackdrop(null);
            screen.restoreTo = restoring && screen.saved ? {row: screen.saved.row, col: screen.saved.col} : null;
            current = screen; artwork.reset();
            ui.clear(content); viewport.scrollTop = 0;
            titleEl.textContent = screen.title || ""; hintEl.textContent = screen.hint || "A: select   B: back";
            header.style.display = viewport.style.display = statusEl.style.display = screen.fullscreen ? "none" : "";
            var rows = screen.build(content) || [];
            nav.setRows(rows, false);
            if (screen.restoreTo) nav.focus(screen.restoreTo.row, screen.restoreTo.col);
            else if (screen.initialFocus) nav.focus(screen.initialFocus.row, screen.initialFocus.col);
        }
        nav.onMove(function (item, row, col) { if (current) current.saved = {row: row, col: col}; if (item && item.onFocus) item.onFocus(); updateArtwork(row); });
        // Only rows near the focus hold artwork; the rest give their images back.
        function updateArtwork(focusRow) {
            var rows = nav.rows();
            for (var r = 0; r < rows.length; r++) {
                for (var i = 0; i < rows[r].length; i++) {
                    var card = rows[r][i];
                    if (!card.img) continue;
                    var near = r >= focusRow - 1 && r <= focusRow + 2 && card.el.style.display !== "none";
                    card.img.__jfWanted = near;
                    if (near) artwork.show(card.img, card.imageId, card.imageTag, card.imageHeight, card.imageKind);
                    else artwork.release(card.img);
                }
            }
        }

        function failed(e) {
            hideSplash();
            status(e.message || String(e), true);
            if (e.status === 401 && settings.token) { settings.token = null; settings.userId = null; persist(); makeApi(); stack = [connectScreen()]; show(loginScreen()); }
        }
        // User-triggered actions (connect, sign in): one at a time, input blocked meanwhile.
        async function guard(label, fn) {
            if (busy) return;
            busy = true; status(label);
            try { await fn(); if (statusEl.textContent === label) status(""); }
            catch (e) { failed(e); }
            finally { busy = false; }
        }
        // Screen data loads: never blocked by an action that opened the screen.
        async function load(label, fn) {
            status(label);
            try { await fn(); if (statusEl.textContent === label) status(""); }
            catch (e) { failed(e); }
        }

        function heading(parent, text) { return el("div", parent, {fontSize: "27px", fontWeight: "bold", color: C.text, margin: "22px 0 8px"}, text); }

        // Poster cards in fixed rows sized to the screen; returns one focus row per line.
        function columns(landscape) {
            var width = viewport.clientWidth || 1280;
            if (landscape) return width >= 1700 ? 4 : width >= 1000 ? 3 : 2;
            return width >= 1700 ? 6 : width >= 1300 ? 5 : width >= 950 ? 4 : 3;
        }
        // options.landscape: 16:9 cards (Home); otherwise 2:3 posters (libraries).
        function cardGrid(parent, items, onPick, maxRows, options) {
            var landscape = !!(options && options.landscape);
            var cols = columns(landscape), width = viewport.clientWidth || 1280, gap = 24;
            var w = Math.max(150, Math.min(landscape ? 400 : 240, Math.floor((width - 96 - gap * (cols - 1)) / cols)));
            // options.gradient: a blue-to-purple frame around the artwork (Home rows).
            var gradient = !!(options && options.gradient), pad = gradient ? 10 : 0;
            var aw = w - pad * 2, h = landscape ? Math.round(aw * 9 / 16) : Math.round(aw * 1.5);
            var cardHeight = h + pad * 2 + 60;
            var rows = [], carousel = !!(options && options.carousel);
            var counter = carousel && items.length > cols ? el("div", parent, {fontSize: "17px", color: C.dim, margin: "-6px 0 2px"}) : null;
            for (var start = 0; start < items.length && (!maxRows || rows.length < maxRows); start += cols) {
                var line = el("div", parent, {display: "flex", padding: "8px 4px"});
                var slice = carousel ? items : items.slice(start, start + cols);
                rows.push(slice.map(function (it) {
                    var card = el("div", line, gradient
                        ? {position: "relative", width: w + "px", height: cardHeight + "px", boxSizing: "border-box", padding: pad + "px", marginRight: gap + "px", flexShrink: "0", borderRadius: "18px", overflow: "hidden", outline: "4px solid transparent"}
                        : {width: w + "px", marginRight: gap + "px", flexShrink: "0", borderRadius: "16px", padding: "0", outline: "4px solid transparent"});
                    if (gradient) { var shade = el("img", card, {position: "absolute", left: "0", top: "0", width: w + "px", height: cardHeight + "px"}); shade.src = JF.gradientUrl; }
                    var art = el("div", card, {position: "relative", width: aw + "px", height: h + "px", borderRadius: gradient ? "12px" : "14px", backgroundColor: C.card, overflow: "hidden"});
                    el("div", art, {position: "absolute", left: "10px", right: "10px", top: "40%", textAlign: "center", fontSize: "18px", color: C.dim}, it.Name);
                    var pick = landscape ? JF.jellyfin.landscapeImage(it) : null;
                    var own = it.ImageTags && it.ImageTags.Primary;
                    if (!landscape) pick = own ? {id: it.Id, kind: "Primary", tag: it.ImageTags.Primary, fill: true}
                        : (it.SeriesPrimaryImageTag ? {id: it.SeriesId, kind: "Primary", tag: it.SeriesPrimaryImageTag, fill: true} : null);
                    // A tall poster inside a wide card is centred at its own shape, never stretched.
                    var iw = pick && !pick.fill ? Math.round(h * 2 / 3) : aw;
                    var img = el("img", art, {position: "absolute", left: Math.round((aw - iw) / 2) + "px", top: "0", width: iw + "px", height: h + "px", display: "none"});
                    var progress = it.UserData && it.RunTimeTicks && it.UserData.PlaybackPositionTicks ? it.UserData.PlaybackPositionTicks / it.RunTimeTicks : 0;
                    if (progress > 0.01) {
                        var track = el("div", art, {position: "absolute", left: "14px", right: "14px", bottom: "12px", height: "5px", borderRadius: "3px", backgroundColor: "rgba(255,255,255,0.3)", overflow: "hidden"});
                        el("div", track, {height: "100%", width: Math.min(100, progress * 100) + "%", backgroundColor: C.text});
                    }
                    var episodeTitles = !!(options && options.episodeTitles);
                    var name = episodeTitles ? (it.IndexNumber != null ? it.IndexNumber + ". " : "") + it.Name : (it.Type === "Episode" && it.SeriesName ? it.SeriesName : it.Name);
                    var label = el("div", card, {position: gradient ? "relative" : "static", fontSize: "19px", fontWeight: "bold", marginTop: "10px", color: gradient ? "#ffffff" : C.dim, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", width: aw + "px"}, name);
                    var sub = episodeTitles ? (it.RunTimeTicks ? Math.round(it.RunTimeTicks / 600000000) + " min" : "") + (it.UserData && it.UserData.Played ? "  -  Watched" : "")
                        : (it.Type === "Episode" ? "S" + (it.ParentIndexNumber || "?") + ":E" + (it.IndexNumber || "?") + " - " + it.Name : (it.ProductionYear || ""));
                    el("div", card, {position: gradient ? "relative" : "static", fontSize: "16px", color: gradient ? "rgba(255,255,255,0.85)" : C.dim, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", width: aw + "px"}, String(sub));
                    return {el: card, rowEl: line, kind: "card", img: img, label: label, labelColors: gradient ? {on: "#ffffff", off: "rgba(255,255,255,0.92)"} : null, activate: function () { onPick(it); },
                        imageId: pick && pick.id, imageTag: pick && pick.tag, imageKind: pick ? pick.kind : "Primary", imageHeight: h};
                }));
                if (carousel) { windowRow(rows[rows.length - 1], cols, counter); break; }
            }
            return rows;
        }
        // Shows `cols` cards of a long row at a time and slides the window to follow
        // the focus. Plain show/hide only: no transforms or horizontal scrolling.
        function windowRow(row, cols, counter) {
            var first = 0;
            function apply() {
                for (var i = 0; i < row.length; i++) row[i].el.style.display = i >= first && i < first + cols ? "" : "none";
                if (counter) counter.textContent = (first > 0 ? "<  " : "") + (first + 1) + "-" + Math.min(first + cols, row.length) + " of " + row.length + (first + cols < row.length ? "  >" : "");
            }
            row.forEach(function (item, index) {
                item.onFocus = function () {
                    if (index < first) first = index;
                    else if (index >= first + cols) first = index - cols + 1;
                    apply();
                };
            });
            apply();
        }
        function addRows(target, more) { for (var i = 0; i < more.length; i++) target.push(more[i]); }

        // ---- Tabs: Home, each video library, Settings (L / R cycle through them) ----
        var tabViews = [], liveTvEnabled = false;
        function tabList() {
            return [{key: "home", name: "Home"}].concat(tabViews.map(function (v) { return {key: v.Id, name: v.Name, view: v}; }),
                liveTvEnabled ? [{key: "livetv", name: "Live TV"}] : [], [{key: "settings", name: "Settings"}]);
        }
        function tabBar(container, activeKey) {
            return tabList().map(function (t) {
                return ui.pill(container, t.name, function () { goTab(t.key); },
                    {base: t.key === activeKey ? C.accentDark : C.pill, fontSize: "21px", padding: "10px 28px"});
            });
        }
        // Tabs sit directly above Home in the screen stack, so B from any tab returns Home.
        function goTab(key) {
            var homeIndex = -1;
            for (var i = stack.length - 1; i >= 0; i--) if (stack[i].isHome) { homeIndex = i; break; }
            if (key === "home") {
                if (homeIndex < 0) { show(homeScreen()); return; }
                if (current && current.leave) current.leave();
                stack.length = homeIndex + 1; render(stack[homeIndex], true); return;
            }
            var target;
            if (key === "settings") target = settingsScreen();
            else if (key === "livetv") target = guideScreen();
            else {
                var view = tabViews.filter(function (v) { return v.Id === key; })[0];
                if (!view) return;
                target = libraryScreen(view, {tab: true});
            }
            if (current && current.leave) current.leave();
            if (homeIndex >= 0) stack.length = homeIndex + 1;
            stack.push(target); render(target);
        }
        function cycleTab(delta) {
            var tabs = tabList(), key = current && current.tabKey, at = -1;
            for (var k = 0; k < tabs.length; k++) if (tabs[k].key === key) at = k;
            if (at >= 0) goTab(tabs[(at + delta + tabs.length) % tabs.length].key);
        }

        // Wide artwork for a hero banner: backdrops first, then thumbs, then 16:9 stills.
        function heroImage(it) {
            if (it.BackdropImageTags && it.BackdropImageTags.length) return {id: it.Id, kind: "Backdrop", tag: it.BackdropImageTags[0]};
            if (it.ParentBackdropItemId && it.ParentBackdropImageTags && it.ParentBackdropImageTags.length) return {id: it.ParentBackdropItemId, kind: "Backdrop", tag: it.ParentBackdropImageTags[0]};
            return JF.jellyfin.landscapeImage(it);
        }
        function runtime(ticks) {
            var m = Math.round((ticks || 0) / 600000000);
            return m >= 60 ? Math.floor(m / 60) + " h " + (m % 60 ? m % 60 + " min" : "") : m + " min";
        }
        function metaLine(it) {
            var bits = [];
            if (it.Type === "Episode") bits.push("S" + (it.ParentIndexNumber || "?") + " - E" + (it.IndexNumber || "?"));
            if (it.ProductionYear && it.Type !== "Episode") bits.push(it.ProductionYear);
            if (it.RunTimeTicks) bits.push(runtime(it.RunTimeTicks).trim());
            if (it.OfficialRating) bits.push(it.OfficialRating);
            var pos = it.UserData && it.UserData.PlaybackPositionTicks;
            if (pos && it.RunTimeTicks && pos < it.RunTimeTicks) bits.push(runtime(it.RunTimeTicks - pos).trim() + " left");
            return bits.join("   -   ");
        }
        // Large rounded banner: artwork with a dark caption panel and an action row.
        // options.fullscreen: the artwork fills the whole screen (screen backdrop) and the
        // text sits at the bottom over a full-width fade.
        function heroBlock(parent, it, options) {
            options = options || {};
            var width = Math.max(640, (viewport.clientWidth || 1280) - 96), height = Math.round(width * (options.tall ? 0.46 : 0.34)), img = null;
            if (options.fullscreen) height = Math.max(360, (viewport.clientHeight || 664) - 56);
            var box = el("div", parent, options.fullscreen
                ? {position: "relative", width: width + "px", height: height + "px"}
                : {position: "relative", width: width + "px", height: height + "px", borderRadius: "20px", overflow: "hidden", backgroundColor: C.panel, marginBottom: "18px"});
            if (!options.fullscreen) {
                img = el("img", box, {position: "absolute", left: "0", top: "0", width: width + "px", height: Math.round(width * 9 / 16) + "px", display: "none"});
                var shade = el("img", box, {position: "absolute", left: "0", top: "0", width: width + "px", height: height + "px"});
                shade.src = JF.scrimUrl;
            }
            var panel = el("div", box, {position: "absolute", left: "0", bottom: "0", maxWidth: Math.round(width * 0.64) + "px", padding: "26px 34px 30px"});
            var kicker = options.kicker ? el("div", panel, {fontSize: "17px", fontWeight: "bold", color: "rgba(255,255,255,0.7)", marginBottom: "6px"}, options.kicker) : null;
            var titleNode = el("div", panel, {fontSize: "44px", fontWeight: "bold", lineHeight: "1.08", marginBottom: "8px"}, it.Type === "Episode" && it.SeriesName && !options.episodeTitle ? it.SeriesName : it.Name);
            var metaNode = el("div", panel, {fontSize: "19px", color: "rgba(255,255,255,0.78)", marginBottom: "16px"}, metaLine(it));
            // Filled in with the full details, together with the action buttons.
            var overviewNode = options.overview ? el("div", panel, {fontSize: "20px", lineHeight: "1.4", maxHeight: "84px", overflow: "hidden", marginBottom: "20px", color: "rgba(255,255,255,0.9)"}, "") : null;
            var actions = el("div", panel, {display: "flex", alignItems: "center"});
            function setImage(item) {
                // An episode's page shows that episode's own still; everything else its backdrop.
                var pick = options.episodeStill && item.Type === "Episode" && item.ImageTags && item.ImageTags.Primary
                    ? {id: item.Id, kind: "Primary", tag: item.ImageTags.Primary} : heroImage(item);
                if (options.fullscreen) { if (pick) setBackdrop(pick, {dim: 0.15, fade: true}); }
                else if (pick) artwork.show(img, pick.id, pick.tag, 405, pick.kind);
            }
            setImage(it);
            return {box: box, img: img, kicker: kicker, titleNode: titleNode, metaNode: metaNode, overviewNode: overviewNode, actions: actions, setImage: setImage};
        }

        // ---- Screens ----------------------------------------------------------
        function connectScreen() {
            return {title: "Connect to a server", build: function (c) {
                el("div", c, {fontSize: "22px", color: C.dim, maxWidth: "1100px", lineHeight: "1.5", marginBottom: "16px"},
                    "Enter your Jellyfin address. At home: http://192.168.1.20:8096. Away from home: your HTTPS address, for example https://jellyfin.example.com (a path such as /jellyfin is fine).");
                function label() { return "Server: " + (settings.server || "not set"); }
                var warning = el("div", c, {fontSize: "19px", color: C.danger, maxWidth: "1100px", lineHeight: "1.4", margin: "4px 0 8px"});
                function warn() {
                    var text = "";
                    try {
                        var a = JF.jellyfin.parseServerAddress(settings.server);
                        if (JF.jellyfin.insecureRemote(a)) text = "Warning: this is an unencrypted (http://) address outside your home network. Your password and session can be read by anyone along the way. Use an https:// address for remote access.";
                    } catch (e) {}
                    warning.textContent = text;
                }
                var addr = ui.button(c, label(), async function () {
                    var value = await keyboard.open("Server address (up to 128 characters)", settings.server || "http://", {maxLength: 128, quickKeys: ["http://", "https://"]});
                    if (value === null) return;
                    // Keep exactly what was typed, so a long address never has to be retyped.
                    settings.server = value.trim(); persist();
                    addr.el.textContent = label(); warn();
                }, {wordBreak: "break-all", maxWidth: "1400px"});
                warn();
                function target() {
                    var a = JF.jellyfin.parseServerAddress(settings.server);
                    settings.host = a.host; settings.port = a.port; settings.tls = a.tls; settings.basePath = a.basePath; persist();
                    return a;
                }
                var go = ui.button(c, "Connect", function () {
                    var a;
                    try { a = target(); } catch (e) { status(e.message, true); return; }
                    guard("Connecting to " + a.host + "...", async function () {
                        makeApi();
                        var info = await api.publicInfo();
                        status("Connected to " + (info.ServerName || "Jellyfin") + " " + (info.Version || ""));
                        show(loginScreen(info), true);
                    });
                });
                var test = ui.button(c, "Test connection", function () {
                    var a;
                    try { a = target(); } catch (e) { status(e.message, true); return; }
                    if (!platform.testConnection) { status("Connection testing is only available on the console.", true); return; }
                    guard("Testing " + a.host + "...", async function () {
                        var result = await platform.testConnection(a, "/System/Info/Public");
                        result.lines.forEach(function (l) { log("Test: " + l); });
                        show(testResultScreen(result));
                    });
                });
                return [[addr], [go], [test], [ui.button(c, "Exit", close)]];
            }, back: function () { close(); }};
        }

        function testResultScreen(result) {
            return {title: result.ok ? "Connection test: OK" : "Connection test: failed", build: function (c) {
                result.lines.forEach(function (line) {
                    el("div", c, {fontSize: "21px", lineHeight: "1.5", color: /^FAILED/.test(line) ? C.danger : C.text, wordBreak: "break-word", maxWidth: "1500px"}, line);
                });
                el("div", c, {fontSize: "18px", color: C.dim, marginTop: "16px"}, "These lines are also in Settings > Diagnostics.");
                return [[ui.button(c, "Back", back)]];
            }};
        }

        function loginScreen(info) {
            var username = settings.userName || "", password = "";
            return {title: "Sign in" + (info && info.ServerName ? " to " + info.ServerName : ""), build: function (c) {
                var rows = [];
                var u = ui.button(c, "Username: " + (username || "-"), async function () {
                    var v = await keyboard.open("Username", username, {maxLength: 64}); if (v === null) return;
                    username = v; u.el.textContent = "Username: " + (username || "-");
                });
                var p = ui.button(c, "Password: " + (password ? "******" : "-"), async function () {
                    var v = await keyboard.open("Password", password, {secret: true, maxLength: 128}); if (v === null) return;
                    password = v; p.el.textContent = "Password: " + (password ? "******" : "-");
                });
                var go = ui.button(c, "Sign in", function () {
                    guard("Signing in...", async function () {
                        var who = await api.login(username, password);
                        password = "";
                        signedIn(who);
                    });
                }, {base: C.accentDark});
                rows.push([u], [p], [go]);
                var qc = ui.button(c, "Use Quick Connect (sign in from your phone)", function () {
                    guard("Starting Quick Connect...", async function () {
                        if (!(await api.quickConnectEnabled())) throw new Error("Quick Connect is turned off on this server (Dashboard > General).");
                        var start = await api.quickConnectStart();
                        show(quickConnectScreen(start));
                    });
                });
                rows.push([qc]);
                rows.push([ui.button(c, "Change server", function () { show(connectScreen(), true); })]);
                return rows;
            }, back: function () { show(connectScreen(), true); }};
        }

        function quickConnectScreen(start) {
            var stop = false;
            return {title: "Quick Connect", hint: "B: cancel", build: function (c) {
                el("div", c, {fontSize: "24px", color: C.dim, marginBottom: "16px"}, "On a signed-in device, open Jellyfin > your profile > Quick Connect and enter:");
                el("div", c, {fontSize: "96px", letterSpacing: "18px", color: C.accent, margin: "20px 0 30px", fontWeight: "bold"}, start.Code);
                var waiting = el("div", c, {fontSize: "22px", color: C.dim}, "Waiting for approval...");
                (async function poll() {
                    while (!stop && !closed) {
                        await platform.sleep(3000);
                        if (stop || closed) return;
                        try {
                            var state = await api.quickConnectState(start.Secret);
                            if (state && state.Authenticated) {
                                waiting.textContent = "Approved. Signing in...";
                                var who = await api.quickConnectFinish(start.Secret);
                                if (!stop) signedIn(who);
                                return;
                            }
                        } catch (e) { waiting.textContent = e.message; if (e.status === 404 || e.status === 401) { status("The Quick Connect code expired. Try again.", true); stop = true; back(); return; } }
                    }
                })();
                return [[ui.button(c, "Cancel", function () { stop = true; back(); })]];
            }, leave: function () { stop = true; }};
        }

        function signedIn(who) {
            settings.token = who.token; settings.userId = who.userId; settings.userName = who.userName || settings.userName;
            persist(); stack = []; show(homeScreen());
            status("Signed in as " + settings.userName);
        }

        function signOut() {
            settings.token = null; settings.userId = null; persist(); makeApi();
            stack = []; show(connectScreen()); show(loginScreen());
        }

        function homeScreen() {
            var screen = {isHome: true, tabKey: "home", title: "Home", hint: "L / R: tabs   A: select   B: exit", build: function (c) {
                var rows = [];
                var tabs = el("div", c, {display: "flex", alignItems: "center", margin: "0 0 20px"});
                var holder = el("div", c, {});
                var loading = el("div", holder, {fontSize: "22px", color: C.dim, marginTop: "20px"}, "Loading...");
                load("Loading your libraries...", async function () {
                    var results = await Promise.all([api.resume().catch(function () { return []; }), api.nextUp().catch(function () { return []; }), api.views(),
                        api.liveTvInfo().then(function (i) { return !!(i && i.IsEnabled); }).catch(function () { return false; })]);
                    liveTvEnabled = results[3];
                    if (current !== screen) return;
                    holder.removeChild(loading);
                    var views = results[2].filter(function (v) { return !v.CollectionType || ["movies", "tvshows", "homevideos", "mixed", "boxsets"].indexOf(v.CollectionType) >= 0; });
                    // Top tab bar, as on Apple TV.
                    tabViews = views;
                    rows.push(tabBar(tabs, "home"));
                    if (results[0].length) { heading(holder, "Continue watching"); addRows(rows, cardGrid(holder, results[0], openItem, 1, {landscape: true, carousel: true, gradient: true})); }
                    if (results[1].length) { heading(holder, "Next up"); addRows(rows, cardGrid(holder, results[1], openItem, 1, {landscape: true, carousel: true, gradient: true})); }
                    heading(holder, "Libraries");
                    if (!views.length) el("div", holder, {fontSize: "22px", color: C.dim}, "No video libraries are available to this account.");
                    else addRows(rows, cardGrid(holder, views, function (v) { goTab(v.Id); }, 0, {landscape: true}));
                    nav.setRows(rows, true);
                    if (screen.restoreTo) nav.focus(screen.restoreTo.row, screen.restoreTo.col);
            else if (screen.initialFocus) nav.focus(screen.initialFocus.row, screen.initialFocus.col);
                    else nav.focus(0, 0);                         // the Home tab, as on Apple TV
                    screen.restoreTo = null;
                    updateArtwork(nav.position().row);
                    homeReady();
                });
                return rows;
            }, back: function () { close(); }, options: function () { goTab("settings"); }};
            return screen;
        }

        function libraryScreen(view, options) {
            var items = [], total = 0, loadingMore = false, screen, tabRow = null, asTab = !!(options && options.tab);
            function loadPage(c, rows) {
                if (loadingMore) return;
                loadingMore = true;
                load("Loading " + view.Name + "...", async function () {
                    var first = !items.length;
                    var page = await api.library(view.Id, items.length, 60);
                    if (current !== screen) return;
                    total = page.total; items = sortAZ(items.concat(page.items));
                    var keep = screen.restoreTo || (first ? {row: tabRow ? 1 : 0, col: 0} : nav.position()); screen.restoreTo = null;
                    ui.clear(c); rows.length = 0;
                    if (tabRow) rows.push(tabRow);
                    el("div", c, {fontSize: "20px", color: C.dim, marginBottom: "6px"}, total + " titles - A-Z");
                    addRows(rows, cardGrid(c, items, openItem));
                    if (!items.length) el("div", c, {fontSize: "22px", color: C.dim}, "This library is empty.");
                    nav.setRows(rows, true); nav.focus(keep.row, keep.col); updateArtwork(nav.position().row);
                    // Fetch the next page when focus nears the end.
                    rows.forEach(function (row, r) { row.forEach(function (item) {
                        if (item === undefined || (tabRow && row === tabRow)) return;
                        var prev = item.onFocus; item.onFocus = function () { if (prev) prev(); if (r >= rows.length - 2 && items.length < total) loadPage(c, rows); };
                    }); });
                }).then(function () { loadingMore = false; });
            }
            screen = {title: view.Name, tabKey: asTab ? view.Id : null, hint: asTab ? "L / R: tabs   A: select   B: home" : "A: select   B: back", build: function (c) {
                var rows = [];
                if (asTab) {
                    var bar = el("div", c, {display: "flex", alignItems: "center", margin: "0 0 20px"});
                    tabRow = tabBar(bar, view.Id); rows.push(tabRow);
                }
                loadPage(el("div", c, {}), rows);
                return rows;
            }};
            return screen;
        }

        // A-Z by Jellyfin's sort name (which files "The Office" under O), numbers in
        // natural order, then year. Matches the server's own SortName ordering.
        function sortKey(it) { return String(it.SortName || it.Name || "").toLowerCase(); }
        function naturalCompare(a, b) {
            var ra = a.match(/\d+|\D+/g) || [], rb = b.match(/\d+|\D+/g) || [];
            for (var i = 0; i < Math.min(ra.length, rb.length); i++) {
                var x = ra[i], y = rb[i];
                if (x === y) continue;
                var nx = /^\d/.test(x), ny = /^\d/.test(y);
                if (nx && ny) { var d = Number(x) - Number(y); if (d) return d; return x.length - y.length; }
                return x < y ? -1 : 1;
            }
            return ra.length - rb.length;
        }
        function sortAZ(list) {
            return list.slice().sort(function (a, b) {
                return naturalCompare(sortKey(a), sortKey(b)) || ((a.ProductionYear || 0) - (b.ProductionYear || 0)) || (a.Id < b.Id ? -1 : a.Id > b.Id ? 1 : 0);
            });
        }

        function openItem(it) {
            if (it.Type === "Series") show(seriesScreen(it));
            else if (it.Type === "Season") show(seriesScreen({Id: it.SeriesId, Name: it.SeriesName}, it.Id));
            else if (it.Type === "BoxSet" || it.IsFolder) show(libraryScreen(it));
            else show(detailsScreen(it));
        }

        // Seasons in order (Season 1 first, Specials last); episodes by number.
        function bySeason(a, b) {
            var x = a.IndexNumber, y = b.IndexNumber;
            x = x === 0 ? 1e6 : (x == null ? 1e7 : x); y = y === 0 ? 1e6 : (y == null ? 1e7 : y);
            return x - y || String(a.Name).localeCompare(String(b.Name));
        }
        function byEpisode(a, b) {
            var x = a.IndexNumber == null ? 1e7 : a.IndexNumber, y = b.IndexNumber == null ? 1e7 : b.IndexNumber;
            return x - y || String(a.Name).localeCompare(String(b.Name));
        }

        // One episode in the right pane: thumbnail, number and title, runtime, overview.
        function episodeRow(parent, ep, width) {
            var rowHeight = 168;
            var row = el("div", parent, {position: "relative", display: "flex", alignItems: "flex-start", width: width + "px", height: rowHeight + "px", boxSizing: "border-box",
                padding: "12px", marginBottom: "12px", borderRadius: "16px", overflow: "hidden", outline: "4px solid transparent"});
            var shade = el("img", row, {position: "absolute", left: "0", top: "0", width: width + "px", height: rowHeight + "px"});
            shade.src = JF.gradientUrl;
            var thumb = el("div", row, {position: "relative", width: "256px", height: "144px", flexShrink: "0", borderRadius: "12px", backgroundColor: C.card, overflow: "hidden", marginRight: "22px"});
            var img = el("img", thumb, {position: "absolute", left: "0", top: "0", width: "256px", height: "144px", display: "none"});
            var progress = ep.UserData && ep.RunTimeTicks && ep.UserData.PlaybackPositionTicks ? ep.UserData.PlaybackPositionTicks / ep.RunTimeTicks : 0;
            if (progress > 0.01) {
                var track = el("div", thumb, {position: "absolute", left: "10px", right: "10px", bottom: "9px", height: "4px", borderRadius: "2px", backgroundColor: "rgba(255,255,255,0.3)", overflow: "hidden"});
                el("div", track, {height: "100%", width: Math.min(100, progress * 100) + "%", backgroundColor: C.text});
            }
            var text = el("div", row, {position: "relative", flex: "1", minWidth: "0"});
            var title = el("div", text, {fontSize: "22px", fontWeight: "bold", color: "#ffffff", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis"},
                (ep.IndexNumber != null ? ep.IndexNumber + ". " : "") + ep.Name);
            var meta = [];
            if (ep.RunTimeTicks) meta.push(Math.round(ep.RunTimeTicks / 600000000) + " min");
            if (ep.UserData && ep.UserData.Played) meta.push("Watched");
            el("div", text, {fontSize: "17px", color: "rgba(255,255,255,0.85)", margin: "4px 0 6px"}, meta.join("  -  "));
            el("div", text, {fontSize: "17px", lineHeight: "1.35", color: "rgba(255,255,255,0.9)", maxHeight: "46px", overflow: "hidden"}, ep.Overview || "");
            var pick = JF.jellyfin.landscapeImage(ep);
            return {el: row, rowEl: row, kind: "card", img: img, label: title, labelColors: {on: "#ffffff", off: "rgba(255,255,255,0.92)"}, activate: function () { show(detailsScreen(ep)); },
                imageId: pick && pick.id, imageTag: pick && pick.tag, imageKind: pick ? pick.kind : "Primary", imageHeight: 144};
        }

        function seriesScreen(series, seasonId) {
            var screen;
            screen = {title: series.Name, hint: "Left: seasons   Right: episodes   A: select   B: back", build: function (c) {
                var rows = [], seasons = [], seasonItems = [], episodeItems = [], selected = 0, right = null;
                // Width of an episode row: screen minus page padding, season pane, divider gap.
                var rowWidth = Math.max(420, (viewport.clientWidth || 1280) - 96 - 270 - 34 - 34 - 8);
                function position(item) {
                    for (var r = 0; r < rows.length; r++) { var col = rows[r].indexOf(item); if (col >= 0) return {row: r, col: col}; }
                    return null;
                }
                // Rows pair season i with episode i so both panes scroll together; the moves
                // below keep up/down inside a pane and make left/right switch panes.
                function layout(focusItem) {
                    rows.length = 0;
                    for (var i = 0; i < Math.max(seasonItems.length, episodeItems.length); i++) {
                        var row = [];
                        if (seasonItems[i]) row.push(seasonItems[i]);
                        if (episodeItems[i]) row.push(episodeItems[i]);
                        rows.push(row);
                    }
                    seasonItems.forEach(function (item, i) {
                        item.base = i === selected ? C.accentDark : C.pill;
                        item.moves = {
                            up: function () { return i > 0 ? position(seasonItems[i - 1]) : null; },
                            down: function () { return i < seasonItems.length - 1 ? position(seasonItems[i + 1]) : null; },
                            left: function () { return null; },
                            right: function () { return episodeItems.length ? position(episodeItems[0]) : null; }
                        };
                    });
                    episodeItems.forEach(function (item, i) {
                        item.moves = {
                            up: function () { return i > 0 ? position(episodeItems[i - 1]) : null; },
                            down: function () { return i < episodeItems.length - 1 ? position(episodeItems[i + 1]) : null; },
                            left: function () { return position(seasonItems[selected]); },
                            right: function () { return null; }
                        };
                    });
                    nav.setRows(rows, true);
                    var at = focusItem ? position(focusItem) : null;
                    if (at) nav.focus(at.row, at.col);
                    updateArtwork(nav.position().row);
                }
                function selectSeason(i, focusEpisodes) {
                    selected = i;
                    return load("Loading " + seasons[i].Name + "...", async function () {
                        var episodes = (await api.episodes(series.Id, seasons[i].Id)).slice().sort(byEpisode);
                        if (current !== screen) return;
                        ui.clear(right);
                        if (!episodes.length) el("div", right, {fontSize: "21px", color: C.dim, padding: "12px"}, "No episodes in this season.");
                        episodeItems = episodes.map(function (ep) { return episodeRow(right, ep, rowWidth); });
                        layout(focusEpisodes && episodeItems.length ? episodeItems[0] : seasonItems[i]);
                    });
                }
                load("Loading seasons...", async function () {
                    var loaded = await Promise.all([api.seasons(series.Id), api.item(series.Id).catch(function () { return null; })]);
                    seasons = loaded[0].slice().sort(bySeason);
                    if (current !== screen) return;
                    // The show's backdrop fills the screen behind both panes.
                    if (loaded[1]) setBackdrop(heroImage(loaded[1]));
                    if (!seasons.length) { el("div", c, {fontSize: "22px", color: C.dim}, "No seasons found."); return; }
                    var nameBox = el("div", c, {margin: "0 0 24px"});
                    el("div", nameBox, {display: "inline-block", fontSize: "44px", fontWeight: "bold", paddingBottom: "8px", borderBottom: "4px solid #ffffff"}, series.Name);
                    var panes = el("div", c, {display: "flex", alignItems: "stretch"});
                    var left = el("div", panes, {width: "270px", flexShrink: "0", marginRight: "34px"});
                    // A solid line between the seasons and the episodes.
                    right = el("div", panes, {flex: "1", minWidth: "0", borderLeft: "3px solid #ffffff", paddingLeft: "34px"});
                    seasonItems = seasons.map(function (s, i) {
                        var item = ui.button(left, s.Name, function () { selectSeason(i, true); },
                            {minWidth: "0", width: "260px", fontSize: "21px", padding: "12px 22px", margin: "0 0 10px"});
                        item.rowEl = item.el;
                        return item;
                    });
                    var wanted = seasons.findIndex(function (s) { return s.Id === seasonId; });
                    await selectSeason(wanted >= 0 ? wanted : 0, true);
                });
                return rows;
            }};
            return screen;
        }

        // ---- Live TV guide ----------------------------------------------------------
        var HALF_HOUR = 30 * 60000;
        // Times are shown in the chosen zone: "auto" uses the console's, otherwise a fixed
        // offset in minutes (the console's engine may not know the local zone).
        function zoneOffset() { return settings.tz === "auto" ? -new Date().getTimezoneOffset() : Number(settings.tz) || 0; }
        function zoneLabel(minutes) {
            var sign = minutes < 0 ? "-" : "+", a = Math.abs(minutes);
            return "UTC" + sign + (Math.floor(a / 60) < 10 ? "0" : "") + Math.floor(a / 60) + ":" + (a % 60 < 10 ? "0" : "") + (a % 60);
        }
        function clock(ms) {
            var d = new Date(ms + zoneOffset() * 60000), h = d.getUTCHours(), m = d.getUTCMinutes();
            return ((h % 12) || 12) + ":" + (m < 10 ? "0" : "") + m + (h < 12 ? " AM" : " PM");
        }
        function serverNow() { return api ? api.now() : Date.now(); }
        function byChannelNumber(a, b) {
            var x = String(a.Number || "").split(/[.\-]/).map(Number), y = String(b.Number || "").split(/[.\-]/).map(Number);
            for (var i = 0; i < Math.max(x.length, y.length); i++) {
                var p = isNaN(x[i]) ? 1e9 : (x[i] || 0), q = isNaN(y[i]) ? 1e9 : (y[i] || 0);
                if (p !== q) return p - q;
            }
            return String(a.Name).localeCompare(String(b.Name));
        }
        function programAt(list, time) {
            for (var i = 0; i < (list || []).length; i++) if (Date.parse(list[i].StartDate) <= time && time < Date.parse(list[i].EndDate)) return list[i];
            return null;
        }

        function guideScreen() {
            var screen, SPAN = 120, CH_W = 250, ROW_H = 84, ROWS = 30;
            var channels = [], programs = {}, tabRow = null, grid = null, ruler = null, info = null;
            var minStart = Math.floor(serverNow() / HALF_HOUR) * HALF_HOUR, maxStart = minStart + 10 * 60 * 60000;
            var windowStart = minStart, cursorTime = serverNow(), first = 0, focusChannel = 0, clockTimer = null;
            function width() { return Math.max(500, (viewport.clientWidth || 1280) - 96 - CH_W); }
            function showInfo(item) {
                if (!info) return;
                var p = item.program, c = item.channel;
                info.title.textContent = p ? p.Name : c.Name;
                info.meta.textContent = (c.Number ? c.Number + "  " : "") + c.Name + (p ? "   -   " + clock(Date.parse(p.StartDate)) + " - " + clock(Date.parse(p.EndDate)) +
                    (Date.parse(p.StartDate) <= serverNow() && serverNow() < Date.parse(p.EndDate) ? "   -   On now" : "") : "   -   No guide information");
                info.overview.textContent = p && p.Overview ? p.Overview : "";
            }
            function cellsFor(channel) {
                var list = programs[channel.Id] || [], windowEnd = windowStart + SPAN * 60000;
                return list.filter(function (p) { return Date.parse(p.EndDate) > windowStart && Date.parse(p.StartDate) < windowEnd; });
            }
            // Builds the visible slice of channel rows around `focusChannel`, focusing the
            // program on air at `cursorTime`.
            function render() {
                var rows = [tabRow], ppm = width() / SPAN, windowEnd = windowStart + SPAN * 60000, now = serverNow();
                first = Math.max(0, Math.min(focusChannel - 5, channels.length - ROWS));
                ui.clear(ruler); ui.clear(grid);
                for (var t = windowStart; t < windowEnd; t += HALF_HOUR) el("div", ruler, {position: "absolute", left: (CH_W + (t - windowStart) / 60000 * ppm) + "px", top: "0", fontSize: "17px", fontWeight: "bold", color: C.dim}, clock(t));
                if (now >= windowStart && now < windowEnd) el("div", ruler, {position: "absolute", left: (CH_W + (now - windowStart) / 60000 * ppm - 1) + "px", top: "26px", width: "3px", height: "10px", backgroundColor: C.text});
                var slice = channels.slice(first, first + ROWS);
                slice.forEach(function (channel, k) {
                    var index = first + k;
                    var rowEl = el("div", grid, {position: "relative", height: ROW_H + "px", marginBottom: "8px"});
                    // Channel cell on the Jellyfin blue-to-purple gradient.
                    var head = el("div", rowEl, {position: "absolute", left: "0", top: "0", width: (CH_W - 14) + "px", height: ROW_H + "px", borderRadius: "12px", backgroundColor: C.panel, overflow: "hidden"});
                    var headShade = el("img", head, {position: "absolute", left: "0", top: "0", width: (CH_W - 14) + "px", height: ROW_H + "px"});
                    headShade.src = JF.gradientUrl;
                    var logo = el("img", head, {position: "absolute", left: "12px", top: "18px", width: "80px", height: "48px", display: "none"});
                    el("div", head, {position: "absolute", left: "104px", right: "8px", top: "16px", fontSize: "20px", fontWeight: "bold", color: "#ffffff", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis"}, channel.Number || "");
                    el("div", head, {position: "absolute", left: "104px", right: "8px", top: "44px", fontSize: "16px", color: "rgba(255,255,255,0.9)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis"}, channel.Name);
                    var list = cellsFor(channel), items = [];
                    (list.length ? list : [null]).forEach(function (p) {
                        var start = p ? Math.max(Date.parse(p.StartDate), windowStart) : windowStart, end = p ? Math.min(Date.parse(p.EndDate), windowEnd) : windowEnd;
                        var onNow = p ? Date.parse(p.StartDate) <= now && now < Date.parse(p.EndDate) : true;
                        var cell = el("div", rowEl, {position: "absolute", left: (CH_W + (start - windowStart) / 60000 * ppm) + "px", top: "0", width: Math.max(18, (end - start) / 60000 * ppm - 8) + "px",
                            height: ROW_H + "px", boxSizing: "border-box", padding: "12px 14px", borderRadius: "12px", overflow: "hidden", outline: "4px solid transparent",
                            backgroundColor: onNow ? "rgba(255,255,255,0.16)" : "rgba(255,255,255,0.07)"});
                        var label = el("div", cell, {fontSize: "19px", fontWeight: "bold", color: C.dim, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis"}, p ? p.Name : "No guide information");
                        if (p) el("div", cell, {fontSize: "15px", color: C.dim, marginTop: "4px", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis"}, clock(Date.parse(p.StartDate)) + " - " + clock(Date.parse(p.EndDate)));
                        if (p && onNow) {
                            var track = el("div", cell, {position: "absolute", left: "14px", right: "14px", bottom: "9px", height: "4px", borderRadius: "2px", backgroundColor: "rgba(255,255,255,0.25)", overflow: "hidden"});
                            el("div", track, {height: "100%", width: Math.min(100, (now - Date.parse(p.StartDate)) / (Date.parse(p.EndDate) - Date.parse(p.StartDate)) * 100) + "%", backgroundColor: C.text});
                        }
                        var item = {el: cell, rowEl: rowEl, kind: "card", label: label, program: p, channel: channel, channelIndex: index, start: p ? Date.parse(p.StartDate) : windowStart, end: p ? Date.parse(p.EndDate) : windowEnd,
                            onFocus: function () { showInfo(item); },
                            activate: function () {
                                if (!p || (Date.parse(p.StartDate) <= serverNow() && serverNow() < Date.parse(p.EndDate))) watchChannel(index);
                                else status(p.Name + " starts at " + clock(Date.parse(p.StartDate)) + ".");
                            }};
                        items.push(item);
                    });
                    items[0].img = logo; items[0].imageId = channel.ImageTags && channel.ImageTags.Primary ? channel.Id : null;
                    items[0].imageTag = channel.ImageTags && channel.ImageTags.Primary; items[0].imageKind = "Primary"; items[0].imageHeight = 60;
                    rows.push(items);
                });
                // Moves: up/down keep the time, left/right walk programs and slide the window.
                rows.forEach(function (row, r) {
                    if (r === 0) return;
                    row.forEach(function (item, col) {
                        item.moves = {
                            up: function () { return item.channelIndex === 0 ? {row: 0, col: Math.max(0, tabRow.length - 2)} : jump(item.channelIndex - 1); },
                            down: function () { return item.channelIndex < channels.length - 1 ? jump(item.channelIndex + 1) : null; },
                            left: function () {
                                if (col > 0) { cursorTime = Math.max(row[col - 1].start, windowStart); return {row: r, col: col - 1}; }
                                if (windowStart <= minStart) return null;
                                windowStart -= HALF_HOUR; cursorTime = Math.max(item.start - 60000, windowStart); focusChannel = item.channelIndex; render(); return null;
                            },
                            right: function () {
                                var windowEnd = windowStart + SPAN * 60000;
                                if (col < row.length - 1 && row[col + 1].start < windowEnd) { cursorTime = Math.max(row[col + 1].start, windowStart); return {row: r, col: col + 1}; }
                                if (windowStart >= maxStart) return null;
                                cursorTime = Math.max(item.end, windowEnd); windowStart = Math.min(maxStart, Math.floor(cursorTime / HALF_HOUR) * HALF_HOUR - HALF_HOUR * 2);
                                windowStart = Math.max(minStart, windowStart); focusChannel = item.channelIndex; render(); return null;
                            }
                        };
                    });
                });
                tabRow.forEach(function (t) { t.moves = {down: function () { return channels.length ? jump(first) : null; }}; });
                nav.setRows(rows, true);
                var target = locate(focusChannel);
                if (target) nav.focus(target.row, target.col);
                updateArtwork(nav.position().row);
                function jump(index) {
                    if (index < first || index >= first + ROWS) { focusChannel = index; render(); return null; }
                    focusChannel = index; return locate(index);
                }
                function locate(index) {
                    var r = index - first + 1;
                    if (r < 1 || r >= rows.length) return null;
                    var row = rows[r], best = 0;
                    for (var i = 0; i < row.length; i++) if (row[i].start <= cursorTime && cursorTime < row[i].end) { best = i; break; } else if (row[i].start <= cursorTime) best = i;
                    return {row: r, col: best};
                }
            }
            screen = {title: "Live TV", tabKey: "livetv", hint: "L / R: tabs   A: watch   B: home", leave: function () { if (clockTimer) { clearInterval(clockTimer); clockTimer = null; } }, build: function (c) {
                var rows = [];
                var bar = el("div", c, {display: "flex", alignItems: "center", margin: "0 0 18px"});
                tabRow = tabBar(bar, "livetv"); rows.push(tabRow);
                info = {box: el("div", c, {position: "relative", minHeight: "118px", marginBottom: "10px"})};
                // Live clock (server time, chosen zone) so the guide can be checked at a glance.
                var clockEl = el("div", info.box, {position: "absolute", right: "0", top: "0", textAlign: "right"});
                var clockTime = el("div", clockEl, {fontSize: "30px", fontWeight: "bold"}, clock(serverNow()));
                var clockZone = el("div", clockEl, {fontSize: "15px", color: C.dim}, "");
                function tickClock() {
                    clockTime.textContent = clock(serverNow());
                    clockZone.textContent = zoneLabel(zoneOffset()) + (settings.tz === "auto" ? " (console)" : "") + (api.clockSynced() ? " - server time" : "");
                }
                if (clockTimer) clearInterval(clockTimer);
                tickClock(); clockTimer = setInterval(function () { if (current !== screen) { clearInterval(clockTimer); clockTimer = null; return; } tickClock(); }, 1000);
                timers.add(clockTimer);
                info.title = el("div", info.box, {fontSize: "32px", fontWeight: "bold", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", marginRight: "220px"}, "");
                info.meta = el("div", info.box, {fontSize: "18px", color: C.dim, margin: "6px 0 6px"}, "");
                info.overview = el("div", info.box, {fontSize: "18px", lineHeight: "1.35", color: "rgba(255,255,255,0.8)", maxHeight: "48px", overflow: "hidden"}, "");
                ruler = el("div", c, {position: "relative", height: "40px"});
                grid = el("div", c, {});
                load("Loading the guide...", async function () {
                    var all = [], total = Infinity;
                    while (all.length < total && all.length < 300) {
                        var page = await api.channels(all.length, 100);
                        total = page.total; all = all.concat(page.items);
                        if (!page.items.length) break;
                    }
                    if (current !== screen) return;
                    channels = all.sort(byChannelNumber);
                    if (!channels.length) { el("div", grid, {fontSize: "22px", color: C.dim}, "No Live TV channels are available."); return; }
                    var from = new Date(minStart), to = new Date(maxStart + SPAN * 60000);
                    for (var i = 0; i < channels.length; i += 40) {
                        var batch = channels.slice(i, i + 40), found = await api.programs(batch.map(function (ch) { return ch.Id; }), from, to);
                        found.forEach(function (p) { (programs[p.ChannelId] = programs[p.ChannelId] || []).push(p); });
                    }
                    if (current !== screen) return;
                    render();
                });
                return rows;
            }};
            // Tunes channel `index`; L / R during playback change channel.
            function watchChannel(index) {
                var channel = channels[index];
                if (!channel) return;
                var quality = QUALITIES[settings.quality] || QUALITIES[0], q = {videoBitrate: quality.videoBitrate, maxWidth: quality.maxWidth, maxHeight: quality.maxHeight};
                guard("Tuning " + (channel.Number ? channel.Number + " " : "") + channel.Name + "...", async function () {
                    var stream = await api.openLiveStream(channel.Id, q);
                    stream.path = api.livePlaylistPath(channel.Id, stream, q);
                    stream.channel = channel; stream.programs = programs[channel.Id] || [];
                    stream.switchChannel = function (delta) {
                        if (channels.length < 2) return;
                        var next = (index + delta + channels.length) % channels.length;
                        focusChannel = next; cursorTime = serverNow();
                        setTimeout(function () { watchChannel(next); }, 0);
                    };
                    play(channel, 0, stream);
                });
            }
            return screen;
        }

        function detailsScreen(it) {
            var screen;
            screen = {isDetails: true, title: it.Type === "Episode" && it.SeriesName ? it.SeriesName : it.Name, build: function (c) {
                var rows = [];
                var hero = heroBlock(c, it, {fullscreen: true, overview: true, episodeTitle: true, episodeStill: true, kicker: it.Type === "Episode" && it.SeriesName ? it.SeriesName.toUpperCase() : null});
                load("Loading details...", async function () {
                    var full = await api.item(it.Id);
                    if (current !== screen) return;
                    hero.titleNode.textContent = full.Name;
                    hero.metaNode.textContent = metaLine(full);
                    hero.overviewNode.textContent = full.Overview || "";
                    hero.setImage(full);
                    var resumeAt = full.UserData && full.UserData.PlaybackPositionTicks ? full.UserData.PlaybackPositionTicks / JF.jellyfin.TICKS : 0;
                    var buttons = [];
                    if (!full.MediaSources || !full.MediaSources.length) el("div", hero.actions, {fontSize: "20px", color: C.danger}, "This item has no playable media.");
                    else {
                        if (resumeAt > 30) buttons.push(ui.pill(hero.actions, "> Resume from " + ui.formatTime(resumeAt), function () { play(full, resumeAt); }));
                        buttons.push(ui.pill(hero.actions, resumeAt > 30 ? "Play from the beginning" : "> Play", function () { play(full, 0); }));
                    }
                    if (full.Type === "Episode" && full.SeriesId)
                        buttons.push(ui.pill(hero.actions, "All episodes", function () { show(seriesScreen({Id: full.SeriesId, Name: full.SeriesName}, full.SeasonId)); }));
                    if (buttons.length) rows.push(buttons);
                    nav.setRows(rows, true);
                });
                return rows;
            }};
            return screen;
        }

        function clockAt(zone) {
            var d = new Date(serverNow() + zone * 60000), h = d.getUTCHours(), m = d.getUTCMinutes();
            return ((h % 12) || 12) + ":" + (m < 10 ? "0" : "") + m + (h < 12 ? " AM" : " PM");
        }
        // A list of options; A picks one and returns to the previous screen.
        function choiceScreen(title, options, currentValue, onPick) {
            var at = 0;
            options.forEach(function (o, i) { if (String(o.value) === String(currentValue)) at = i; });
            return {title: title, initialFocus: {row: at, col: 0}, build: function (c) {
                return options.map(function (o) {
                    return [ui.button(c, (String(o.value) === String(currentValue) ? "(*) " : "( ) ") + o.label, function () { onPick(o.value); back(); }, {minWidth: "620px"})];
                });
            }};
        }

        // Rebuilds Settings after a change without losing the focused option.
        function refreshSettings() {
            var at = nav.position();
            show(settingsScreen(), true); nav.focus(at.row, at.col);
        }
        function settingsScreen() {
            return {title: "Settings", tabKey: "settings", hint: "L / R: tabs   A: select   B: home", initialFocus: {row: 1, col: 0}, build: function (c) {
                var rows = [];
                var bar = el("div", c, {display: "flex", alignItems: "center", margin: "0 0 10px"});
                rows.push(tabBar(bar, "settings"));
                heading(c, "Streaming quality");
                QUALITIES.forEach(function (q, i) {
                    var b = ui.button(c, (settings.quality === i ? "(*) " : "( ) ") + q.label, function () { settings.quality = i; persist(); refreshSettings(); }, {minWidth: "620px"});
                    rows.push([b]);
                });
                heading(c, "Playback");
                rows.push([ui.button(c, "Auto-play next episode: " + (settings.autoplay ? "On" : "Off"), function () {
                    settings.autoplay = !settings.autoplay; persist(); refreshSettings();
                }, {minWidth: "620px"})]);
                heading(c, "Connection");
                rows.push([ui.button(c, "Check HTTPS certificates: " + (settings.tlsVerify ? "On (recommended)" : "Off (insecure)"), function () {
                    settings.tlsVerify = !settings.tlsVerify; persist();
                    if (platform.setTlsVerify) platform.setTlsVerify(settings.tlsVerify);
                    refreshSettings();
                }, {minWidth: "620px"})]);
                heading(c, "Time");
                rows.push([ui.button(c, "Time zone: " + (settings.tz === "auto" ? "Auto (console: " + zoneLabel(-new Date().getTimezoneOffset()) + ")" : zoneLabel(Number(settings.tz))), function () {
                    var zones = ["auto"];
                    for (var h = -12; h <= 14; h++) { zones.push(h * 60); if (h === 3 || h === 4 || h === 5 || h === 9) zones.push(h * 60 + 30); if (h === 5) zones.push(5 * 60 + 45); }
                    show(choiceScreen("Time zone", zones.map(function (z) {
                        return {label: z === "auto" ? "Auto (console: " + zoneLabel(-new Date().getTimezoneOffset()) + ")" : zoneLabel(z) + "   (now " + clockAt(z) + ")", value: z};
                    }), settings.tz, function (z) { settings.tz = z; persist(); }));
                }, {minWidth: "620px"})]);
                heading(c, "Account");
                el("div", c, {fontSize: "20px", color: C.dim, marginBottom: "6px"}, (settings.userName || "Not signed in") + " on " + (settings.server || settings.host));
                rows.push([ui.button(c, "Sign out", signOut)]);
                rows.push([ui.button(c, "Diagnostics", function () { show(diagnosticsScreen()); })]);
                rows.push([ui.button(c, lastReport ? "Playback report" : "Playback report (none yet: press Y while playing)", function () { if (lastReport) show(reportScreen()); })]);
                rows.push([ui.button(c, "About & credits", function () { show(aboutScreen()); })]);
                return rows;
            }};
        }

        function aboutScreen() {
            var lines = [
                ["YAJA (Yet another jellyfin app) " + VERSION, "An unofficial client for Jellyfin media servers. Not affiliated with or endorsed by the Jellyfin project, Nintendo, Firaxis or 2K."],
                ["XITRIX - CivHomebrew", "The CivHomebrew launcher this app runs in: the .civapp format and packager, the app lifetime contract, and the way controller buttons are read natively."],
                ["XITRIX - Moonlight-CivSwitch", "The native video and audio pipeline used for playback (hardware H.264 decoding, the GPU texture, Opus and AudioOut), and the console patterns for network sockets, save files and the SDK lookup."],
                ["Gezine - CivSwitch", "The CivSwitch userland escape and its loader, whose primitives every native call here relies on."],
                ["The Jellyfin project", "The media server and its API."],
                ["Licensing", "This app's own code is MIT licensed. XITRIX's modules included in the package remain his work and are not covered by that license."]
            ];
            return {title: "About & credits", build: function (c) {
                var rows = [];
                lines.forEach(function (l) {
                    var block = el("div", c, {padding: "10px 14px", marginBottom: "6px", borderRadius: "12px", outline: "4px solid transparent", maxWidth: "1300px"});
                    el("div", block, {fontSize: "23px", fontWeight: "bold", marginBottom: "4px"}, l[0]);
                    el("div", block, {fontSize: "19px", lineHeight: "1.4", color: "rgba(255,255,255,0.8)"}, l[1]);
                    rows.push([{el: block, kind: "card"}]);
                });
                rows.push([ui.button(c, "Back", back)]);
                return rows;
            }};
        }

        function reportScreen() {
            return {title: "Playback report", build: function (c) {
                el("div", c, {fontSize: "18px", color: C.dim, marginBottom: "10px"}, lastReport.path
                    ? "Saved as " + lastReport.path + " (download it over CivHomebrew FTP: Root > " + lastReport.path + ")."
                    : "This report could not be saved to a file; take a photo of this screen.");
                var lines = lastReport.text.split("\n"), rows = [];
                for (var i = 0; i < lines.length; i += 8) {
                    var block = el("div", c, {fontSize: "16px", fontFamily: "monospace", whiteSpace: "pre", lineHeight: "1.35", padding: "4px 8px", borderRadius: "6px", outline: "4px solid transparent"});
                    block.textContent = lines.slice(i, i + 8).join("\n");
                    rows.push([{el: block, kind: "card"}]);
                }
                return rows;
            }};
        }

        function diagnosticsScreen() {
            return {title: "Diagnostics", build: function (c) {
                el("div", c, {fontSize: "18px", color: C.dim, marginBottom: "12px"}, "YAJA (Yet another jellyfin app) " + VERSION + " - device " + settings.deviceId);
                var box = el("div", c, {fontSize: "17px", fontFamily: "monospace", whiteSpace: "pre-wrap", lineHeight: "1.35"});
                box.textContent = diagnostics.slice().reverse().join("\n") || "No messages.";
                return [[ui.button(c, "Back", back)]];
            }};
        }

        // ---- Playback ---------------------------------------------------------
        var playback = null, lastReport = null;
        // liveStream (Live TV): {path, mediaSourceId, liveStreamId, playSessionId, channel, programs, switchChannel}
        function play(item, startSeconds, liveStream) {
            if (playback) return;
            var quality = QUALITIES[settings.quality] || QUALITIES[0];
            var stream, live = !!liveStream;
            if (live) stream = liveStream;
            else {
                try { stream = api.masterPlaylistPath(item, {videoBitrate: quality.videoBitrate, maxWidth: quality.maxWidth, maxHeight: quality.maxHeight, maxFramerate: 60}); }
                catch (e) { status(e.message, true); return; }
            }
            var screenEl, video, overlay, bar, fill, timeEl, stateEl, statsEl, hideTimer = null, started = false, lastProgressAt = 0, seekTarget = null, seekTimer = null;
            var sink;
            try {
                sink = platform.createSink({log: log, onImage: function (url) {
                    if (url.indexOf("live:/") === 0) video.style.backgroundImage = 'url("' + url + '")';
                    else video.style.backgroundImage = 'url("' + url + '")';
                }});
            } catch (e) { status("Video playback is unavailable: " + e.message, true); return; }

            screenEl = el("div", root, {position: "absolute", left: "0", top: "0", right: "0", bottom: "0", backgroundColor: "#000", zIndex: "20"});
            video = el("div", screenEl, {position: "absolute", left: "0", top: "0", right: "0", bottom: "0", backgroundSize: "contain", backgroundRepeat: "no-repeat", backgroundPosition: "center"});
            overlay = el("div", screenEl, {position: "absolute", left: "0", right: "0", bottom: "0", padding: "30px 64px 34px", backgroundColor: "rgba(0,0,0,0.55)"});
            if (live) el("div", overlay, {fontSize: "18px", fontWeight: "bold", color: "rgba(255,255,255,0.7)"}, "LIVE   -   " + ((item.Number ? item.Number + "  " : "") + item.Name).toUpperCase());
            else if (item.Type === "Episode" && item.SeriesName) el("div", overlay, {fontSize: "18px", fontWeight: "bold", color: "rgba(255,255,255,0.7)"}, item.SeriesName.toUpperCase() + "   -   S" + (item.ParentIndexNumber || "?") + ", E" + (item.IndexNumber || "?"));
            var nameEl = el("div", overlay, {fontSize: "32px", fontWeight: "bold", margin: "4px 0 18px"}, item.Name);
            bar = el("div", overlay, {height: "6px", backgroundColor: "rgba(255,255,255,0.28)", borderRadius: "3px", overflow: "hidden"});
            fill = el("div", bar, {height: "100%", width: "0%", backgroundColor: C.text});
            var line = el("div", overlay, {display: "flex", marginTop: "10px", fontSize: "19px", fontWeight: "bold"});
            timeEl = el("div", line, {flex: "1"}, "0:00");
            stateEl = el("div", line, {flex: "1", textAlign: "center", color: "rgba(255,255,255,0.8)"}, "Starting...");
            var remainEl = el("div", line, {flex: "1", textAlign: "right", color: "rgba(255,255,255,0.8)"}, "");
            // Media bar: focusable buttons while the overlay is showing.
            var controls = el("div", overlay, {display: "flex", alignItems: "center", marginTop: "16px"});
            el("div", overlay, {fontSize: "16px", color: "rgba(255,255,255,0.55)", marginTop: "12px"}, live
                ? "A: pause   Left/Right: buttons   L / R: channel   X: stats   Y: 30 s report   B: stop"
                : "A: pause   Left/Right: 10 s (buttons when shown)   L / R: 1 min   X: stats   Y: 30 s report   B: stop");
            statsEl = el("div", screenEl, {position: "absolute", left: "24px", top: "20px", fontSize: "16px", fontFamily: "monospace", whiteSpace: "pre", color: "#9f9", display: "none", backgroundColor: "rgba(0,0,0,0.6)", padding: "10px"});

            var perfNow = function () { return G.performance && G.performance.now ? G.performance.now() : Date.now(); };
            var upNext = null, nextEpisode = null;
            if (!live && item.Type === "Episode") api.nextEpisode(item).then(function (n) { nextEpisode = n; }).catch(function (e) { log("Next episode lookup: " + e.message); });
            var monitor = JF.diagnostics.create({now: perfNow, recordSeconds: JF.diagnostics.RECORD_SECONDS}), lastSecond = perfNow(), reportNote = "";
            var reportState = function () { return {itemId: item.Id, mediaSourceId: stream.mediaSourceId, playSessionId: stream.playSessionId, liveStreamId: stream.liveStreamId, position: player.position(), paused: player.paused()}; };
            function showOverlay() {
                overlay.style.display = "";
                if (hideTimer) clearTimeout(hideTimer);
                // Hide 5 s after the last input; if playback is buffering or paused then, keep
                // checking instead of giving up (otherwise a rebuffer left the bar on screen).
                hideTimer = setTimeout(function tryHide() {
                    if (menu || player.state() !== "playing") { hideTimer = setTimeout(tryHide, 1000); return; }
                    overlay.style.display = "none";
                }, 5000);
            }
            var player = JF.player.create({
                api: api, sink: sink, transport: platform.transport, sleep: platform.sleep, log: log,
                now: function () { return G.performance && G.performance.now ? G.performance.now() : Date.now(); },
                onState: function (s, detail) {
                    if (platform.keepAwake) platform.keepAwake(s === "loading" || s === "buffering" || s === "playing");
                    // Blank while playing (an empty label must not fall back to the raw state name).
                    var labels = {loading: live ? "Tuning..." : "Starting transcode...", buffering: "Buffering...", playing: live ? "LIVE" : "", paused: "Paused", ended: "Finished", error: "Error", stopped: ""};
                    stateEl.textContent = Object.prototype.hasOwnProperty.call(labels, s) ? labels[s] : s;
                    if (typeof playButton !== "undefined" && playButton) playButton.el.textContent = s === "paused" ? "> Play" : "|| Pause";
                    if (s === "playing" && !started) { started = true; api.reportStart(reportState()).catch(function (e) { log("Report start: " + e.message); }); }
                    if (s === "paused" || s === "buffering" || s === "error") showOverlay();
                    if (s === "error") status("Playback failed: " + (detail && detail.message), true);
                    if (s === "error") setTimeout(function () { stopPlayback(); }, 2500);
                    if (s === "ended") { if (settings.autoplay && nextEpisode) showUpNext(); else setTimeout(function () { stopPlayback(); }, 500); }
                }
            });
            function loop() {
                if (!playback || playback.player !== player) return;
                player.tick();
                var pos = player.position(), dur = player.duration();
                if (live) {
                    // Live: the bar shows how far into the current program we are.
                    var nowMs = serverNow(), prog = programAt(stream.programs, nowMs);
                    if (prog) {
                        var ps = Date.parse(prog.StartDate), pe = Date.parse(prog.EndDate);
                        nameEl.textContent = prog.Name;
                        fill.style.width = Math.min(100, (nowMs - ps) / (pe - ps) * 100) + "%";
                        timeEl.textContent = clock(ps); remainEl.textContent = clock(pe);
                    } else { nameEl.textContent = item.Name; fill.style.width = "100%"; timeEl.textContent = ""; remainEl.textContent = ""; }
                } else if (dur > 0) {
                    var at = seekTarget !== null ? seekTarget : pos;
                    fill.style.width = Math.min(100, at / dur * 100) + "%";
                    timeEl.textContent = ui.formatTime(at); remainEl.textContent = "-" + ui.formatTime(Math.max(0, dur - at));
                }
                if (started && Date.now() - lastProgressAt > 10000) { lastProgressAt = Date.now(); api.reportProgress(reportState()).catch(function (e) { log("Report progress: " + e.message); }); }
                monitor.tick(player.buffered());
                var tNow = perfNow();
                if (tNow - lastSecond >= 1000) { lastSecond = tNow; sampleSecond(); }
                schedule();
            }
            // Tick right before each render when the engine offers requestAnimationFrame,
            // with a timer as a backstop if frames are not being drawn.
            function schedule() {
                if (!playback || playback.player !== player) return;
                var fired = false;
                function run() { if (fired) return; fired = true; clearTimeout(playback.timer); if (playback && playback.frame && G.cancelAnimationFrame) G.cancelAnimationFrame(playback.frame); loop(); }
                if (typeof G.requestAnimationFrame === "function") playback.frame = G.requestAnimationFrame(run);
                playback.timer = setTimeout(run, 20);
            }
            function sampleSecond() {
                var net = platform.transport.stats || null, slice = net ? net.windowMaxMs || 0 : 0;
                if (net) net.windowMaxMs = 0;
                monitor.second({player: player.stats, sink: sink.stats ? sink.stats() : null, slice: slice, buffer: player.buffered(),
                    lead: player.stats.videoLeadMs, latency: sink.latency ? sink.latency() : null, playing: player.state() === "playing"});
                renderStats();
            }
            function renderStats() {
                if (statsEl.style.display === "none") return;
                var r = monitor.recent(), rec = monitor.recording(), lines = [];
                lines.push("LAST 5 S   " + player.state() + "   buffer " + player.buffered().toFixed(1) + " s   " + (sink.mode ? sink.mode() : "?") + " video");
                if (r) {
                    lines.push("shown " + r.shownFps.toFixed(1) + " fps   decoded " + r.decodedFps.toFixed(1) + "   fed " + r.fedFps.toFixed(1));
                    lines.push("frame spacing " + r.intervalMean.toFixed(1) + " +/- " + r.intervalJitter.toFixed(1) + " ms");
                    lines.push("loop pauses max " + r.maxGap + " ms, " + r.gaps50 + " over 50 ms   download slice max " + r.maxSlice + " ms");
                    lines.push("late " + r.late + "   skipped " + r.skipped + "   stalls " + r.stalls + "   replaced " + r.superseded + "   audio underruns " + r.underruns);
                    lines.push("decode " + r.decodeAvg.toFixed(1) + " ms   GPU copy " + r.gpuAvg.toFixed(1) + " ms   lead " + r.lead + " ms   latency " +
                        (r.latency !== null && r.latency !== undefined ? Math.round(r.latency * 1000) + " ms" : "?") + "   " + Math.round(r.kbps) + " kbps");
                } else lines.push("collecting...");
                if (rec) lines.push("RECORDING REPORT " + rec.seconds + " / " + rec.total + " s (keep playing)");
                if (reportNote) lines.push(reportNote);
                statsEl.textContent = lines.join("\n");
            }
            function startReport() {
                if (monitor.recording()) return;
                reportNote = "";
                monitor.record(function (rows) { buildReport(rows); });
                statsEl.style.display = ""; showOverlay(); renderStats();
                log("Recording a 30 s playback report");
            }
            async function buildReport(rows) {
                reportNote = "Building report..."; renderStats();
                var server = null;
                try { var session = await api.sessionInfo(); server = session && session.TranscodingInfo ? session.TranscodingInfo : null; }
                catch (e) { log("Session info: " + e.message); }
                var source = (item.MediaSources && item.MediaSources[0]) || {}, vs = null;
                (source.MediaStreams || []).forEach(function (m) { if (!vs && m.Type === "Video") vs = m; });
                var vi = player.videoInfo();
                var report = JF.diagnostics.formatReport(rows, {
                    version: VERSION, item: item.Type === "Episode" && item.SeriesName ? item.SeriesName + " - " + item.Name : item.Name,
                    sourceFps: vs ? (vs.RealFrameRate || vs.AverageFrameRate || null) : null, sourceRes: vs ? vs.Width + "x" + vs.Height : null,
                    sourceCodec: vs ? vs.Codec : null, stream: vi ? vi.width + "x" + vi.height + " H.264 (profile " + vi.profile + ", level " + vi.level + ")" : null,
                    quality: quality.label, mode: sink.mode ? sink.mode() : null, controller: controller ? "native" : "fallback",
                    server: server, startedAt: new Date().toISOString().replace("T", " ").slice(0, 19)
                });
                var path = null;
                try { if (platform.storage.writeText) path = platform.storage.writeText("reports/report-" + new Date().toISOString().replace(/[-:]/g, "").replace("T", "-").slice(0, 15) + ".txt", report.text); }
                catch (e) { log("Saving report failed: " + e.message); }
                lastReport = {text: report.text, path: path, findings: report.findings};
                log("Report: " + report.findings[0]);
                if (path) log("Report saved: " + path);
                reportNote = "REPORT READY: " + report.findings[0].split(":")[0] + (path ? "\nsaved " + path : "") + "\n(Settings > Playback report)";
                renderStats();
            }
            function showUpNext() {
                if (upNext || !playback || playback.player !== player) return;
                var seconds = JF.UP_NEXT_SECONDS || 10;
                overlay.style.display = "";
                var panel = el("div", screenEl, {position: "absolute", right: "64px", bottom: "200px", width: "560px", padding: "24px 28px",
                    backgroundColor: "rgba(28,28,30,0.94)", borderRadius: "20px", boxShadow: C.shadow});
                el("div", panel, {fontSize: "17px", fontWeight: "bold", color: "rgba(255,255,255,0.7)", marginBottom: "6px"}, "UP NEXT");
                el("div", panel, {fontSize: "26px", fontWeight: "bold", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis"},
                    "S" + (nextEpisode.ParentIndexNumber || "?") + ":E" + (nextEpisode.IndexNumber || "?") + " - " + nextEpisode.Name);
                var count = el("div", panel, {fontSize: "20px", color: C.dim, marginTop: "10px"});
                el("div", panel, {fontSize: "17px", color: C.dim, marginTop: "8px"}, "A: play now   B: back");
                upNext = {panel: panel, timer: null};
                function tickDown() {
                    count.textContent = "Starting in " + seconds + " s";
                    if (seconds-- <= 0) { playNext(); return; }
                    upNext.timer = setTimeout(tickDown, 1000);
                }
                tickDown();
            }
            function playNext() {
                if (!upNext) return;
                clearTimeout(upNext.timer); upNext = null;
                var next = nextEpisode;
                stopPlayback();
                status("Loading the next episode...");
                api.item(next.Id).then(function (full) {
                    if (closed || playback) return;
                    if (current && current.title !== undefined && stack.length && current.isDetails) show(detailsScreen(full), true);
                    status("");
                    play(full, 0);
                }).catch(function (e) { status("Next episode: " + e.message, true); });
            }
            function seekBy(delta) {
                if (live) { showOverlay(); return; }                       // no seeking in live TV
                seekTarget = Math.max(0, Math.min(player.duration() - 1, (seekTarget !== null ? seekTarget : player.position()) + delta));
                showOverlay(); stateEl.textContent = "Seek to " + ui.formatTime(seekTarget);
                // Coalesce repeated presses: each seek restarts the server's transcode.
                if (seekTimer) clearTimeout(seekTimer);
                seekTimer = setTimeout(function () { var t = seekTarget; seekTarget = null; seekTimer = null; player.seek(t); }, 700);
            }
            function stopPlayback() {
                if (platform.keepAwake) platform.keepAwake(false);
                if (!playback || playback.player !== player) return;
                var pb = playback; playback = null;
                clearTimeout(pb.timer); if (pb.frame && G.cancelAnimationFrame) G.cancelAnimationFrame(pb.frame);
                if (upNext) { clearTimeout(upNext.timer); upNext = null; }
                if (hideTimer) clearTimeout(hideTimer); if (seekTimer) clearTimeout(seekTimer);
                var state = reportState();
                monitor.cancel();
                player.stop(); try { sink.close(); } catch (e) { log("Sink close: " + e.message); }
                if (screenEl.parentNode) screenEl.parentNode.removeChild(screenEl);
                api.reportStopped(state).catch(function (e) { log("Report stopped: " + e.message); });
                api.stopTranscode(stream.playSessionId).catch(function () {});
                if (live && stream.liveStreamId) api.closeLiveStream(stream.liveStreamId).catch(function (e) { log("Close live stream: " + e.message); });
                if (current) render(current, true);
            }
            // ---- Media bar: pause, skip, subtitles, audio, quality -------------------------
            var source = (item.MediaSources && item.MediaSources[0]) || {}, streams = source.MediaStreams || [];
            var subtitleTracks = streams.filter(function (m) { return m.Type === "Subtitle"; });
            var audioTracks = streams.filter(function (m) { return m.Type === "Audio"; });
            var choice = {quality: settings.quality, audio: source.DefaultAudioStreamIndex != null ? source.DefaultAudioStreamIndex : (audioTracks[0] ? audioTracks[0].Index : null), subtitle: -1};
            function trackName(m) { return m.DisplayTitle || [m.Language, m.Title].filter(Boolean).join(" ") || "Track " + m.Index; }
            function qualityShort(i) { return (QUALITIES[i] || QUALITIES[0]).label.split(" (")[0]; }
            var buttons = [], barIndex = 0, menu = null;
            function addButton(label, run) { var b = ui.pill(controls, label, run, {fontSize: "19px", padding: "10px 24px"}); buttons.push(b); return b; }
            function paintBar() {
                buttons.forEach(function (b, i) {
                    var on = i === barIndex && !menu;
                    b.el.style.backgroundColor = on ? C.focus : C.pill; b.el.style.color = on ? "#000000" : C.text;
                    b.el.style.boxShadow = on ? "0 8px 22px rgba(0,0,0,0.5)" : "none";
                });
            }
            function togglePause() {
                player.toggle();
                playButton.el.textContent = player.paused() ? "> Play" : "|| Pause";
                api.reportProgress(reportState()).catch(function () {});
            }
            if (!live) addButton("<< 10", function () { seekBy(-10); });
            var playButton = addButton("|| Pause", togglePause);
            if (!live) addButton("10 >>", function () { seekBy(10); });
            var subtitleButton = !live && subtitleTracks.length ? addButton("Subtitles: Off", function () {
                openMenu("Subtitles", [{label: "Off", value: -1}].concat(subtitleTracks.map(function (m) { return {label: trackName(m), value: m.Index}; })), choice.subtitle, function (v) {
                    choice.subtitle = v; subtitleButton.el.textContent = "Subtitles: " + (v < 0 ? "Off" : trackName(subtitleTracks.filter(function (m) { return m.Index === v; })[0]));
                    restart();
                });
            }) : null;
            var audioButton = !live && audioTracks.length > 1 ? addButton("Audio: " + trackName(audioTracks.filter(function (m) { return m.Index === choice.audio; })[0] || audioTracks[0]), function () {
                openMenu("Audio", audioTracks.map(function (m) { return {label: trackName(m), value: m.Index}; }), choice.audio, function (v) {
                    choice.audio = v; audioButton.el.textContent = "Audio: " + trackName(audioTracks.filter(function (m) { return m.Index === v; })[0]);
                    restart();
                });
            }) : null;
            var qualityButton = addButton("Quality: " + qualityShort(choice.quality), function () {
                openMenu("Quality", QUALITIES.map(function (q, i) { return {label: q.label, value: i}; }), choice.quality, function (v) {
                    choice.quality = v; qualityButton.el.textContent = "Quality: " + qualityShort(v);
                    restart();
                });
            });
            barIndex = buttons.indexOf(playButton);
            paintBar();
            // Restarts the stream with the current choices, at the same moment (live: at the edge).
            function restart() {
                var q = QUALITIES[choice.quality] || QUALITIES[0], at = player.position(), old = stream.playSessionId;
                var opts = {videoBitrate: q.videoBitrate, maxWidth: q.maxWidth, maxHeight: q.maxHeight, maxFramerate: 60, audioStreamIndex: choice.audio, subtitleStreamIndex: choice.subtitle};
                api.stopTranscode(old).catch(function () {});
                if (live) { stream.path = api.livePlaylistPath(item.Id, stream, opts); player.load(stream.path, 0); }
                else { stream = api.masterPlaylistPath(item, opts); player.load(stream.path, at); }
                started = false; playButton.el.textContent = "|| Pause";
                log("Restarted the stream: quality " + qualityShort(choice.quality) + ", audio " + choice.audio + ", subtitles " + choice.subtitle);
            }
            // A small list over the video; up/down to choose, A to pick, B to close.
            function openMenu(title, options, currentValue, onPick) {
                var panel = el("div", screenEl, {position: "absolute", right: "64px", bottom: "230px", width: "520px", maxHeight: "60%", overflow: "hidden", padding: "18px 0",
                    backgroundColor: "rgba(28,28,30,0.96)", borderRadius: "20px", boxShadow: C.shadow, zIndex: "25"});
                el("div", panel, {fontSize: "18px", fontWeight: "bold", color: C.dim, padding: "0 24px 10px"}, title.toUpperCase());
                var list = el("div", panel, {});
                var at = 0, nodes = options.map(function (o, i) {
                    if (String(o.value) === String(currentValue)) at = i;
                    return el("div", list, {fontSize: "21px", padding: "11px 24px", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis"}, (String(o.value) === String(currentValue) ? "*  " : "   ") + o.label);
                });
                function paint() { nodes.forEach(function (n, i) { n.style.backgroundColor = i === at ? C.focus : "transparent"; n.style.color = i === at ? "#000000" : C.text; }); }
                function close() { if (panel.parentNode) panel.parentNode.removeChild(panel); menu = null; paintBar(); showOverlay(); }
                menu = {action: function (name) {
                    if (name === "up") at = Math.max(0, at - 1);
                    else if (name === "down") at = Math.min(options.length - 1, at + 1);
                    else if (name === "accept") { var v = options[at].value; close(); if (String(v) !== String(currentValue)) onPick(v); return; }
                    else if (name === "cancel") { close(); return; }
                    paint();
                }};
                paint(); paintBar(); showOverlay();
            }
            playback = {player: player, timer: null, stop: stopPlayback, action: function (name) {
                if (upNext) { if (name === "accept") playNext(); else if (name === "cancel") stopPlayback(); return; }
                if (menu) { menu.action(name); return; }
                var visible = overlay.style.display !== "none";
                if (name === "cancel") { stopPlayback(); return; }
                if (name === "menu") { statsEl.style.display = statsEl.style.display === "none" ? "" : "none"; renderStats(); return; }
                if (name === "options") { startReport(); return; }
                if ((name === "l" || name === "r") && live) { var sw = stream.switchChannel; stopPlayback(); if (sw) sw(name === "r" ? 1 : -1); return; }
                if (name === "l" || name === "r") { seekBy(name === "r" ? 60 : -60); return; }
                if (visible) {
                    // Bar showing: left/right choose a button, A presses it.
                    if (name === "left") barIndex = Math.max(0, barIndex - 1);
                    else if (name === "right") barIndex = Math.min(buttons.length - 1, barIndex + 1);
                    else if (name === "accept") { buttons[barIndex].activate(); }
                    paintBar(); showOverlay(); return;
                }
                // Bar hidden: A pauses, left/right skip 10 s, anything else shows the bar.
                if (name === "accept") { togglePause(); showOverlay(); }
                else if (name === "left" && !live) seekBy(-10);
                else if (name === "right" && !live) seekBy(10);
                else showOverlay();
            }};
            showOverlay();
            loop();
            player.load(stream.path, startSeconds || 0);
        }

        // ---- Input --------------------------------------------------------------
        var held = null, nextRepeat = 0, lastAction = {name: "", time: 0}, buttonFromEngine = function (name) { dispatch(name); };
        function dispatch(name) {
            if (closed) return;
            if (keyboard.active()) { keyboard.action(name); return; }
            if (playback) { playback.action(name); return; }
            if (busy && name !== "cancel") return;
            if (["up", "down", "left", "right"].indexOf(name) >= 0) nav.move(name);
            else if (name === "accept") nav.activate();
            else if (name === "cancel") { if (current && current.back) current.back(); else back(); }
            else if (name === "options" && current && (current.options || current.tabKey)) { if (current.options) current.options(); else goTab("settings"); }
            else if ((name === "l" || name === "r") && current && current.tabKey) cycleTab(name === "r" ? 1 : -1);
        }
        var NATIVE = {"nav-up": "up", "nav-down": "down", "nav-left": "left", "nav-right": "right", accept: "accept", cancel: "cancel", "keyboard-escape": "cancel", menu: "menu", options: "options"};
        function engineAction(name, phase, x, y) {
            phase = Number(phase);
            if (name === "nav-move") {
                x = Number(x); y = Number(y);
                if (Math.abs(x) > Math.abs(y) && Math.abs(x) > 0.5) name = x > 0 ? "nav-right" : "nav-left";
                else if (Math.abs(y) > 0.5) name = y > 0 ? "nav-up" : "nav-down";
                else { if (phase !== 0 && phase !== 3) held = null; return; }
            }
            var action = NATIVE[name];
            if (!action) return;
            if (phase !== 0 && phase !== 3) { if (held === action) held = null; return; }
            var t = Date.now();
            if (lastAction.name === action && t - lastAction.time < 90) return;
            if (["up", "down", "left", "right"].indexOf(action) >= 0) {
                if (phase === 3 && (held !== action || t < nextRepeat)) return;
                held = action; nextRepeat = t + (phase === 0 ? 350 : 120);
            } else if (phase !== 0) return;
            lastAction = {name: action, time: t};
            if (action === "menu" || action === "options") buttonFromEngine(action); else dispatch(action);
        }
        function listen(target, type, fn) { target.addEventListener(type, fn, true); removers.push(function () { target.removeEventListener(type, fn, true); }); }
        function consume(e) { if (e.preventDefault) e.preventDefault(); if (e.stopImmediatePropagation) e.stopImmediatePropagation(); }
        function onGame(e) {
            var d = e.detail || {};
            if (["nav-up", "nav-down", "nav-left", "nav-right", "nav-move", "accept", "cancel", "keyboard-escape", "menu", "options"].indexOf(d.name) < 0) return;
            engineAction(d.name, d.status, d.x, d.y); consume(e);
        }
        listen(window, "navigate-input", onGame);
        listen(window, "engine-input", onGame);
        listen(window, "keydown", function (e) {
            var map = {ArrowUp: "up", ArrowDown: "down", ArrowLeft: "left", ArrowRight: "right", Enter: "accept", Escape: "cancel", F8: "exit"};
            var name = map[e.key];
            // With the on-screen keyboard open, a physical keyboard types literally and
            // Enter finishes; the controller's + button arrives via gamepad polling.
            if (keyboard.active()) {
                if (e.key === "Enter") name = "plus";
                else if (e.key === "Backspace") name = "backspace";
                else if (e.key && e.key.length === 1) name = "char:" + e.key;
            }
            if (!name) name = {x: "menu", y: "options", q: "l", e: "r", "+": "plus"}[e.key];
            if (!name) return;
            consume(e);
            if (name === "exit") close(); else dispatch(name);
        });
        var nativeInput = false, subscription = null, owner = {owner: "jellyfin-civswitch"};
        if (G.engine && typeof G.engine.on === "function") {
            try { subscription = G.engine.on("InputAction", engineAction, owner); nativeInput = true; } catch (e) { log("Native input unavailable: " + e.message); }
        }
        // Buttons the engine does not report as input events (X, Y, L, R, ZR, +) are
        // read from the controller natively, the way CivHomebrew reads X. The
        // browser gamepad API is only a fallback where native reading is missing.
        var controller = null, lastButton = {}, previousBits = 0n, padState = {};
        if (platform.createController) {
            try { controller = platform.createController(); log("Controller buttons: native"); }
            catch (e) { log("Native controller buttons unavailable: " + e.message); }
        }
        var NPAD = [[0x4n, "menu"], [0x8n, "options"], [0x40n, "l"], [0x80n, "r"], [0x200n, "zr"], [0x400n, "plus"]];
        var PAD = nativeInput ? [[4, "l"], [5, "r"], [7, "zr"], [9, "plus"], [3, "menu"], [2, "options"]]
            : [[12, "up"], [13, "down"], [14, "left"], [15, "right"], [1, "accept"], [0, "cancel"], [3, "menu"], [2, "options"], [4, "l"], [5, "r"], [7, "zr"], [9, "plus"]];
        // One press may arrive by more than one route; act on it once.
        function button(name) {
            var t = Date.now();
            if (lastButton[name] && t - lastButton[name] < 150) return;
            lastButton[name] = t; dispatch(name);
        }
        buttonFromEngine = button;
        function pollPads() {
            if (closed) return;
            if (controller) {
                try {
                    var bits = controller.poll();
                    if (bits !== null) {
                        for (var n = 0; n < NPAD.length; n++) if ((bits & NPAD[n][0]) && !(previousBits & NPAD[n][0])) button(NPAD[n][1]);
                        previousBits = bits;
                    }
                } catch (e) { log("Controller polling stopped: " + e.message); try { controller.close(); } catch (_) {} controller = null; }
            } else {
                var pads = [];
                try { pads = navigator.getGamepads ? navigator.getGamepads() : []; } catch (e) { pads = []; }
                for (var p = 0; p < (pads ? pads.length : 0); p++) {
                    var pad = pads[p]; if (!pad) continue;
                    for (var i = 0; i < PAD.length; i++) {
                        var key = p + ":" + PAD[i][0], down = !!(pad.buttons[PAD[i][0]] && pad.buttons[PAD[i][0]].pressed);
                        if (down && !padState[key]) button(PAD[i][1]);
                        padState[key] = down;
                    }
                }
            }
            var t = setTimeout(pollPads, 33); timers.add(t);
        }
        pollPads();

        // ---- Lifetime -------------------------------------------------------------
        function close() {
            if (closed) return lifetime;
            closed = true;
            try { if (playback) playback.stop(); } catch (e) { log("Stop: " + e.message); }
            timers.forEach(clearTimeout); timers.clear();
            try { if (controller) controller.close(); } catch (e) {}
            removers.forEach(function (r) { r(); });
            try {
                if (subscription && typeof subscription.clear === "function") subscription.clear();
                else if (nativeInput && G.engine && typeof G.engine.off === "function") G.engine.off("InputAction", engineAction, owner);
            } catch (e) { log("Input cleanup: " + e.message); }
            if (root.parentNode) root.parentNode.removeChild(root);
            try { if (platform.close) platform.close(); } catch (e) {}
            if (G.__civswitchApp === instance) delete G.__civswitchApp;
            finish();
            return lifetime;
        }

        var instance = {id: "jellyfin-civswitch", name: "YAJA (Yet another jellyfin app)", close: close, lifetime: lifetime, diagnostics: diagnostics};
        G.__civswitchApp = instance;
        root.focus && root.focus();
        log("YAJA (Yet another jellyfin app) " + VERSION + " started");
        if (settings.host && settings.token && settings.userId) {
            splashNote.textContent = "Loading your libraries...";
            makeApi(); stack = [connectScreen()]; show(homeScreen());
        } else if (settings.host) {
            makeApi(); stack = [connectScreen()]; show(loginScreen()); hideSplash();
        } else { show(connectScreen()); hideSplash(); }
        return instance;
    }

    JF.startApp = startApp;
    JF.VERSION = VERSION;
})();
