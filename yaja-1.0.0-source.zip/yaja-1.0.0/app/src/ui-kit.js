/* UI toolkit for controller-driven screens: DOM helpers, focus navigation,
 * an on-screen keyboard and a throttled artwork loader. */
/* Credits: the artwork cache limit (8 MiB of data URLs, one download at a time),
 * scrollTop-based scrolling and the absence of CSS animation follow XITRIX's
 * console-tested Moonlight-CivSwitch menus (app/src/ui/game-artwork.js,
 * hosts-screen.js). */
(function () {
    "use strict";
    var G = typeof window !== "undefined" ? window : globalThis;
    var JF = G.JF = G.JF || {};

    // tvOS-like palette: near-black, white focus, system greys.
    var C = JF.colors = {
        bg: "#0c0c0f", panel: "#1c1c1e", card: "#2c2c2e", line: "#3a3a3c", text: "#ffffff",
        dim: "#8e8e93", accent: "#0a84ff", accentDark: "rgba(255,255,255,0.24)", focus: "#ffffff", danger: "#ff453a",
        pill: "rgba(255,255,255,0.13)", shadow: "0 14px 34px rgba(0,0,0,0.65)"
    };

    // Jellyfin blue (#00A4DC, top) to purple (#AA5CC3, bottom): a 1x256 PNG stretched
    // behind cards. An image, not a CSS gradient: images are the display path proven
    // on the console's UI engine.
    JF.gradientUrl = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAEACAIAAAD9XIvPAAAAeklEQVR42rWTUQrAIAxD097/GDvW7pJ9bMWirS0b+xCi4COJFThOFUBBqOBeAFRIp935sx+aQ4cc0yw4prlyQiYb3l4yU47dZSPv1OGWyYY3l2XrLWEu3ty7lHmTDkMmG94mZuotmLEtk428QYfpbLDh7S8m67zf/+kFvzpkyLtfYU8AAAAASUVORK5CYII=";

    // Clear at the top, fading to 90% black at the bottom: stretched across banners so
    // their text sits on a full-width shade (an image, for the same reason as above).
    JF.scrimUrl = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAEACAYAAAByPhyYAAAAQ0lEQVR42u2LMQ4AMAgCEf//584dNCJLhzoQgQP49+QFAeCWqOzy022Z9YUNU4EHC+6yqR0UEkIXsa2U9YWE2Ite8gCKLAJD2iqbZQAAAABJRU5ErkJggg==";

    // The YAJA app icon (also the launcher tile), shown on the splash screen.
    JF.appIconUrl = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAIAAADTED8xAAA0yElEQVR42u19eZhc1XXnOee+92rv6kWotYDQxioQO9gxaEFsEkiEMTGfjZM4juOJPTOfnbGN7ck3yYwBx7EnxvHnxHacxQ628RIcbAM2qxZACAMCAQETNqGlpZbU6qXWt9x75o9bVV1dWzdISO+17u9rkFRd9eot53fO75x77r2YTmfBwOBYBZlbYGAIYGBgCGBgYAhgYGAIYGBgCGBgYAhgYGAIYGBgCGBgYAhgYGAIYGBgCGBgYAhgYGAIYGBgCGBgYAhgYGAIYGBgCGBgYAhgYGAIYGBgCGBgYAhgYGAIYGBgCGBgYAhgYGAIYGBgCGBgYAhgYGAIYGBgCGBgYAhgYHBkYJlbYNAE1P9D/ZcqmBUiVf/OAGwIYBBdE2dAHDdxRGBmYABgGWgTZ+UDADAwMCKRcIKgCACIRMImYet3GQIYhNbOseLK6x05MCsJACxl5S9KAgAgkbAAIJbsQSSyY6meE5SS6b4TrViahBVL9rqFocDN5Q5sz+1/rZw/gIDCTjCr6EYDQ4DpaeKgFAAo6Wn/rU0cEQEQSdjxDCvlJLqcVC8AZI5bhIBWPJPqOYFZJbOzUdiIZMcyAIxICKgPQiQQUUk/8ArDu1/Y+fw9Y/tfsewkkmBWkbx/Zo+wSCjyip3Xmzhr3x0gAivtyxEQmEEIm+w4ACS6+gHRcpKp3nlKeomu2bF0H5JIdc9lYMtOWLEUMJOwARBYcYU2PjADs2KJE9MC/a0IhCQsOxH4xYHfPrTjuZ8HXklYsShywBAgVCY+wcp13slKAiJLX+ed2shI2FqUO6leVkE8PcNJ9iKJzHELgdlOdicy/Qwqnp6BSIiCLEfLeqzEAx8BWUmlJAPoY2oTRwTt8munxs2nBZWIgER2vGt073++uPHvSrl9lh2PHAcMAY6iXGEAZJaVkor0KxavzZEEMAg7YTkJVjKRnUOWbSeyqe65SvrJ7uPtRBcJO5GZySyFFScrDsAVP81VcS+DSqzQdqlJxjoHZkAkJIssi2xt+8xKKilZSQ6YmRAr6TJAPQ+wTvCzCpxENje0fdv9Xwm8PAk7WmnxdCJAGO47wkRnrnVKtagSaNXCzAgASABsOUkkCxETXbOYOZ6dFUt2M3O6bz6RsJPdsVQvy8BOZEloMxWVtJUVMCsZAAIoTZvKFyJg9RywZvNQtUtCEiRssi1hW2QJFM05ss9B2S960qsvfU68Rqh+EbAK7FjX6OBL2x78KlROwxDgaFj8kXI9iIhVR1qxGQRU2iiBlQwqp8OMiMKOA7Ow406yB4BTPfNI2MKOpfrm64zTcpIAEEv1AiAJC1HUpA4rySoAQE2byhViXUBpTIDH/609v75JhCTQssmyhWOhRUhU8ePaX0+QOViVQgEHRT/vyjKO2zsw1108IjAAIisZT/a8/sydr239iR1LR0gIRZEA/I6b+7gLnyhXlGRgYKWURABWikHpjJCB7VhKWHEUdqp7jlIynp4R7+oH5vSM+YAkrHgs3QvMwk4gUY28LAMdIpQKQIv8qpKpsY3HHS7DhFNq0OXMdcRDQItsiyybbIssQqEvp87iJ6h7bLrNepyg6BWKfqF+WAx1ZjAhaWEkIb3SMw98qZw/ECEhZEXe7vEQA27d89eJHYCqGqW2eEQEJGC2YmlCtJxULN2rZJDsnms5SWEn0r0nKBnEUr12ogsBrXhal0r0ubEK9JG1BArc/ATzGz//hhSB6xx59T9uceq1QVkGIESBlmXZNtmCbKJKOsvAChQzjIsjbuRRfeCAWpoAkLCSCJj3xiqU0NSofBARWMcCll481Td74cWvbP2xI+yoWJUVFdOfYPfaIgFABeD7h3Lkiobmii0KOwHA8VSvsBMAkO6dBwCx9HHxzHFKBonsbGE5ZDl2PAOskCxEAdW0tVqLBFXMjTO1znNiQy2zXk03mDZzk0vGVpKPAVGATmQti2xLWAQCEYGBpQIpK778rSRNE8Ifg0JIoA0UL3r5erpWzkmIKgNQ+uXe2UssO6WUalnUMgQ4ZOvXpu+7WC6CIE528XGzgVVLK5rkuKwsO5Hu6gclk70nCCeJKFI9xwOAk8gKO87AwoprBQLMCKBUwMwBK19JRGT2gb1xry0QhAAAQKvBWutUC9fKiFPKbrDFQfQ7CIQtbKsqbwBRMgc6IeFOxocd7xO2ORO001KwL73KaFolWmHM9ewgQIbAtqT0EukZyczM/MgushysxCw0BHj71j/B8ZMArwy+y/3zgvOvlCefx7MWqBlz327lgZEsz0kA80il0MGq0hoQgGJA0AND41ZTnxvgofO6g91Nel+AECuCpDmNfQe9EU+4BIRksZTKF7oPHpy1ZzBRKIhkNt03b+zgdgExfWKIoeZAaAkwwfEjEiNAYZTnLAyu/e/ynFXcOwuUgsDDwJ/Ep7VPdJnZk17946zWNggs7dTDW3ANtDWOqyrszCaejG7tKMl1N6j5g2PZ7Fh3954Tjn/95NLMgYHTtg+mRJInchXxyNBzekWAioRGYla+X3Qky4uu9v7oZu6bg6Ucjg1VFdHbv63Y8FTqyyNRGc3hI8nKFl8hdJoBEFjWzoXzR+YtSO9+RDzncwzr7yWGNQaEsAzK9dYf+CWyY3NOuKB06fsGL1mNgUS/zCTCe0ePVSAAKiWFYNtxfvL/6K5vQCoLSjaV68L14MIYAcat3yv0zDt30alXjpx98ZtLz7SKYwDIZOFb9HeGK0eKBGRJBaqsbvzf6Lt497ch0wPVEBHOOBC2CMBV60ffK85dctWiM9eNZTLbzjunMvxqjDkCqoyBEJDoKx+Clx6HRBqUmhgH0BBgEusPvOKJZ//u8WesCdzCCxddVOjpE4HPiKGvqhnrB0AAKSGRxjdfhFvfB0rprqdwciB0EgiRAq84a/El85auU6P7hk44sdA7w3FdRVSpJbCxstBzgAQUc7DobL7walj/Q0j31CcDJgfo4P5RKT+e7pt/1rVBOc+Iw3OPtyQjIBm7jxgIfJ/ftU5tvgtYNkik8AwOhCsCIKL0/ROWrLHjmaAw4qYzhe4eSwb1HTMGEbF/ArcEi87hOYt518vgxMNZWQ4JAZgZAFEGbqbvxOPmnRd4JaG4nEwpYVlBwCb9jaISUhKTGZyzWG1/DmOJegKEJwiEKAIgoJJ+z+zTbSfplkZBqVI2S4jEuivRaKDIUYABSMw7Q27+99CeoxWWGwXAzGQ52RmL9ORAACXtGDEQG9uPagxABpXprcuOcWIQMASo3Bd9R5RlJxPp45QMkAGUQqXQSJ8oAwFQBty2+/XoqyArRPeKpRC2EA4oCczMTMAmAkQ9AmBILD3kBEAEqWQ81WPZcSV9AKUnaCEzRX31vWM4B0BmCpnLDykBmJlIlIsjfjlvOXFQDIoJgIwEirgECjmsEJh+7W6Rki6rQK9vpmc2CUYjgaItgdo3RYchDw7XQBgrZunpqXTIqiqBQBljijYBwuvBrKN/k6ogIt8r5Ef3JNIzQbnAQBUFyWYbj4gyACtLvHRIA45yVhDGZjisrkiJALoKZBDRCEDcuMqLiQCdjJ+ZCyO7j5tzZsV/MKAhQMQl0PjUZUOAqdwz3ysiAzDrgTDiyVYQMQh3BKj3XyGcFBamXiBExcqXLrBCQEc4FlnIikwRKLIMIGAM9+OzjrKLqDN9NyilY139mEpRPBGPWVgeIQsZhCmDToccoLMZ4LFJgIr1+9KLWfEzZ56/sHuRk+x1yfL1YsiKjQSKeg4Q8sd3lAmAgG7gzUzNuvD4ZX2J48p+0SvnwS+jZSMAVX8MBaIIFYWB/KNJAETyAnd2Zu6lC64RSCW/yMgopfJ9sBxgXQUyvUBRBTIjc62izYYADb4/kEE23rNi/mpEcpWLSAySEbCyIG1lHGAaSCBEOBZJzBF4fEeNAAqURdayE6+MWQk3KBGS0mvcSgmlPCTSelFvEX0JxAxSsmOR0hM/jyH7B2EkUDvx4wflc2a/a2ZqdtHPI6Kq37CBle4jpyhkUZNZP8cEpRNix7CXiQmLQPIxxAAM/WTWo0MAxTJuJxb1nupJD4EUqMrCtFrue2VkBVCZDBDpHEAxEPA3rpv369+O3v7UgXyZu+JC8TGR1jAzMSObcYAWuW9pYc8pXU53KSjq7UwAxrd0Y7dY24aN6mYVRTMRBJacccQnl81aubjrG48MPvpaLulQzCKpeLoTIAKtXEclAjAhnZBdoDdXrG5xVbeEPJFOAGo/kQYBSAbJfNac5HduWPCLF4a/9ei+Nw+6mbggRDWtY4GZENNSFShHxLKxHsnV/bkYmKtb6iJyuUjSZ0Q9GYCinQNURkMFolRABOvO6Fm2qOsfN+/7t2cOlgKZiQk5TUlQiQCGABNdAiqWcSsdEzGlVN2eFJUEgBFBBXpPLtRTAqJsHsxA1ZZ4vWOjVNydEJ9eNfvqJd1/8+DAE2/kM3GyxTRURNUcwBCgySYsYQuyWDHoSRMTtzlhViADYIy6BEIA1bQiiCBkBsV82qzEtz+w8N+2Dv3To/v25/1MXBCCVNOqUBr+Ct5RSYJBKilZEooWW4ojQOCBV0I7MQ0kEHHF8TfcAYGoGAThDefPWHlK9juPDN7z3HAgOR0XarooIiOBWt0UAAAM2FcsCUX1NWadB0C1EoQEyFUJFHEjaMcNBACQimdm7D9fc/zVZ/T83cN7ntlRSDrkTIsaETMIMxLcsgTkSa/kF7OxmFRc0UC1P/XOn26BLIei0FD+FojfCloRMcDZ81Lf/sNFP31y6AeP79sz4mWTFgBEPBjoOcEc5g3djs44gBuUDhQGe+MzPPCq1jFh4hBLTy+JTpEfCQbiScZCEQEBFAMi3nDhjBWndP3LI4P3PDvMwClHqMgOmrHpBerw0PcX957Ut4SBCbA640UHAmAAVgpZS6DpQICpOMCaIurPOp+75oQ1S3u/+dCe53bkY3ZUR82mfu3HGAGYBYmDpf2edAlJ58FcywWAAVGVctA1C6PfCwRv8fxrimjpvNTff2jxnb858IPH9g2OetmEQMSI0aD6+EwvUMNtYYEi743lvdGuWE+gZN0W1ZXWKUQERGSIeg7A8JarWDVFRAjXXzTjklO7bt80+OtnD0rFKV0jikhPKVdSOBMBWjxjdKV7sLS/Oz5DNYZNBgAVeCB9PTEg6hHg7dUBtSJSivuzzqfXnnD5mT3/+NCebdvzqZiwrIiEAjMlsvPd2V8YXNRzKtQaQaEqgQA5KIMKCIBU5HOAQzl/qo6anTU/fduHFt+7dehf1+8dyvldSYuZQ84CkwR39ItIB0sHXOkhoOJqTwRCpQ4KyMwY/dWh+ZAvoTpqxpbAdRfMOG9h5rsP79nw/DARJmIVRRTOMqO+9pDDOkq3hgVZY+5IzhvpcnokSy3+WW+Xh8jSV+U8AWHoG8oPbxLcXhGhVkRz+2J//nvzVy3tuf3hPb/dVUzFhU1YywvCdaf0dA6zLlC7NMAL3IPFAz3xGZ6cUC1jYObK3sDTZBzgMIGqNaJ3nZI9d1HmF1v2/3jjYK4UpOIC9EiCkUCRyQEAAOBAcXBh7yk1u6+fF6kCd9oMhB3GS6jUiBQ7Fl1/cf97Tu/+7gMDj70wwgzxWLi8rRkHmCwNIDpY2u8HLiIy12YFVwbFpFsQgNNgXcR3wgKIkAFY8eze2OdvWPD4mSN3PrJv+96STgbCc8vMukAd0wAUOW8s5411xbp9lroGyvXOrrI0kJFArXmFhFIxIb779O7+bufm21/PFQNBYblhzHppIDQEaBfNyQvKQ6X93fHeuoYXZmBGDNycpQLBAJGfEPNOHRkABKHrq59tGrxn8z4vUBahnksUkioQy6AneZwtYi363g0B9D0aKu1b2HNKZQig2hGNAMyKYDqsJ3XY5/Qw6z0FEQCeemn0+/cNvLGnGI+RRcghm09DAAJNBGj7IJlQHCwe0Iuj1G0FxpX5wVIRRLsb+rBHAKWYCBFxx2Dp3zcMbtg6ZFuUTVqVAYFQZQCMqFTMSsacVFGVBYoQNrYe5QggSBS8XMEfyzhZqWStFQIRpV/ioCww4sMAh48A+tYQ4Vgh+MWmvb/avN/1VFdCMANLhSEcDWMAJRNWIu6kC6UiVOY/GQLUuwhAX3nD5aHuWI9fsXSspsKIAMgc0ZURazuk02ExfWYiRIBHnhn6twf37BwsZZKWExe6KYjCVfsZr3NoKcssjQRqayXMPFTcN79rcXVlFNY76bCSQbnoAKlIr6h5yFWsmuZ5c6D44/t2P/3SqC2oJ2VLxcyh3j8TGVixTU53ataB4j4gJ4QsPfpJMKEYKQ35ykNE5nGHz6xA+dMjB8C3+1kAIMJCKfjl+r33bd5fdmUmYTEzyyhsHct6SjQKYYX2GR79fYKJKO/l8l4u7WQky+o6KcgAyJWhgCgzAN5GEqM7QAUhAGx+Zujf7hvYs7+cjFuZuJCSISoBsbKsJSecDGJIF8k9+lskEZAn3ZHyUFe8G2R1ijDX9gmuXzgxivb/lnMArXkE4pu7i3fet/upF0biDnXpOo8CitjVMyjuTh6HYeWsFZL7NFTcPy+7sDYxjOsWx4XpPim+WfMMj3r3bRrcsOVAsRRkk9HRPK3sHwGUCthslN0xDaARd8hTnt4ucrxGNF3mBOMUTJ+Bdc/zw4/tv/uhgX0H3HTKyiSsKGme5kcLyEp2JfpiVkKqIIRxIAwRQE8Rzhe9XNrpUlDxFgyAzAQQ6V1VpiKBKnUewFe35392z66XXsk5DvVkbKmYJVOUJwQhQMDKEXFBQko/hGMVoZBAiOhLd7h0MBPrqV8tlwCI9dyAyOYAdYvjtvotIyIRjuX8ux8Y2PT4fik5kxSKWUlF4340qhev5zMJJEs4rl8KIZfDsVM8AwMcLO2fl11YJ4YrOQBHeYOMdiPBtbEtpfjRLfvvuX9g6KCXTAi0SEVR7reXf6xkwkl3xfvGigeFZYWN0CFJglkgjZQPesqbuKIwE2DU10tuboarjW29+nru5/fsfunl0URcZFKWUgwR1zwtr52ZpQpMEtwJBKLg54t+Pm1nFAd6GBFVJQmOsElMTOJrmiefD375q12PP3Eg8FU2bSvFLKtSadrsE6CvnVkgZRN9AyOvGQK0dxWEvnRHSkMZJ1tb5wCBBauo5wB6SkO95nl4/d4NmwaHhsrJhOXExbjcn2bgyjaHgJSKd4Vz4r4VppPB4fLQCZU0oNJKNT0igFKsl7p76aXRu+/euX17wXEok7QrmgemKWpVbAaBVjjHwqzw3CxCGnOHA90UVPUT02CfPGROpqzREe+Xv9j51FNDgJBJWYqZFU/7TbORgZB8ljPScwVZISxoWKGxfyakglco+IWkndY5E1X32YxwFUixbYtHNww+sWX/wYNuMmkhgJKMx8KW8QzIYIEIEIFlOJd5D5EEQiBfeaPl4bSdqXVE6E3yItwRiiA9ef+9uxyHMklLjbfvHwNgRlYCCRjidsqxY0pKDNlYmBUqW2HgkfLQ3My8ag7AQu8zF3FHmEpYzNOtxDm1RwoEiIjpWDZupfJyRIQr7QzV2TAT0mh5RM8NqCQAUU+CNdS0K3FOPQkGFihABeGcHG+F6XYBoSj6uaJfSDtdXNkhBonhGPOb04oAuhk2aaf7krOGiwcsCtfkmHDFIwL0pT9WHsnEenQZlFhFOwc4pglQ6QUiRCKLQZleoCnFgWH34FyYX2sHOiYKJtM3BwAABLRAJO1M9TU2BGhn/UyIY+XhQHoISNWNsg0BIi6B2EKRiXVz6Ow/fBGAUBT9QsEv2EgQ/XGAY54AldQXEUfLB8AsjDWFoIkBByW/4FhdAEwACCYHiCoDEGr7m7AblBEpbBywQnjbFKsR92C33aVHwUwEiG4EIGYEEEhlvzhc3E9IYfNkYSQAAY25I0EqQCOBIk8AAGZb2PuL+0ZKQ4LssE1xDWEViImo6BfcoCyQ9CiYIUBEgQCgWIC1Y/iVQAW2cNi0Q08lAnjSzXljAgVGvRfomI4AjMwWiVFv7D/3Py/IYtMNOuVbx2PuMGoRycdM99h0s39AxQ7ZL+97dn9xr0U2h2/j+JASgBDH3FHFksC0QkSYATZa+wr7X96/TbGywpcBh5QA1bkBeS8oCSAEEwEiCQVsoTVaPrgnv9uyHDMf4C0lT+SzV/TyFiCGfrNlg3Y61gYo+jlXlVMQY7M4bqsiQaebolQgqrVkg8iBKnOCcbLZwHjMEqDVzcDxsUJCAgAyEiiyQACqmwcQwikBVmjvHTMMDL0iFJihgEjqHwBkEAoGhl4J8y5v4SUAEe0ZfkNKT4DeKM9QIFq+nxFQSm/P8BtEZAjw1rICBraFs2vk1ZHCYDbRJ8M6oc6gQwZskTVSGNw18urEAWAzKX4KeTAzW+QczO99dsem1Us+mCsPIwljVVEigFJJJ7Vxx78fzO9NxbKq7U7xeIwTYELW28ABIezNr/1q5Um/a6EwhdBogVC4XmHza78Swm43AhCGqC4cJx46+Vi9L7awB3M7ZyRnntZ/nhsUBZBWllg3VdL8hOyHEVCy3xXrue/FOzb8578nnUx18/NGl19d+sPkAO11pC1iD7700yX9583Kziv5RUECTCwIde4LgfKysZ7f7nnqzme/nXBS7cVPKBDCCID1f0MEBii7uXk9J3UneoPAJSTjaEP7o1SQjffsHnnja5s+n3dHhbA6+PswRIAwEAAnVYdpO7Vj+JXe5Mz+zFwpfWZFRgiF6QeAmZUAysa7nx/4zW0bP7cvPxC3k8yVdf2a9Q8AhGGZxFBEgKb7MP5vAgyU35ecKUD8x96nAHhu14kJO8ltF1vlt/HDb+tTR/xHTbxANflH+J3/AUZAR9hpp0sq/+4Xf/itLbcWvLG4nVQsa48ynO4fADCdzoZD7TfbsV5MG33lnZBdsLDnFDcol/1Sf2buaTPPOqP/vGQszUohNrSa4AQGVY/LzQxDRABEAgZERJywozs2n82hPK4pfvKQa+Vc3WMQERHoCLhYZvZk+UBh8PGdGza/+cArB15M2ElBQrGaaP2GAG+TAyg56I71LJl5rmIJAJ70vKA8IzXr5BlnzO46IWmlAvYrH2aobzlEqFoCAyHWBxqlJAMrVuWghIhuUHaD8pTNpZkObQf7Ww5zYHvLn/AaN3SRNXwvj7+x+lZCQkQGkCpwZdkNXH4HFxdmQvHmyGu7Rt/YNbp9pDQkhB23EtWICh3FD4RkRCzMBKi8yMAWWWf1XxATcakCfd886SqlepMzZ6bnOCJmkaUHXyq78DBIDhAgUIFearfoF5SSvvKLXp6QSkHJV572XgDIrKZYrOBxs+604c/Ezg19ZVgZ48barxve1UiE+i/AxnOo2BhWohcxsFTSleWSXyj6hVJQ9GT5HS+YYaXkb4uYTTYDM6gGmre09fAQIEz7A7QaEUMEZPKkV/DzCSslUeoNt2xymHikPDTmDsdEPO1kHBGzyGaAclAihJyXY6V85XvSRUSpAsVcsycCBARCTFjJtzAkM8FwJxCAW7t0hkmcfY0Dk+yfNcHoEQlIF8gCDjxZLvqFgp8v+UVPuoqldhm2yBwxI2NgBbI5yLW8r6HqagkPAdqJBUYEVpxzR2emZqPeWgVZxwvtdcpBuegXdMGhms4C1hQQIDMLtARN+IZW8zPqzRbr3lJnppW5Cap2BJxEybTTNjxBxLT4NE/U9EQg9OZRvvI86ZaCYt4b00YvWUJlJX5C7TSA3+EZWO2anJtfx0PIio6lCACAiM1PDQGACHPuqGKJSACMXNmDWesQQShgfIBMcZNJsS6I1G4769ACdXY9/lSq3ddcIREDUIMS0bOUafyz9Y+6fUzACblJm1R7fHs0BCKqWLOn/FJQKPj5gpcrBkU/8BQoACYgRLTQarpmfIcf1RQpEV7xE0ICtI3+AqkYFLzAday49nbaOLVq4nGzaXDJVXtFwMqQWqunUrX06ptruWe90WPV+ePEPFS/uUUYaGMhrCNY9ZjVV5g1zxCIiBBQAQfKz3vFgp8v+LmiX/ClpxMVxHGj1x/kI23rndx5B+sPIULXDo3IzVUVBOErL+/njnPSSirAWr6AVfPWuwmzNvcGFzxuZw2pKXYS3JNN5NNzFKhNCbNJ0SHXkQAr5NEVWEYk0uHPV17By+f9nJY3vnQVK0Cc6Om5XqkdPSvD9lTpMLhp2qGnkAw0JsTVNKA/PQcREWqCplb1qTAHqvV8rvPiCFgXIZoeFzUSBnncXbcv8DB2khw1vvGEo1bPm3Sdnkix8tkr+4WcN5Z3x0p+wZUus6wavbBQ1Dh5lOaVTyEE4CTvD6f1h1YCYXOxBIHGvFGlFEFlfhg2Fgirk2kQx8NAtfiIQADMWE00Wj6ImkkjtK/J1FWSgIErdByXR3WlIqh8ZeVFAYhEmo2+9MpBPuflct5oyS9UE1kkIELCitE3VEbDqCgmNX0I9/mHNgeYoIXGFwyVrmPFWEmcEPuxIqKxwZTrrXn8YTEitqhGYsMj5XF9wW3kfTVLRsLx3BfHv1k7eazIG096RX8s747lvVzBz3ta3gBU5Y1dZ/QcelufqmWH1veHPwnW44iVupBeMLTg55JOyq8OWk2Q8RW/zzX/j+PDTs2Pq+qk69NRanhbzaqx4U9oVPdVr68rSIiEFU/vSS/njeW9sZw3WvBy2ugRkJAIUTRp+ohM/MS3wplQX1P4q0BVcc/ArEbLwzNTsyp9PMzj3ponVGdwPJGte7U5CxgnArUWPDixgDnh8Y93X6AuWSIRoWLlKz/vjWlNX/BzrnSlkohAQISi3uiPTMnyqIaLsF+aFRV/o+VEzhthZtJ7ao+PHWslPrF3gBsstbFNrknWU33nHELbumql9QaQUDtyUqB86eX90TF3NO+NFby8K8tK1RJZtCns8uYYNP0IEaBiiYJE3svlvVzKySiWWEt4m+nCE/p1oFObAY9XgqoHw6aUd7yAgySAkCqJbM4bzbmjY+5IxehZYaUjjaxjyeghauX/6BEAABDIk+5Absdpxy115XgeXJPzWMtBcTxH5apdY6MCqqW5DU1qWO2n10UcREAiQiRm5Uov74+NuSNj7kjBy7mBK1kiAKEgJDGhesPHjMVHWMVFiQAMbJE9WBg4IbswaSelktBiNIhhgllXElesNfi06LqvVj11j0WlWCoEEiEqYF+6Y+XRnDc65o4WvDE3KFdKlohERGDXvpd58oUwpxkLIn8BoWmHnuL9xoCD45L9S/svCFSA48MBXNdZUDeI1uDxG58X18t+AtTqRbHypJv3czlXG33OlWXFEqtvwOZjGxgCHDEO+Mo7uW/Jgu6T3cCFihJibqHs273E1S5LrJYsiVn50i34+TFvdMwdzns5N6gZvajNO2Nj9tMLVuTOmIFtsl89+FsAPLF7sVS+Tj0RGgtBTdZf2aKKkLSmV6w85ebc/Jg7MlrR9OVjVtObCBAxBCo4vuvEk/uWEIlABdq622mcaosBKmZPukU/P+qOjLnDBS9fZ/Ra3hhPbwgQGS3kp52uhT0n9yT6HBFTrBQorqv7E4x7+qKXH3VHxsrDeW/Mle5ETW+M3hAgmhyQLJlV2unqT8/tjvc6wnEoBgiKFYMqePkxd3TMHclXqjeB0fQG04cA+hIQQLJULAVaFlmOiAGiXjioXKfpjdEbTEsCjNOgslZTnQQy8sagM6zpciFcnR2AiNXJupU/jOkbTH8CTCCDea4GU4TZf9HAEMDAwBDAwMAQwMDAEMDAwBDAwMAQwMDAEMDAwBDAwMAQwMDAEMDAwBDAwMAQwMDAEMDAwBDAwMAQwMAgeojqhBi9PXT734KUatIjEFGHvUSVUod4Gm/1aIfxDkzx6ya9Ce/c+RsCHNKzL5fLvu9XNwSbYPoaqVSq8xF83y+Xy81HgOqGM8lkUgjRwTgQ0fN8z3MBoN279PlYlhWPxw/jxr2I6Hme53kNX43VzZGTyeQUDgJSylwuV1lcntue/xQPaAhwhBAEwZe//KVTTjlFysrOwbVfMbNt2zt27PjUpz7TzuCIqFQqnnHGGTff/IWWtqWUSiQSX//6N+655+50OiOlbHmQYrGwbNmyT3/6U1LKds5YKeU4zu23f/+OO+5IpzOHxY8KQfl8/v3vf/8HP3ij53lEVH/5lmXt2LHjpps+FwRBB++uXcDMmTO/+tW/SSYT7U5Mn/9TTz39hS/cHIvF3uHNtw0BpvT4RaGQ+4//ePGTn/xEh7etX7/hjjt+mM32NJsvEfm+94lPfOLqq9e0+/jQ0NDWrU87TqydZSBiEPgf/OCNq1dfNek5ZzKZn/70p4fR/Uvpn376qVdeeUXLN+zcufOzn/38JMkfUblcXLFi+Xvfe92k37h8+bJ/+Zd/2bVrdywWm2ZaKHpJsJQyne7653/+51//+j6llOd5ciJ831dK3XTTp1OpTEvrLxQKZ5551vXX/5cgCIIgaP44AHz2s5/ftWtHO5+nxU9//+xVqy7VH5Edcc45Z59++umlUqneWx8iymVXSum6XsPJSynHxsYm/TgzE4l169ZKKZvvYcMx4/H4qlWrXPdwnr8hwCGcNBEi3nzzrVJKy7KISNTBtm0AOPvss6+//r35/JhlWU2h3/34x/80lUohomVZ9Z9FRNu2n356649+9KN0OhsEQQf3+Tu/8+558+YRkW3boj0AIJFIXHHFlb5fPowGhIidv7TzZ13XPfHE+StWLNd3rMOhtI5at24dkWBWhgBhCQKbNz/y/e//gIhaBmVm/sxnPpVOZ+qNmIhKpdKpp57+gQ+8n5nbmeMtt9xaLBY6mxGzWrv2mqmXR6699hrHibdMJ46KB3Hd0vLly/r6+pRSnQtZ2t0sW3bxwoULS6XyFKtehgDvLJhVLJb44he/NDo6irW9VOueGTMvWbLkfe97Xz4/WgsCROR5pT/5kz/u6upqfvBSSiK6//4H7r777kwm285YdQXmuONmXX75ZfqYkyYtAHD++ecfdhV0aAGE1q5dy8yT5rWIKKXMZDKrVq3yvNKk4cUQ4EhAKZVIJF999eWvfe3rnYNANtsTBD4iIGKpVDrxxIUf+tAftnT/iBgEwc0338rMHfyc1j/vec+7jz/++EndZ61s5TjOmjWrg8A96gTQReR5805cuXK5HgeY4gevu+5aIexppoIinNNIKZPJzDe+8Xevv/56Mwd0EDj11FPf//735/M5nSa4bvEjH/nj3t7e5sKldv8//vFPHn10YybT1UGr6IBz7bXr4K2MNwHAunVrY7HkUVdBWv+sXLmip6dnigTWJHnPe96zaNHiaaaCIkwAXfI/cGDfF7/4pXaPhJk/+clP9PT06YLJnDnHf+QjH252/9rlFwqFL33prx0n3sGsdfo4c+asyy+/vKX+aakoNBvPOeecM844IwwqCJGuvXZdS/3T8kWtgtLp9GWXXeZ506oWFO0rkVJmMtkf/OAHjz/+OBE1OFdtdqeccvKNN34gn8+XSsU/+IPfnzVrllKq4RHqV/7hH/7xhReeSyZTHQhQ1T+/M3funIbjaLt57rnnH3ro4YbgoAfXHMdZvfrKIHCPoget6Z/ly5e11D8jI6M/+clP2zH52mvX2va0Gg6LPJWJyPPcv/zLL7QT7sz8iU/8j0wm09fX99GP/knz25RiItq7d+9tt90Wj6cmlSjMsHbt2mb9o/+5adOmDga0du01yWT6KKogrX8uvXRls/7R5//mm29+85vfkrJRGlVV0O+cfPIppVJ52gSByF+GDgIPPHD/nXf+rF0QWLx48ZVXXrFy5YoFCxa00j8KEW+77W937nyzc8eOrv/MmjX78stXNesfbTGbNz++efPm5m/RxZNzzjnnzDOXlstHTUXo8a+1a6/ROyk0i7etW595/PHHd+7c0RzEpJSpVOryy1f5fmnapAHTgcc6Gbj55luKxWJzSVS/4fOf/9xNN326+Vdaxrz66qvf+c53Uqmuzr65pn90/adB/+hBhm3btr3++htvvPGGlj0NXLVte/Xqq4LAOyoE0AnM/PkLli9fhtiawI899pjnlR9/fEu7FH/t2mmlgqYDAZRSqVT6ueee/da3vt2yHISI5557zgUXXNCserUiuvXWvxoeHrJte9Lnygzr1q1tVjj6S7dt2/bmmzuKxfyjjz7WbEDawtauvSaRSLcbYz4y9Z/e3t4G/aMJnM/nn3jiCQDQaUxLFfTud7/r5JNPCc+AhiFAxbnG46mvfvVrAwMDLYcFWhY3pFRCiN/85skf/ehHmUx3Z6Os6p85l13WQv/og2/c+EixWEAUGzZsaGlAzLx06dKzzjrrqBgQMxNZ69a1GP+qEvi5V199zXESW7Y8USqVG7rBtQpKJBJXXnnF4W3rMAQ4DI82Fovt3r3jy1/+SpsW/xbTR/QLt9xyq+tOPj5VG/+aM2dOc/lcS/z169cTiVgstmXLE8VisXk6gZTSssTVV6+W8kirIEQsl935809ctuySlpEQANav3+C6xVQq+dprr73wwgvta0HrLGuatIVOn4KulDKdzv7TP/3z888/LwRNOiNMj3zdc8+99957b+eRr3or0fpHqUb3iYg7d+56+umt8XjccZzXXnt927ZtzQakzW7durXJZOYIqyAhhOeVVq5c0d3d3TwOqLn60EMPE1mIVC4XdBBref4XXXThaaedNj1U0LTqbrUskc/n/+Iv/q82186mrCXNLbd8cSoFDf3m/v7ZV1xxOQAI0cJ9PvroowcO7LNtmwg9r7Rhw8aWBqSblM4995xSqXgkDYiZEWndumtbVgIQcfv27du2bYvHE1JKREuff3OiLKWMxWJXXaWbW9EQIEQIAtnVlf3lL39x3333CyE6OHVdw7njjju2bNk8lYlaehLZJZdcrMfRGjij//nQQw/rjiNmILI3btwErYaKlVJCiDVr1kjpNxiQbs9uiUOkih7/mj9/wfLlLfSPDmiPPPLo8PBBx3GYOR6PP/vstoGBAURsCHfVWtA1sVhi0jBrCHAUgIj/5/98wfPcliXRmvvP5XJ/9Vdf7tz40PC5tWuvYeaG91frJ4VHHnlUCEdPsnEcZ+vWZ3bs2NlcDNVsufrqNZlMt++PSxE9R3FkZKjlT6l0SKV3InLd4qpVK7PZbLP+0Ty87777AZSUMggCy7IGBnZv3vw4ADR0v2nyXHjhBaefvmQaqKDptk2qLolu2bL5u9+9/aMf/YiUsrl9V/vgb37zWy+//GJ3d9+kWlzrn9mz515++WWt3KcSQjz99NN79+7t6enRlBNCjI2Nbt68ed68G1qqoDPOWHLuuec+8sgj6XS6psfmz5//+79/Y1N9hh3Hvueee3/zm9/E44m3nXoKYa9bt67ZIWgCDw8PP/vss9lsr44AQgjfdzdu3HT99e9tvhs1FfTMM08hpgwBQlgRSvz1X3/52mvX9vf3N/Q+6Ke7c+fOr3/9G4nElLoSdP3n4ouvnj17dnMfkSbYWWctfeqpJ4QQ2sIQQSnV3d1de0MzZ66+evXGjQ/rc6tO0Zr353/+v1qew9DQwUcf3dS5T2lS/XPJJRe3G/9KJpM///ldRFh3/hyPx1qef00F3Xbb16JeC5qGBNBrOrz++it33vmzj3/8Y3raZIPx3XHHj3fv3jEV91+lDej5X+1Gyrq7u7W5T9EiAWDNmjW33PLFIAi0AtESqPl8NOVKpdKh6Z/SpZfq+o9qyOA1YrHY4sWLpl5QAoDzzjv3jDOWPPvstmQyGV0aTNuV4RCxVCq3+22xWGiXITQfx3W9OXPmXnZZp/lfOjdoQId1WZj59NNPO//880ulIpGAasdoc/orhLAsy7btujiGiCiE1a7Y1dDnw8xCWLqBr0NxbOrnDwBSSsdxVq++KgxTfAwBWltkS1dX82FT7GbR+ueSSy6ePXtWh+kjOjdoQIe0VbdbXnPNGqWCmgryPE+fVYP5AsDixYv0mj96ojozL1iwoN3BS6VSNdNlIiqX3YULFy5bdgl0nMD5ls6/qoJCMcXHEKAtB97Gr9rp3alMn30rskSroNWZTLdeiEUIMTw8nMvlWnL1937v+iVLlh44MDg6OjI0tO9d73rP2rVrdD7TfF0DAwO6PsNcmQa9cuXKbDY7xflfU1dB55xz9tKlZx7hAQ2TAxxRHeV53uzZcy67bFW76bNTkb/NH6xO1jnlwgsvXL/+4Uymy3Gc3bsHtm9/c+nSM+sTdy3VZs6c+eCD93/ve9/buXPXwoUL/+iP/jCb7W43BeLll1+W0kNM6yKmXv+nHYGrr2MHddTywnW1dM2aNU8++QRRJqJpgCHAJIZbKhXXrVvb39/fXP/pYBxTgc7O16275qGH7teL/IyODj/22GOaAA08ZOZZs/o/+9mb6g232fr1yWzYsBFR6DeUSuUFCxZecskl7Qhc1yWFb9U76Nj4la985ag0txoCHCElpd1nu4mUf/M3X33wwYcymRar0Akh8vn8ihXLb7rpM832qo921VVXdXfP8H3PsiwhrJ/85Kd/+qf/tVXfHjKzVvZa+TS/Ryucl156adOmR3TB1LIszyutWnVpV1emeUhEv3Lffff/7d/+bcslUHVhqr+//2tfuy2ZTLTUZmedtXTp0rOeeurJt1eiNQQIv/45ftWqS7WHblAORFQsFr/5zW+99toriFbLueTMwW9/+/LHP/6x2oBXgwo66aSTLrroggceeCCd7kql0ps2bbrrrp9fd93v+r6vl7irP1rDKnfNZSjLsr70pS+PjY3oRVF1/7NewKId/vVfb//Vr+4Vwmmfy6oPf/iP3vWui1q6AMuy1qxZvWXLY1pxmSR4uumf5csv0fqnwePWJhDu3j3Q3d3X1dWVbUJXV1d3d9+ePXu2bn2mZbaglEKEtWuvUUrqw9u282d/9j937dpl27ZOjqcCpZRW5N/73u3f//73u7oq/Z6lUmnRosUXX3wxtJrAIIQYGxt78smnEol0JpPJtkJvby8irl+/vmXloKqCrk6nsxGtBU3zKlC7BV+nXM/hNWtW6/aYhiMEQaCUevDBh8rlgpYT7b6oXC6sX79BKdX8W6VYSnnFFZf39s7Qa/rG4/Fdu3Zdd93127dv1zPU9Be1W79EH0evT3r77d//2Mc+lkgk9Zt1/WfFiuWZTFoffOKSt4GU8sknn9q+/Q3btpsvsHaZiLRhwwZ9Ds1XJ6U8/fTTly5dGtFa0HQmQCwWE0Lo/9fgOI5+cVL947ru/PkLr7vud2ufajgOEa1fv4HI7qB9mZnI3rhxIxE1H8S2LSHESSedtHLlilKpqDtY0+nM1q1bV6xY9cMf3qFr/7okr0VOzfJ08qqP8+abOz7+8f/24Q9/hEjU9gRgZtuO3XjjB/SKv03nbwshHn54ve93WqaFmePxxDPPbBsc3NewkHD9rbjhht+T0o/iTHlruvp+IcSrr772xBNPBEFQHTSt1V7E9u3bJ939xfe9RYsWvfjiS83tk8wKkQYGBl544YVEItF5wCEeTzz33PN33fXzWbNm6Q82Z6Lz58+vfYVeiHPv3r033vj7f//337zhhvetXLli4cKFyWSy/jQ8zxsc3Pfss8/ec8+9d93188HBgUymuyZUqgnMbM9zt2x5oikF1wyBX//617Yd73z+lmUdPHjwu9/97sqVK5szaZ0YZLPZZDITRRWE6XR2ukYA7Syh1SZCU1lDXMN13fb1QXYcZypuj5k9z2t5nKr0txu2utFVy1wup5SfyXTPnTv3+OOPnzGjT/M2l8vt3r17YGDP4OAgc5BIpB3HaVnG8TxPKUaE5r2kmNmybMua0qC43o4JAFruSaX7NaK4VMR0JkBn05zi0zosB6nVfN7qcbT40XtY+L7PrKokId0gpHuEOvTtTMrPI3wfDAEM3gaToTpghQ1J8PTbtMvkAAbN/rVi8OZWmCqQgYEhgIGBIYCBgSGAgYEhgIGBIYCBgSGAgYEhgIGBIYCBgSGAgYEhgIGBIYCBgSGAgYEhgIGBIYCBgSGAgYEhgIEhgIGBIYCBgSGAgYEhgIGBIYCBgSGAgYEhgIGBIYCBgSGAgYEhgIHBdML/B+PRRcR5qET0AAAAAElFTkSuQmCC";

    function el(tag, parent, style, text) {
        var node = document.createElement(tag);
        if (style) for (var k in style) node.style[k] = style[k];
        if (text !== undefined && text !== null) node.textContent = text;
        if (parent) parent.appendChild(node);
        return node;
    }

    function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); }

    function formatTime(seconds) {
        seconds = Math.max(0, Math.floor(seconds || 0));
        var h = Math.floor(seconds / 3600), m = Math.floor(seconds / 60) % 60, s = seconds % 60;
        return (h ? h + ":" + (m < 10 ? "0" : "") : "") + m + ":" + (s < 10 ? "0" : "") + s;
    }

    // rows: [[{el, activate, kind}]]. Focus moves within and between rows.
    // No CSS transforms or transitions: Civ VII's UI engine is only known to be
    // stable with plain layout plus scrollTop scrolling (as Moonlight uses).
    function createNavigator(viewport) {
        var rows = [], row = 0, col = 0, onMove = null;
        function item() { return rows[row] && rows[row][col]; }
        function paint(target, active) {
            if (!target || !target.el) return;
            var s = target.el.style;
            // tvOS focus without its scaling animation (animations are unstable on the
            // console's UI engine): the focused tile is at full brightness with a white
            // edge and a lifted shadow; the others sit slightly dimmed.
            if (target.kind === "card") {
                s.outline = active ? "4px solid " + C.focus : "4px solid transparent";
                s.boxShadow = active ? C.shadow : "none";
                s.opacity = active ? "1" : "0.72";
                s.backgroundColor = "transparent";
                if (target.label) target.label.style.color = target.labelColors ? (active ? target.labelColors.on : target.labelColors.off) : (active ? C.text : C.dim);
            } else {
                s.backgroundColor = active ? C.focus : (target.base || C.pill);
                s.color = active ? "#000000" : C.text;
                s.boxShadow = active ? "0 10px 26px rgba(0,0,0,0.55)" : "none";
                s.borderColor = active ? C.focus : "transparent";
            }
        }
        function rect(node) { try { return node && node.getBoundingClientRect ? node.getBoundingClientRect() : null; } catch (e) { return null; } }
        // Vertical scrolling only follows row changes: moving sideways never scrolls
        // (revealing a card in a sliding row could otherwise report position 0 before
        // the engine lays it out, which used to send the page to the top). Rows are
        // measured by their always-visible row element, relative to the viewport.
        function scroll(rowChanged) {
            var target = item(); if (!target) return;
            if (row === 0) { viewport.scrollTop = 0; return; }
            if (!rowChanged) return;
            var view = viewport.clientHeight || 0; if (!view) return;
            var anchor = target.rowEl || target.el, TOP = 64, BOTTOM = 24;
            var a = rect(anchor), v = rect(viewport);
            if (a && v && a.height > 0) {
                var top = a.top - v.top, bottom = a.bottom - v.top;
                if (top < TOP) viewport.scrollTop = Math.max(0, viewport.scrollTop - (TOP - top));
                else if (bottom > view - BOTTOM) viewport.scrollTop = viewport.scrollTop + (bottom - (view - BOTTOM));
                return;
            }
            // Fallback: layout offsets, only once the row has a size.
            var off = 0, n = anchor, guard = 0, height = anchor.offsetHeight || 0;
            if (!height) return;
            while (n && n !== viewport && guard++ < 32) { off += n.offsetTop || 0; n = n.offsetParent; }
            if (off - TOP < viewport.scrollTop) viewport.scrollTop = Math.max(0, off - TOP);
            else if (off + height + BOTTOM > viewport.scrollTop + view) viewport.scrollTop = off + height + BOTTOM - view;
        }
        function set(r, c, force) {
            if (!rows.length) return;
            var previousRow = row;
            paint(item(), false);
            row = Math.max(0, Math.min(rows.length - 1, r));
            col = Math.max(0, Math.min(rows[row].length - 1, c));
            paint(item(), true);
            if (onMove) onMove(item(), row, col);       // may reveal the item (sliding rows) before scrolling to it
            scroll(force || row !== previousRow);
        }
        return {
            setRows: function (next, keep) {
                rows = next.filter(function (r) { return r && r.length; });
                rows.forEach(function (r) { r.forEach(function (i) { paint(i, false); }); });
                if (!keep) { row = 0; col = 0; viewport.scrollTop = 0; }
                set(row, col, true);
            },
            // An item may define moves[dir]() -> {row, col} (or null to stay put), for
            // layouts that are not a plain grid, such as side-by-side panes.
            move: function (dir) {
                if (!rows.length) return;
                var from = item();
                if (from && from.moves && from.moves[dir]) { var to = from.moves[dir](); if (to) set(to.row, to.col); return; }
                if (dir === "up") set(row - 1, col);
                else if (dir === "down") set(row + 1, col);
                else if (dir === "left") set(row, col - 1);
                else if (dir === "right") set(row, col + 1);
            },
            activate: function () { var i = item(); if (i && i.activate) i.activate(); },
            current: item,
            rows: function () { return rows; },
            position: function () { return {row: row, col: col}; },
            focus: function (r, c) { set(r, c, true); },
            onMove: function (fn) { onMove = fn; }
        };
    }

    // Rounded "pill" button, white with black text when focused.
    function button(parent, label, activate, style) {
        style = Object.assign({}, style || {});
        var base = style.base || C.pill; delete style.base;
        var b = el("div", parent, Object.assign({
            padding: "14px 30px", margin: "7px 0", borderRadius: "30px", border: "2px solid transparent",
            backgroundColor: base, color: C.text, fontSize: "23px", fontWeight: "bold", minWidth: "320px", boxSizing: "border-box"
        }, style), label);
        return {el: b, activate: activate, kind: "button", base: base};
    }

    // Horizontal pill for action rows and tab bars.
    function pill(parent, label, activate, style) {
        return button(parent, label, activate, Object.assign({minWidth: "0", margin: "0 14px 0 0", textAlign: "center", padding: "14px 34px"}, style || {}));
    }

    // Modal keyboard: resolves with the text, or null when cancelled.
    function createKeyboard(host) {
        var active = null;
        // Pages: 0 lowercase, 1 uppercase, 2 symbols.
        var layouts = [
            ["1234567890", "qwertyuiop", "asdfghjkl-", "zxcvbnm._@"],
            ["1234567890", "QWERTYUIOP", "ASDFGHJKL:", "ZXCVBNM,/!"],
            ["1234567890", "!@#$%^&*()`~", "-_=+[]{};:", "'\",.<>/?\\|"]
        ];
        function open(title, value, opts) {
            opts = opts || {};
            if (active) active.finish(null);
            return new Promise(function (resolve) {
                var text = String(value || ""), page = 0, r = 1, c = 0;
                var overlay = el("div", host, {position: "fixed", left: "0", top: "0", right: "0", bottom: "0", backgroundColor: "rgba(0,0,0,0.78)", zIndex: "50", display: "flex", alignItems: "center", justifyContent: "center"});
                var panel = el("div", overlay, {backgroundColor: "rgba(28,28,30,0.97)", borderRadius: "24px", padding: "30px", width: "980px", boxShadow: C.shadow});
                el("div", panel, {fontSize: "22px", color: C.dim, marginBottom: "10px"}, title);
                var field = el("div", panel, {fontSize: "34px", padding: "14px 20px", backgroundColor: "rgba(255,255,255,0.08)", borderRadius: "14px", minHeight: "44px", marginBottom: "18px", wordBreak: "break-all"});
                var grid = el("div", panel, {});
                el("div", panel, {fontSize: "18px", color: C.dim, marginTop: "14px"}, "A: type   B: cancel   X: delete   Y: shift   ZR: symbols   +: done");
                var keys = [];
                function render() {
                    field.textContent = (opts.secret ? text.replace(/./g, "*") : text) + "_";
                    clear(grid); keys = [];
                    var set = layouts[page];
                    set.forEach(function (line) {
                        var rowEl = el("div", grid, {display: "flex", justifyContent: "center"}), rowKeys = [];
                        line.split("").forEach(function (ch) { rowKeys.push({el: el("div", rowEl, keyStyle(56)), value: ch}); rowKeys[rowKeys.length - 1].el.textContent = ch; });
                        keys.push(rowKeys);
                    });
                    if (opts.quickKeys && opts.quickKeys.length) {
                        var quick = el("div", grid, {display: "flex", justifyContent: "center"}), quickKeys = [];
                        opts.quickKeys.forEach(function (q) { quickKeys.push({el: el("div", quick, keyStyle(Math.max(140, q.length * 18 + 40)), q), value: "quick:" + q}); });
                        keys.push(quickKeys);
                    }
                    var last = el("div", grid, {display: "flex", justifyContent: "center"}), specials = [];
                    [[page === 1 ? "SHIFT" : "Shift", "shift", 140], [page === 2 ? "abc" : "#+=", "symbols", 130], ["Space", " ", 260], ["Delete", "del", 140], ["Done", "done", 170]].forEach(function (k) {
                        var node = el("div", last, keyStyle(k[2]), k[0]); specials.push({el: node, value: k[1]});
                    });
                    keys.push(specials);
                    r = Math.min(r, keys.length - 1); c = Math.min(c, keys[r].length - 1); paint();
                }
                function keyStyle(width) { return {width: width + "px", height: "56px", lineHeight: "56px", margin: "5px", textAlign: "center", fontSize: "26px", borderRadius: "12px", backgroundColor: C.pill, color: C.text}; }
                function paint() {
                    keys.forEach(function (line, i) { line.forEach(function (k, j) {
                        var on = i === r && j === c;
                        k.el.style.backgroundColor = on ? C.focus : C.pill; k.el.style.color = on ? "#000000" : C.text;
                    }); });
                }
                function press(v) {
                    if (v === "shift") { page = page === 0 ? 1 : 0; render(); return; }
                    if (v === "symbols") { page = page === 2 ? 0 : 2; render(); return; }
                    if (v === "del") { text = text.slice(0, -1); render(); return; }
                    if (v === "done") { finish(text); return; }
                    if (v.indexOf("quick:") === 0) {
                        var insert = v.slice(6), limit = opts.maxLength || 128;
                        // A scheme replaces any scheme already typed instead of stacking.
                        if (/^[a-z]+:\/\/$/i.test(insert)) text = insert + text.replace(/^[a-z][a-z0-9+.-]*:\/\//i, "");
                        else text += insert;
                        text = text.slice(0, limit); render(); return;
                    }
                    if (text.length < (opts.maxLength || 128)) text += v;
                    render();
                }
                function finish(result) {
                    if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
                    active = null; resolve(result);
                }
                active = {
                    finish: finish,
                    action: function (name) {
                        if (name === "up") { r = Math.max(0, r - 1); c = Math.min(c, keys[r].length - 1); paint(); }
                        else if (name === "down") { r = Math.min(keys.length - 1, r + 1); c = Math.min(c, keys[r].length - 1); paint(); }
                        else if (name === "left") { c = Math.max(0, c - 1); paint(); }
                        else if (name === "right") { c = Math.min(keys[r].length - 1, c + 1); paint(); }
                        else if (name === "accept") press(keys[r][c].value);
                        else if (name === "cancel") finish(null);
                        else if (name === "menu") press("del");
                        else if (name === "options") press("shift");
                        else if (name === "zr") press("symbols");
                        else if (name === "plus") finish(text);
                        else if (name.length === 6 && name.indexOf("char:") === 0) press(name.slice(5));
                        else if (name === "backspace") press("del");
                    }
                };
                render();
            });
        }
        return {open: open, active: function () { return !!active; }, action: function (n) { if (active) active.action(n); }};
    }

    // Artwork: one download at a time, an LRU cache bounded by the size of the
    // data URLs it holds (8 MiB, as Moonlight does), and images released from
    // <img> elements that are far from the focus so the engine can free them.
    function createArtwork(fetchImage, log, options) {
        options = options || {};
        var budget = options.budget || 8 * 1048576;
        var cache = new Map(), bytes = 0, failed = new Set(), queue = [], running = false, generation = 0;
        var shown = new Map();                          // img node -> key currently displayed
        function remember(key, url) {
            var size = url.length * 2;
            if (size > budget) return;
            if (cache.has(key)) { bytes -= cache.get(key).length * 2; cache.delete(key); }
            while (bytes + size > budget && cache.size) { var oldest = cache.keys().next().value; bytes -= cache.get(oldest).length * 2; cache.delete(oldest); }
            cache.set(key, url); bytes += size;
        }
        function display(node, key, url) { node.src = url; node.style.display = ""; shown.set(node, key); }
        function pump() {
            if (running) return;
            var job;
            while (queue.length) { job = queue.shift(); if (job.generation === generation && job.wanted() && !cache.has(job.key) && !failed.has(job.key)) break; job = null; }
            if (!job) return;
            running = true;
            fetchImage(job.id, job.tag, job.height, job.kind).then(function (url) {
                if (!url) { failed.add(job.key); return; }
                remember(job.key, url);
                if (job.generation === generation && job.wanted()) display(job.node, job.key, url);
            }).catch(function (e) { failed.add(job.key); log("Artwork: " + e.message); })
              .then(function () { running = false; pump(); });
        }
        return {
            show: function (node, id, tag, height, kind) {
                if (!id || !tag || !node) return;
                kind = kind || "Primary";
                var key = id + ":" + kind + ":" + tag + ":" + height;
                if (shown.get(node) === key) return;
                if (cache.has(key)) { var url = cache.get(key); cache.delete(key); cache.set(key, url); display(node, key, url); return; }
                if (failed.has(key) || queue.some(function (j) { return j.node === node && j.key === key; })) return;
                queue.push({key: key, id: id, tag: tag, height: height, kind: kind, node: node, generation: generation,
                    wanted: function () { return !!node.parentNode && node.__jfWanted !== false; }});
                pump();
            },
            release: function (node) {
                if (!node || !shown.has(node)) return;
                node.removeAttribute("src"); node.style.display = "none"; shown.delete(node);
            },
            reset: function () { generation++; queue = []; shown.clear(); },
            idle: function () { return !running && !queue.length; },
            stats: function () { return {cached: cache.size, bytes: bytes, queued: queue.length, shown: shown.size, failed: failed.size}; }
        };
    }

    JF.ui = {el: el, clear: clear, formatTime: formatTime, createNavigator: createNavigator, button: button, pill: pill, createKeyboard: createKeyboard, createArtwork: createArtwork};
})();
