/* Entry point. Keep this file last in the bundle: its promise is the app lifetime. */
/* Credits: closing a previous app and returning the lifetime promise as the last
 * expression follow XITRIX's CivHomebrew Hello example; the CIVSWITCH_APP_READY
 * marker is that example's convention. */
(async function () {
    "use strict";
    var previous = window.__civswitchApp;
    if (previous && typeof previous.close === "function") await previous.close();
    var platform, startupError = null;
    try { platform = JF.nativePlatform.create(); }
    catch (error) {
        startupError = error;
        // Outside CivSwitch (for example a desktop browser preview) the UI still
        // runs; network and video calls report why they are unavailable.
        var memory = null;
        platform = {
            transport: {request: function () { return Promise.reject(new Error("Networking unavailable: " + startupError.message)); }},
            storage: {load: function () { return memory; }, save: function (data) { memory = JSON.parse(JSON.stringify(data)); }},
            createSink: function () { throw new Error(startupError.message); },
            sleep: function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
        };
    }
    var app = JF.startApp(platform);
    if (startupError) JF.log("Platform unavailable: " + startupError.message);
    // Bounded startup marker for the PC-side loader log, as in the Hello example.
    if (typeof log === "function") { try { await log("CIVSWITCH_APP_READY"); } catch (e) {} }
    await app.lifetime;
})();
