/* Player sink backed by the console's native media pipeline (MoonlightStreamMedia,
 * bundled at build time from a local Moonlight-CivSwitch checkout):
 * movie::Decoder hardware H.264 -> GPU texture shown as a live:/ image, and
 * libopus -> nn::audio AudioOut at 48 kHz stereo. */
/* Credits: playback uses XITRIX's native media pipeline from Moonlight-CivSwitch:
 * native-io.js, native-texture.js and native-media.js (MoonlightStreamIO,
 * MoonlightNativeTexture, MoonlightStreamMedia), copied from your local checkout at
 * build time and not covered by this project's license. The synchronous
 * presentation fallback uses that module's own synchronousGpu option; the decoder
 * delay estimate reads its presentAge statistics. */
(function () {
    "use strict";
    var G = typeof window !== "undefined" ? window : globalThis;
    var JF = G.JF = G.JF || {};

    // heap: the platform's validated ArrayBuffer view; media uses [mediaOffset, end).
    function create(io, heap, mediaOffset, options) {
        options = options || {};
        if (!G.MoonlightStreamMedia || !G.MoonlightNativeTexture) throw new Error("Native media modules missing from the package.");
        var SPS = mediaOffset + 16, PPS = mediaOffset + 65536, AUDIO = mediaOffset + 131072, AU = mediaOffset + 262144;
        var AU_LIMIT = heap.length - AU;
        // Only the GPU path is used, which never touches the wasm core; these
        // members cover the few calls MoonlightStreamMedia makes regardless.
        var core = {HEAPU8: heap, _malloc: function () { return 0; }, _free: function () {}, _ml_png_release: function () {}, UTF8ToString: function () { return ""; }};
        var media = null, spsLength = 0, ppsLength = 0, failures = 0;
        var log = options.log || function () {};

        function open(format, synchronousGpu) {
            media = G.MoonlightStreamMedia.create(io, core, {
                onImage: options.onImage, onStatus: function (text) { log(text); },
                smoothVideo: false, synchronousGpu: synchronousGpu
            });
            // fps only selects Moonlight's 60 fps live pacer; timing is handled by the player.
            if (media.videoSetup(1, format.width, format.height, 30) !== 0) throw new Error("Video decoder setup failed.");
        }

        function setup(format) {
            close();
            // The asynchronous path needs a GPU fence found at fixed offsets in the
            // movie module. If those checks reject it, use the module's synchronous
            // presentation instead (no fence) and keep that choice for this session.
            if (!G.__jellyfinSyncGpu) {
                try { open(format, false); }
                catch (e) {
                    if (!/GPU sync|GPU completion/.test(e.message)) throw e;
                    log("Async GPU presentation unavailable (" + e.message + "); using synchronous presentation.");
                    try { if (media) media.close(); } catch (closeError) { log("Media cleanup: " + closeError.message); }
                    media = null; G.__jellyfinSyncGpu = true;
                }
            }
            if (!media) { open(format, true); log("Video: synchronous GPU presentation"); }
            else log("Video: asynchronous GPU presentation");
            if (media.audioSetup(48000, 2, 1, 1, 960) !== 0) throw new Error("Audio output setup failed.");
            spsLength = ppsLength = 0;
        }

        function videoFrame(au) {
            if (!media) return false;
            if (au.data.length > AU_LIMIT) throw new Error("Video frame too large (" + au.data.length + " bytes).");
            if (au.sps && au.pps && !spsLength) {
                heap.set(au.sps, SPS); spsLength = au.sps.length;
                heap.set(au.pps, PPS); ppsLength = au.pps.length;
            }
            heap.set(au.data, AU);
            var result = media.videoFrame(AU, au.data.length, 0, Math.round(au.pts / 90),
                spsLength ? SPS : 0, spsLength, ppsLength ? PPS : 0, ppsLength, heap);
            return result === 0;
        }

        function audioFrame(packet) {
            if (!media || packet.data.length > 65536) return;
            heap.set(packet.data, AUDIO);
            try { media.audioFrame(AUDIO, packet.data.length, heap); }
            catch (e) { if (++failures <= 3) log("Audio: " + e.message); }
        }

        function close() {
            if (!media) return;
            var m = media; media = null;
            m.close();
        }

        return {
            setup: setup,
            videoFrame: videoFrame,
            audioFrame: audioFrame,
            drainVideo: function () { if (media) { media.drainVideo(); media.finishVideo(); } },
            drainAudio: function () { if (media) media.drainAudio(); },
            close: close,
            stats: function () { return media ? media.stats() : null; },
            mode: function () { return G.__jellyfinSyncGpu ? "synchronous" : "asynchronous"; },
            // Average time from handing a frame to the decoder until it is on screen,
            // measured by the native media module itself (seconds), or null.
            latency: function () {
                if (!media) return null;
                var st = media.stats();
                return st && st.presentAgeSamples >= 8 ? st.presentAgeMs / st.presentAgeSamples / 1000 : null;
            }
        };
    }

    JF.createNativeSink = create;
})();
