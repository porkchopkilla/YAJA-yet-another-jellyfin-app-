/* HLS media playlist parsing and URL resolution. Pure logic. */
(function () {
    "use strict";
    var G = typeof window !== "undefined" ? window : globalThis;
    var JF = G.JF = G.JF || {};

    // Returns {targetDuration, endList, segments:[{uri, duration, start}], totalDuration}.
    function parsePlaylist(text) {
        var lines = String(text).split(/\r?\n/), result = {targetDuration: 0, endList: false, mediaSequence: 0, segments: [], totalDuration: 0, encrypted: false, fmp4: false};
        if (!lines.length || lines[0].trim() !== "#EXTM3U") throw new Error("Not an HLS playlist");
        var pending = null, start = 0;
        for (var i = 1; i < lines.length; i++) {
            var line = lines[i].trim();
            if (!line) continue;
            if (line.indexOf("#EXT-X-TARGETDURATION:") === 0) result.targetDuration = Number(line.slice(22)) || 0;
            else if (line.indexOf("#EXT-X-MEDIA-SEQUENCE:") === 0) result.mediaSequence = Number(line.slice(22)) || 0;
            else if (line === "#EXT-X-ENDLIST") result.endList = true;
            else if (line.indexOf("#EXT-X-KEY:") === 0 && !/METHOD=NONE/.test(line)) result.encrypted = true;
            else if (line.indexOf("#EXT-X-MAP:") === 0) result.fmp4 = true;
            else if (line.indexOf("#EXTINF:") === 0) pending = Number(line.slice(8).split(",")[0]);
            else if (line[0] !== "#") {
                if (pending === null || !isFinite(pending)) throw new Error("Segment without duration");
                result.segments.push({uri: line, duration: pending, start: start});
                start += pending; pending = null;
            }
        }
        result.totalDuration = start;
        return result;
    }

    // Master playlists list variants; pick the first (Jellyfin offers one per request).
    function firstVariant(text) {
        var lines = String(text).split(/\r?\n/);
        for (var i = 0; i < lines.length; i++) {
            if (lines[i].indexOf("#EXT-X-STREAM-INF:") === 0) {
                for (var j = i + 1; j < lines.length; j++) if (lines[j].trim() && lines[j][0] !== "#") return lines[j].trim();
            }
        }
        return null;
    }

    // Resolve a playlist entry against the playlist's own path (server-relative paths only).
    function resolve(basePath, uri) {
        if (/^https?:\/\//i.test(uri)) {
            var m = /^https?:\/\/[^\/]+(\/.*)?$/i.exec(uri);
            return m && m[1] ? m[1] : "/";
        }
        if (uri[0] === "/") return uri;
        var queryAt = basePath.indexOf("?"), path = queryAt >= 0 ? basePath.slice(0, queryAt) : basePath;
        var dir = path.slice(0, path.lastIndexOf("/") + 1), parts = (dir + uri).split("?"), segs = parts[0].split("/"), out = [];
        for (var i = 0; i < segs.length; i++) {
            if (segs[i] === "..") out.pop(); else if (segs[i] !== ".") out.push(segs[i]);
        }
        return out.join("/") + (parts.length > 1 ? "?" + parts.slice(1).join("?") : "");
    }

    // Index of the segment containing `seconds`.
    function segmentAt(playlist, seconds) {
        var segments = playlist.segments;
        for (var i = segments.length - 1; i >= 0; i--) if (segments[i].start <= seconds) return i;
        return 0;
    }

    JF.hls = {parsePlaylist: parsePlaylist, firstVariant: firstVariant, resolve: resolve, segmentAt: segmentAt};
    if (typeof module !== "undefined" && module.exports) module.exports = JF.hls;
})();
