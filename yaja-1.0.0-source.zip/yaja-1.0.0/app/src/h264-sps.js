/* H.264 sequence parameter set parser: coded and cropped dimensions. Pure logic. */
(function () {
    "use strict";
    var G = typeof window !== "undefined" ? window : globalThis;
    var JF = G.JF = G.JF || {};

    function unescape(nal) {
        var out = new Uint8Array(nal.length), n = 0, zeros = 0;
        for (var i = 0; i < nal.length; i++) {
            if (zeros >= 2 && nal[i] === 3) { zeros = 0; continue; }   // emulation prevention byte
            out[n++] = nal[i]; zeros = nal[i] === 0 ? zeros + 1 : 0;
        }
        return out.subarray(0, n);
    }

    function Bits(bytes) { this.b = bytes; this.p = 0; }
    Bits.prototype.u = function (n) {
        var v = 0;
        for (var i = 0; i < n; i++) {
            var byte = this.b[this.p >> 3];
            if (byte === undefined) throw new Error("SPS truncated");
            v = v * 2 + ((byte >> (7 - (this.p & 7))) & 1); this.p++;
        }
        return v;
    };
    Bits.prototype.ue = function () {
        var zeros = 0;
        while (this.u(1) === 0) { if (++zeros > 32) throw new Error("Invalid SPS exp-golomb"); }
        return zeros ? Math.pow(2, zeros) - 1 + this.u(zeros) : 0;
    };
    Bits.prototype.se = function () { var k = this.ue(); return (k & 1) ? (k + 1) / 2 : -(k / 2); };

    function skipScalingList(bits, size) {
        var last = 8, next = 8;
        for (var j = 0; j < size; j++) {
            if (next !== 0) next = (last + bits.se() + 256) % 256;
            last = next === 0 ? last : next;
        }
    }

    // nal: the SPS NAL unit including its one-byte header, without a start code.
    function parse(nal) {
        if (!nal || nal.length < 4 || (nal[0] & 0x1f) !== 7) throw new Error("Not an SPS NAL unit");
        var bits = new Bits(unescape(nal.subarray(1)));
        var profile = bits.u(8); bits.u(8); var level = bits.u(8);
        bits.ue();                                                   // seq_parameter_set_id
        var chroma = 1;
        if ([100, 110, 122, 244, 44, 83, 86, 118, 128, 138, 139, 134, 135].indexOf(profile) >= 0) {
            chroma = bits.ue();
            if (chroma === 3) bits.u(1);
            bits.ue(); bits.ue(); bits.u(1);
            if (bits.u(1)) for (var i = 0; i < (chroma !== 3 ? 8 : 12); i++) if (bits.u(1)) skipScalingList(bits, i < 6 ? 16 : 64);
        }
        bits.ue();                                                   // log2_max_frame_num_minus4
        var pocType = bits.ue();
        if (pocType === 0) bits.ue();
        else if (pocType === 1) { bits.u(1); bits.se(); bits.se(); var cycle = bits.ue(); for (var c = 0; c < cycle; c++) bits.se(); }
        var refFrames = bits.ue(); bits.u(1);
        var mbsWide = bits.ue() + 1, mapUnitsHigh = bits.ue() + 1, frameMbsOnly = bits.u(1);
        if (!frameMbsOnly) bits.u(1);
        bits.u(1);
        var cropLeft = 0, cropRight = 0, cropTop = 0, cropBottom = 0;
        if (bits.u(1)) { cropLeft = bits.ue(); cropRight = bits.ue(); cropTop = bits.ue(); cropBottom = bits.ue(); }
        var unitX = chroma === 0 ? 1 : (chroma === 3 ? 1 : 2);
        var unitY = (chroma === 0 || chroma === 1 ? (chroma === 0 ? 1 : 2) : 1) * (frameMbsOnly ? 1 : 2);
        var codedWidth = mbsWide * 16, codedHeight = (frameMbsOnly ? 1 : 2) * mapUnitsHigh * 16;
        return {
            profile: profile, level: level, chromaFormat: chroma, refFrames: refFrames,
            codedWidth: codedWidth, codedHeight: codedHeight,
            width: codedWidth - unitX * (cropLeft + cropRight),
            height: codedHeight - unitY * (cropTop + cropBottom)
        };
    }

    JF.h264Sps = {parse: parse};
    if (typeof module !== "undefined" && module.exports) module.exports = JF.h264Sps;
})();
