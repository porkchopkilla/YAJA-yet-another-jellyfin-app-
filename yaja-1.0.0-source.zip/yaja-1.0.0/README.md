# YAJA (Yet another jellyfin app) 1.0

**YAJA** is an **unofficial** Jellyfin client for the CivSwitch userland escape on Nintendo
Switch / Switch 2, packaged as a `.civapp` for CivHomebrew (or a single `.js` for
Gezine's loader). Sign in at home or remotely over HTTPS, browse your libraries,
watch movies and shows with subtitles, audio and quality choices, and watch Live TV
with a channel guide.

Not affiliated with or endorsed by the Jellyfin project, Nintendo, Firaxis or 2K.
The app icon and name are original; "Jellyfin" refers to the server it connects to.

Built on the work of **XITRIX** (CivHomebrew and Moonlight-CivSwitch) and
**Gezine** (CivSwitch); see [Credits](#credits).

> **Status:** tested on a Switch 2: browsing, local and remote (HTTPS) playback,
> the media bar features of earlier builds, and smooth 24/30 fps playback. Live TV
> and keeping the screen awake have so far been tested against simulated servers
> and a simulated console only. **Settings → Diagnostics** and playback reports
> (**Y** during playback) make problems easy to report.

## Requirements

- **CivSwitch with CivHomebrew**, on the setup Moonlight for CivSwitch needs:
  the Switch 1 edition of Civilization VII, physical cartridge **1.0.0**. Video
  output uses build-specific offsets and refuses to run on other builds.
- A **Jellyfin server** reachable from the console: at home by its local
  address (`http://192.168.1.20:8096`), or remotely by an **HTTPS** address
  such as `https://jellyfin.example.com` or `https://example.com/jellyfin`.
  IPv6 is not supported.
- The account must be **allowed to transcode** (Dashboard → Users → Playback).
  Every title is transcoded to H.264 video with stereo Opus audio in MPEG-TS
  segments, the only formats the console's native pipeline is known to play.
  Standard Jellyfin installs (jellyfin-ffmpeg) include the needed encoders.

## Install

**CivHomebrew (recommended):** in CivHomebrew press **Y → FTP**, enable it,
connect an FTP client to the console (port 5000, plain FTP, passive, binary)
and upload `dist/yaja.civapp` into **Install civapp**. Launch **YAJA** (the splash screen spells out *Yet another jellyfin app*).

**Gezine's Remote JS Loader:** with the loader waiting on port 9026, run
`python3 send_js.py SWITCH_IP dist/yaja.js` from the CivSwitch
folder. Keep the terminal open while the app runs.

## First launch

1. **Server** → type the address, for example `http://192.168.1.20:8096`, then
   **Connect**. The field takes up to 128 characters and has **http://** and
   **https://** keys; pressing one replaces any scheme already typed. Whatever you
   type is saved, and problems are explained when you press Connect.
2. Sign in with **username and password**, or choose **Quick Connect** and enter
   the 6-digit code on a signed-in device (Jellyfin → profile → Quick Connect).
   Quick Connect must be enabled on the server.

The server address and sign-in token are saved under
`save:/civhomebrew/jellyfin/` (kept across updates and reinstalls); your password is never stored. Later launches
open straight to Home.

## Remote access

Use your server's HTTPS address (a reverse proxy with a certificate, for example
from Let's Encrypt). Default ports: 443 for https, 8096 for http.

- **Test connection** on the server screen checks each step separately: finding
  the server name, connecting, the secure (TLS) handshake and Jellyfin's reply,
  and shows which one fails. The results are also in Diagnostics.
- Server names are looked up with public DNS (1.1.1.1, 8.8.8.8, 9.9.9.9), then
  the console's own resolver for names only your local network knows.
- HTTPS uses the console's built-in TLS and checks the certificate. For a
  self-signed certificate, turn off **Settings → Connection → Check HTTPS
  certificates** (insecure: anyone in between could impersonate the server).
- Plain `http://` to an address outside your home network works but shows a
  warning: your password and session would cross the internet unencrypted.

The console TLS calls follow the Switch SDK but were first tested on a simulated
console; if the secure handshake fails, Test connection shows the exact error
code.

## Controls

| Where | Control |
| --- | --- |
| Menus | D-pad / stick: move · **A**: select · **B**: back · **L / R**: previous / next tab (Home, libraries, Settings) · **Y**: Settings |
| TV show | Seasons on the left, episodes on the right (on the show's backdrop) · **◀ ▶**: switch panes · **A** on a season: show its episodes |
| Keyboard | **A**: type · **X**: delete · **Y**: shift · **ZR** or the `#+=` key: symbols · **+** or Done: finish · **B**: cancel |
| Playback | **A**: pause/resume · **◀ ▶**: −/+10 s, or move along the media bar while it shows · **L / R**: −/+1 min · **X**: stats · **Y**: 30 s report · **B**: stop |

**Look:** an Apple TV-style interface: tabs along the top (Home, each library,
Settings), rounded artwork, Continue watching and Next up cards framed in a
Jellyfin blue-to-purple gradient, white focus highlights and pill buttons; details
pages have a large backdrop. Going back returns focus to where you were.

**Screen dimming:** while a video plays, the app tells the system media is
playing so the screen does not dim or sleep (released when paused or stopped).
Diagnostics shows which method the console supports.

**Live TV:** when your server has Live TV set up (a tuner or M3U, with guide
data), a **Live TV** tab shows a channel guide: channels down the side, a 2-hour
window of programs across, and details of the highlighted program on top. Up/down
change channel at the same time, left/right move through programs (the window
slides). **A** on something airing now tunes it; while watching, **L / R** change
channel. Leaving playback releases the tuner.

**Media bar:** while the playback overlay shows, ◀ ▶ move between **⏪ 10**,
**Pause/Play**, **10 ⏩**, **Subtitles**, **Audio** and **Quality**. Subtitles are
burned into the video by the server; changing subtitles, audio or quality
restarts the stream at the same moment (quality applies to that video only).

**Guide time:** the guide uses the server's clock (from its replies) and shows a
live clock. If times are off by whole hours, set **Settings → Time → Time zone**
(Auto uses the console's zone).

**Auto-play:** when an episode ends, an **Up next** card counts down 10 seconds
before playing the next episode (crossing into the next season). **A** plays it
now, **B** stops. Turn it off in **Settings → Playback**.

**Home rows:** Continue watching and Next up hold up to 24 items; moving past
the last visible card slides the row along (a counter shows the position).

Repeated seek presses are combined into one seek, because each seek restarts
the server's transcode at that point.

The engine only reports the D-pad, A and B as input events, so X, Y, L, R, ZR
and + are read from the controller directly (the same method CivHomebrew uses
for its X menu). Diagnostics shows "Controller buttons: native" when this works.

Libraries are sorted A–Z by Jellyfin's sort name, which ignores a leading
"The"/"A" and orders numbers naturally (Film 2, Film 9, Film 10).

**Settings** has the streaming quality (720p 4 Mbps by default; up to 1080p
12 Mbps), sign out, and **Diagnostics**, a log of recent events and errors.

## Limitations

- Always transcodes; no direct play. Requires transcoding permission.
- Default audio track only; no subtitles yet.
- No IPv6.
- Maximum 1920×1080.
- Audio/video timing follows the console clock. Small drift over very long
  films is possible.
- Seeking restarts the transcode, so it takes a few seconds.

## Troubleshooting

- **"Connection refused"**: check the IP and port, and that the server allows
  LAN connections.
- **Which video mode is in use**: Diagnostics shows "Video: asynchronous GPU
  presentation" or "synchronous". If the asynchronous GPU fence can't be set up
  (the "GPU sync pointer range rejected" error), the app switches to
  synchronous presentation automatically.
- **Playback fails or shows no picture**: open **Settings → Diagnostics** and
  press **X** during playback for live stats (segments, frames fed, decoded,
  presented). Note the last lines when reporting problems.
- **Choppy video**: record a playback report (below) and send it.

### Playback reports

During playback, press **Y** to record a 30-second report while the video keeps
playing (the stats overlay shows the progress). The app then adds the server's
live transcode details, writes a summary with plain-language **findings** (most
likely cause first) and saves it as a text file:

- On the console: **Settings → Playback report**.
- Over FTP: CivHomebrew FTP → Root → `civhomebrew/jellyfin/reports/report-….txt`
  (files under `civhomebrew/` can be downloaded but not changed over FTP).

**X** shows live values for the last 5 seconds: frames shown per second, frame
spacing and its variation, the longest pause in the frame loop, how long
download processing took, late/skipped/replaced frames, audio underruns, decode
and GPU copy time, and the measured decoder delay.

## Build from source

Requires Python 3.10+ and a local checkout of
[Moonlight-CivSwitch](https://github.com/XITRIX/Moonlight-CivSwitch):

```sh
python3 tools/build.py --moonlight PATH/TO/Moonlight-CivSwitch
```

This writes `dist/yaja.civapp` and `dist/yaja.js`. The build
copies Moonlight's three native media modules (`native-io.js`,
`native-texture.js`, `native-media.js`) from your checkout into the package and
uses its `tools/package_payload.py`; pass `--packager` to use CivHomebrew's.

**Licensing of the build:** the three native media modules come from XITRIX's
Moonlight-CivSwitch, which does not currently ship a license for them. They are
therefore not in this source tree; the build copies them from your own checkout
and marks them with an attribution header. A built `.civapp` or `.js` contains
them, so it should only be shared publicly with XITRIX's permission (see
[Credits](#credits)).

## How it works

| File | Role |
| --- | --- |
| `http.js` | HTTP/1.1 request builder and incremental response parser (chunked, length, close). |
| `jellyfin-api.js` | Jellyfin REST client; routes checked against the Jellyfin server source. |
| `hls.js`, `ts-demux.js`, `h264-sps.js` | HLS playlists, MPEG-TS demuxing (H.264 Annex-B + Opus), SPS dimensions. |
| `player.js` | Downloads segments, keeps the timeline, feeds video by decode order and audio in real time. |
| `platform-native.js` | Console only: SDK symbol lookup, `nn::socket` HTTP and DNS, `nn::ssl` HTTPS, `nn::fs` settings, `nn::hid` buttons, keep-awake. |
| `native-sink.js` | Console only: connects the player to Moonlight's native media pipeline. |
| `ui-kit.js`, `app.js`, `main.js` | Screens, controller input, playback screen and app lifetime. |

## Testing

Run `npm test` (Node 22+, ffmpeg and ffprobe on PATH):

- **Demuxer** against real ffmpeg H.264 (B-frames) + Opus MPEG-TS, cross-checked
  packet by packet against ffprobe, and the reassembled video decoded by ffmpeg
  without errors.
- **SPS/HLS** on real ffmpeg HLS output at 1080p, 1920×800, 854×480 and 1280×718.
- **HTTP** parser with byte-by-byte delivery, chunked encoding and header injection.
- **End to end** against a mock Jellyfin server over real TCP: sign-in, Quick
  Connect, browsing, artwork and full playback, seek, pause and resume.
- **UI flow** with a fake DOM, driven only by key presses: typing the server and
  credentials, browsing, playing a title, settings, and auto sign-in on restart.
- **Bundle** evaluated the way the loader does.

The console-only files (`platform-native.js`, the native sink) are additionally
run against a simulated console (fake memory, `nn::socket`, `nn::ssl`, DNS and
`nn::oe`) to check call sequences, socket ownership and that every allocation is freed.

## Credits

- **[XITRIX](https://github.com/XITRIX)**
  - **CivHomebrew**: the launcher this app runs in, the `.civapp` format and its
    packager (`package_payload.py`, used by the build), the app lifetime contract,
    and the approach for reading controller buttons natively.
  - **Moonlight-CivSwitch**: the native video and audio pipeline used for playback
    (`native-io.js`, `native-texture.js`, `native-media.js`: hardware H.264
    decoding, the GPU texture shown as a `live:/` image, Opus and AudioOut), and the
    console patterns this app's networking, save file and SDK lookup follow. Its
    menus also set the example for the artwork memory limit and animation-free UI.
- **[Gezine](https://github.com/Gezine/CivSwitch)**: CivSwitch, the userland
  escape and loader whose primitives (`call_rop`, `malloc`, ...) every native call
  relies on (MIT).
- **[The Jellyfin project](https://jellyfin.org)**: the media server and its API.
  Endpoints were checked against its server source. Jellyfin's blue and purple are
  used for the accent gradient; the app icon is original.

Credits also appear in the app under **Settings → About & credits**, and as
comments at the top of each file that uses or follows this work. See
[CREDITS.md](CREDITS.md) for details.

## License

This project's own code (`app/src`, `tests`, `tools`) is released under the MIT
License ([LICENSE](LICENSE)). XITRIX's modules included in built packages, and the
tools used from CivHomebrew and Moonlight-CivSwitch, are not covered by it and
remain their author's work.
