# Credits

YAJA (Yet another jellyfin app) is an independent, unofficial Jellyfin client. It exists because of
the following people and projects.

## XITRIX

**CivHomebrew** (https://github.com/XITRIX/CivHomebrew)
- The launcher the app is installed into and runs from.
- The `.civapp` package format; the build uses its `package_payload.py`.
- The app lifetime contract (`window.__civswitchApp`, the lifetime promise, full
  cleanup) and engine input handling, following its Hello example.
- Reading controller buttons natively through `nn::hid` (used for X, Y, L, R, ZR, +).

**Moonlight-CivSwitch** (https://github.com/XITRIX/Moonlight-CivSwitch)
- `native-io.js`, `native-texture.js` and `native-media.js`: the native playback
  pipeline (hardware H.264 decoding via `movie::Decoder`, the GPU texture published
  as a `live:/` image, libopus decoding and `nn::audio` output). These are copied
  unmodified from your checkout at build time, with an attribution header, and are
  **not** covered by this project's license.
- The patterns followed for the SDK export lookup, `nn::socket` networking and
  `nn::fs` save files.
- The console-tested menu practices followed here: the 8 MiB artwork cache, one
  image download at a time, `scrollTop` scrolling and no CSS animation.

## Gezine

**CivSwitch** (https://github.com/Gezine/CivSwitch, MIT)
- The userland escape and loader, including the primitives every native call uses
  (`call_rop`, `malloc`, `read32`, `alloc_string`, ...) and `send_js.py` for the
  single-file build.

## The Jellyfin project

- The Jellyfin media server and its API (https://github.com/jellyfin/jellyfin).
  Routes and fields were checked against the server source.
- Jellyfin's brand blue (#00A4DC) and purple (#AA5CC3) are used for the accent
  gradient. The YAJA name and icon are original. This app is not affiliated with or endorsed
  by the Jellyfin project.

## Tools used in testing

- FFmpeg and ffprobe generate and cross-check test streams (tests only; not
  included in the app).
